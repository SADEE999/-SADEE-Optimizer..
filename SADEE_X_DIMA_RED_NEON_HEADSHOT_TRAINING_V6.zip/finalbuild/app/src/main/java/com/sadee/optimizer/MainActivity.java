package com.sadee.optimizer;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.util.Log;
import android.widget.*;

import org.json.JSONObject;

import java.io.File;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(255, 45, 70);
    private static final int GREEN2 = Color.rgb(255, 85, 105);
    private static final int CYAN = Color.rgb(255, 110, 145);
    private static final int PURPLE = Color.rgb(178, 105, 255);
    private static final int RED = Color.rgb(255, 85, 105);
    private static final int BG = Color.rgb(4, 4, 7);
    private static final int CARD = Color.rgb(15, 8, 11);
    private static final int CARD2 = Color.rgb(24, 9, 14);
    private static final int MUTED = Color.rgb(135, 153, 151);

    private LinearLayout root, content, nav;
    private TextView licenseTimer, topTitle;
    private JSONObject license;
    private String licenseKey = "";
    private String selectedPlan = "7 DAYS";
    private ToneGenerator tone;
    private int currentPage = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String[] pageNames = {"HOME", "BOOST", "CLEAN", "GAMING", "MORE"};
    private SharedPreferences sessionPrefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        try { tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85); } catch (Exception ignored) { tone = null; }
        sessionPrefs = getSharedPreferences("sadee_secure_session", MODE_PRIVATE);
        tryAutoLogin();
    }

    private TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(12, 8, 12, 8);
        return t;
    }

    private TextView bigText(String s, float size, int color) {
        TextView t = tv(s, size, color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.BLACK); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false);
        b.setBackground(makeBg(color, 16, color)); b.setPadding(12, 4, 12, 4);
        return b;
    }

    private GradientDrawable makeBg(int fill, float radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(radius);
        g.setStroke(1, stroke);
        return g;
    }

    private TextView section(String s, int color) {
        TextView t = tv(s, 16, color);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(4, 18, 4, 10);
        return t;
    }

    private void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(10, 8, 10, 18);
        sv.addView(content); root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setPadding(4, 4, 4, 4); nav.setBackgroundColor(Color.rgb(6, 14, 14));
        root.addView(nav, new LinearLayout.LayoutParams(-1, 62));
        setContentView(root);
    }

    private ImageView logo() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.sadee_logo); image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        return image;
    }

    private void addHero(String title, String subtitle, String emoji) {
        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(14,12,14,14);
        hero.setBackground(makeBg(Color.rgb(3,12,10),24,GREEN));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView mini=logo(); mini.setBackground(makeBg(Color.rgb(1,8,7),22,GREEN2)); row.addView(mini,new LinearLayout.LayoutParams(58,58));
        LinearLayout tt=new LinearLayout(this); tt.setOrientation(LinearLayout.VERTICAL); tt.setPadding(12,0,0,0);
        TextView h=tv(title,20,Color.WHITE); h.setTypeface(Typeface.DEFAULT_BOLD); tt.addView(h);
        TextView s=tv(subtitle,10,GREEN); s.setTypeface(Typeface.DEFAULT_BOLD); tt.addView(s);
        row.addView(tt,new LinearLayout.LayoutParams(0,62,1));
        TextView ic=bigText(emoji,25,CYAN); row.addView(ic,new LinearLayout.LayoutParams(50,62));
        hero.addView(row); content.addView(hero,new LinearLayout.LayoutParams(-1,-2));
    }

    private void tryAutoLogin() {
        final String savedKey = sessionPrefs == null ? "" : sessionPrefs.getString("license_key", "");
        final String cached = sessionPrefs == null ? "" : sessionPrefs.getString("license_json", "");
        if (savedKey.trim().isEmpty()) { showLogin(); return; }

        showSessionLoading();
        new Thread(() -> {
            try {
                String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                JSONObject fresh = Supabase.verifyAndBind(savedKey, device, this);
                license = fresh; licenseKey = savedKey;
                saveSession(savedKey, fresh);
                runOnUiThread(() -> showApp());
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "" : e.getMessage();
                boolean hardFail = msg.contains("INVALID LICENSE") || msg.contains("LICENSE EXPIRED") || msg.contains("LICENSE PAUSED") || msg.contains("ANOTHER DEVICE");
                if (!hardFail && !cached.trim().isEmpty()) {
                    try {
                        JSONObject old = new JSONObject(cached);
                        String cachedExp = old.optString("expires_at", "");
                        if (!expiredLocal(cachedExp)) {
                            license = old; licenseKey = savedKey;
                            runOnUiThread(() -> showApp());
                            return;
                        }
                    } catch (Exception ignored) {}
                }
                clearSession();
                runOnUiThread(this::showLogin);
            }
        }).start();
    }

    private void showSessionLoading() {
        base();
        ImageView im = logo(); content.addView(im, new LinearLayout.LayoutParams(-1,220));
        TextView h = bigText("SADEE OPTIMIZER", 30, Color.WHITE); content.addView(h);
        TextView s = bigText("RESTORING SECURE SESSION", 15, GREEN); content.addView(s);
        TextView p = bigText("● LICENSE • DEVICE • CLOUD CHECK", 11, MUTED); content.addView(p);
    }

    private void saveSession(String key, JSONObject obj) {
        if (sessionPrefs == null) return;
        sessionPrefs.edit().putString("license_key", key).putString("license_json", obj == null ? "" : obj.toString()).apply();
    }

    private void clearSession() {
        if (sessionPrefs != null) sessionPrefs.edit().clear().apply();
        license = null; licenseKey = "";
    }

    private void showLogin() {
        base();
        content.addView(logo(), new LinearLayout.LayoutParams(-1, 190));
        TextView h = tv("SADEE X DIMA", 34, Color.WHITE); h.setGravity(Gravity.CENTER); h.setTypeface(null, Typeface.BOLD); content.addView(h);
        TextView sub = tv("O P T I M I Z E R", 24, GREEN); sub.setGravity(Gravity.CENTER); sub.setTypeface(null, Typeface.BOLD); content.addView(sub);
        TextView tag = tv("// SECURE GAMING LICENSE //", 11, MUTED); tag.setGravity(Gravity.CENTER); content.addView(tag);

        LinearLayout card = card();
        card.setPadding(16, 16, 16, 16);
        card.setBackground(makeBg(Color.rgb(7, 16, 15), 22, GREEN2));
        content.addView(card);
        TextView label = tv("● LICENSE ACCESS", 18, GREEN); label.setTypeface(null, Typeface.BOLD); card.addView(label);
        TextView hint = tv("Enter your key and select your plan", 12, MUTED); card.addView(hint);

        EditText key = new EditText(this);
        key.setSingleLine(true); key.setTextColor(Color.WHITE); key.setHintTextColor(MUTED);
        key.setTextSize(17); key.setHint("SXD-XXXX-XXXX-XXXX"); key.setPadding(16, 10, 16, 10);
        key.setBackground(makeBg(Color.rgb(3, 11, 10), 15, GREEN2));
        card.addView(key, new LinearLayout.LayoutParams(-1, 60));

        TextView planTitle = tv("SELECT PLAN", 14, CYAN); planTitle.setTypeface(null, Typeface.BOLD); card.addView(planTitle);
        LinearLayout plans = new LinearLayout(this); plans.setOrientation(LinearLayout.VERTICAL); card.addView(plans);

        TextView status = tv("READY • SELECT A PLAN", 13, MUTED); status.setGravity(Gravity.CENTER); card.addView(status);
        Button verify = btn("✓  VERIFY & UNLOCK", GREEN); verify.setTextColor(Color.BLACK); card.addView(verify, new LinearLayout.LayoutParams(-1, 60));

        final TextView[] selected = new TextView[1];
        String[][] choices = {{"7 DAYS", "LKR 500"}, {"1 MONTH", "LKR 1,000"}, {"LIFETIME", "LKR 2,200"}};
        for (String[] c : choices) {
            TextView p = tv("", 15, Color.WHITE); p.setGravity(Gravity.CENTER_VERTICAL); p.setTypeface(null, Typeface.BOLD);
            p.setPadding(18, 0, 18, 0);
            p.setText(c[0] + "                                      " + c[1]);
            p.setBackground(makeBg(Color.rgb(8, 22, 19), 15, Color.rgb(25, 70, 55)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 58); lp.setMargins(0, 6, 0, 0); plans.addView(p, lp);
            p.setOnClickListener(v -> {
                selectedPlan = c[0];
                if (selected[0] != null) selected[0].setBackground(makeBg(Color.rgb(8, 22, 19), 15, Color.rgb(25, 70, 55)));
                p.setBackground(makeBg(Color.rgb(2, 42, 28), 15, GREEN));
                selected[0] = p;
                status.setText("SELECTED • " + selectedPlan);
                beep(1);
            });
        }
        ((TextView) plans.getChildAt(0)).performClick();

        verify.setOnClickListener(v -> {
            String k = key.getText().toString().trim().toUpperCase(Locale.US);
            if (k.isEmpty()) { status.setText("ENTER A LICENSE KEY"); beep(2); return; }
            verify.setEnabled(false); status.setText("● VERIFYING LICENSE • PLEASE WAIT"); beep(1);
            new Thread(() -> {
                try {
                    String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    license = Supabase.verifyAndBind(k, device, this);
                    licenseKey = k;
                    saveSession(k, license);
                    runOnUiThread(() -> { beep(3); showApp(); });
                } catch (Exception e) {
                    runOnUiThread(() -> { verify.setEnabled(true); status.setText(e.getMessage() == null ? "VERIFY FAILED" : e.getMessage()); beep(2); });
                }
            }).start();
        });

        TextView foot = tv("1 LICENSE = 1 DEVICE • DEVICE BINDING + EXPIRY PROTECTION", 12, MUTED);
        foot.setGravity(Gravity.CENTER);
        content.addView(foot);
    }


    private void showApp() {
        base(); content.setPadding(12,10,12,22);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(2,0,2,4);
        ImageView li=logo(); top.addView(li,new LinearLayout.LayoutParams(56,56));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setPadding(8,0,0,0);
        topTitle=tv("SADEE OPTIMIZER",19,Color.WHITE); topTitle.setTypeface(Typeface.DEFAULT_BOLD); titles.addView(topTitle);
        TextView online=tv("● REAL ANDROID MONITOR",10,GREEN); online.setTypeface(Typeface.DEFAULT_BOLD); titles.addView(online);
        top.addView(titles,new LinearLayout.LayoutParams(0,56,1));
        TextView battery=bigText("●",18,GREEN); top.addView(battery,new LinearLayout.LayoutParams(26,52));
        content.addView(top);

        licenseTimer=bigText("",11,CYAN); licenseTimer.setBackground(makeBg(Color.rgb(3,30,22),18,GREEN2));
        content.addView(licenseTimer,new LinearLayout.LayoutParams(-1,42)); updateLicenseTimer();
        handler.postDelayed(new Runnable(){public void run(){if(!isFinishing()&&license!=null){updateLicenseTimer();handler.postDelayed(this,1000);}}},1000);

        showPage(0);
        String[] icons={"⌂","⚡","🧹","🎮","⋮"};
        for(int i=0;i<pageNames.length;i++){ final int p=i; Button b=btn(icons[i]+"\n"+pageNames[i],Color.rgb(4,13,12)); b.setTextSize(9); b.setTextColor(i==0?GREEN:Color.LTGRAY); b.setTypeface(Typeface.DEFAULT_BOLD); b.setPadding(2,2,2,2); nav.addView(b,new LinearLayout.LayoutParams(0,-1,1)); b.setOnClickListener(v->{
            v.setEnabled(false);
            try { showPage(p); for(int j=0;j<nav.getChildCount();j++) ((Button)nav.getChildAt(j)).setTextColor(j==p?GREEN:Color.LTGRAY); }
            finally { ((Button)v).postDelayed(() -> ((Button)v).setEnabled(true), 180); }
        }); }
    }

    private void updateLicenseTimer() {
        if (license == null || licenseTimer == null) return;
        String exp = license.optString("expires_at", "");
        String plan = license.optString("plan", "ACTIVE");
        licenseTimer.setText("🔑 " + licenseKey + "   •   " + plan.toUpperCase(Locale.US) + "   •   " + remaining(exp));
    }

    private String remaining(String exp) {
        if (exp == null || exp.trim().isEmpty() || "null".equalsIgnoreCase(exp)) return "LIFETIME • NO EXPIRY";
        Date d = parseDate(exp); if (d == null) return "TIME UNKNOWN";
        long ms = d.getTime() - System.currentTimeMillis(); if (ms <= 0) return "0h 0m REMAINING";
        long h = ms / 3600000L; long m = (ms % 3600000L) / 60000L;
        return h + "h " + m + "m REMAINING";
    }

    private boolean expiredLocal(String exp) {
        if (exp == null || exp.trim().isEmpty() || "null".equalsIgnoreCase(exp.trim())) return false;
        Date d = parseDate(exp); return d != null && d.getTime() <= System.currentTimeMillis();
    }

    private Date parseDate(String s) {
        String[] formats = {"yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String f : formats) { try { SimpleDateFormat df = new SimpleDateFormat(f, Locale.US); df.setTimeZone(TimeZone.getTimeZone("UTC")); Date d = df.parse(s, new ParsePosition(0)); if (d != null) return d; } catch (Exception ignored) {} }
        return null;
    }

    private void showPage(int p) {
        if (content == null) return;
        currentPage = Math.max(0, Math.min(p, pageNames.length - 1));
        content.removeAllViews();
        try {
            if (currentPage == 0) {
                addHero("SADEE OPTIMIZER", "GAMING CORE • ONLINE", "⚡");
                dashboardPage();
            } else if (currentPage == 1) {
                addHero("RAM BOOSTER", "MEMORY • PERFORMANCE", "RAM");
                stableBoostPage();
            } else if (currentPage == 2) {
                addHero("ADVANCED CLEANER", "STORAGE • SAFE CLEANUP", "CLEAN");
                stableCleanPage();
            } else if (currentPage == 3) {
                addHero("GAME CENTER", "GAME BOOSTER • FREE FIRE", "GAME");
                stableGamingPage();
            } else {
                addHero("DEVICE CENTER", "LIVE PHONE • LICENSE CONTROL", "⚙");
                stableMorePage();
            }
        } catch (Exception e) {
            Log.e("SADEE_UI", "Page load failed: " + currentPage, e);
            showSimpleErrorPage(e);
        }
    }

    private LinearLayout neonCard(String title, String subtitle) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(14, 12, 14, 12);
        c.setBackground(makeBg(Color.rgb(12, 7, 10), 16, GREEN));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 5, 0, 8);
        c.setLayoutParams(lp);
        TextView h = tv(title, 16, GREEN);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        c.addView(h);
        if (subtitle != null && !subtitle.isEmpty()) c.addView(tv(subtitle, 11, MUTED));
        return c;
    }

    private void stableBoostPage() {
        LinearLayout c = neonCard("🧠 RAM BOOSTER", "Real Android memory information + app-owned cleanup");
        c.addView(deviceMetric("FREE RAM", formatGB(DeviceInfo.ramFreeBytes(this)), GREEN));
        c.addView(deviceMetric("TOTAL RAM", formatGB(DeviceInfo.ramTotalBytes(this)), CYAN));
        Button scan = btn("🔍  SCAN RAM", GREEN); scan.setTextColor(Color.BLACK);
        c.addView(scan, new LinearLayout.LayoutParams(-1, 58));
        scan.setOnClickListener(v -> { beep(2); Toast.makeText(this, DeviceInfo.memorySummary(this), Toast.LENGTH_LONG).show(); });
        Button boost = btn("⚡  BOOST / CLEAN APP CACHE", GREEN2); boost.setTextColor(Color.BLACK);
        c.addView(boost, new LinearLayout.LayoutParams(-1, 58));
        boost.setOnClickListener(v -> runAnim("BOOSTING PERFORMANCE", () -> { System.gc(); trimMemory(); clearCache(getCacheDir()); if(getExternalCacheDir()!=null) clearCache(getExternalCacheDir()); }));
        content.addView(c);
        content.addView(neonInfo("ANDROID LIMIT", "Normal apps cannot force-free other apps RAM or change CPU frequency. This page only uses permitted app-owned cleanup and real Android telemetry."));
    }

    private void stableCleanPage() {
        LinearLayout c = neonCard("🧹 STORAGE CLEANER", "Scan and clean files owned by this optimizer");
        c.addView(deviceMetric("STORAGE USED", formatGB(DeviceInfo.storageTotalBytes(this) - DeviceInfo.storageFreeBytes(this)), RED));
        c.addView(deviceMetric("STORAGE FREE", formatGB(DeviceInfo.storageFreeBytes(this)), CYAN));
        Button scan = btn("🔍  SCAN STORAGE", GREEN); scan.setTextColor(Color.BLACK);
        c.addView(scan, new LinearLayout.LayoutParams(-1, 58));
        scan.setOnClickListener(v -> { beep(2); Toast.makeText(this, DeviceInfo.storageSummary(this), Toast.LENGTH_LONG).show(); });
        Button clean = btn("🧹  CLEAN OPTIMIZER CACHE", GREEN2); clean.setTextColor(Color.BLACK);
        c.addView(clean, new LinearLayout.LayoutParams(-1, 58));
        clean.setOnClickListener(v -> runAnim("CLEANING OPTIMIZER FILES", () -> { clearCache(getCacheDir()); if(getExternalCacheDir()!=null) clearCache(getExternalCacheDir()); }));
        Button settings = btn("⚙  ANDROID STORAGE SETTINGS", Color.rgb(45, 15, 22)); settings.setTextColor(Color.WHITE);
        c.addView(settings, new LinearLayout.LayoutParams(-1, 58));
        settings.setOnClickListener(v -> { try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); } catch(Exception e){ startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
        content.addView(c);
    }

    private void stableGamingPage() {
        content.addView(neonInfo("🎮 GAME CENTER", "Safe pre-launch cleanup followed by launching an installed game. No game-file injection or modification."));
        addStableGame("FREE FIRE", "com.dts.freefireth");
        addStableGame("FREE FIRE MAX", "com.dts.freefiremax");
        addSensitivityCard();
        addHeadshotTrainingCard();
    }

    private void addSensitivityCard() {
        LinearLayout c = neonCard("🎯 DEVICE MATCHED SENSITIVITY", "Recommended starting profile based on this phone's touch/FPS class");
        String model = (android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL).toLowerCase(Locale.US);
        int general = 190, red = 185, twoX = 175, fourX = 160, sniper = 95, free = 170, dpi = 474, fire = 48;
        if (model.contains("tecno") || model.contains("spark")) {
            general = 190; red = 185; twoX = 175; fourX = 160; sniper = 95; free = 170; dpi = 474; fire = 48;
        }
        addDetailRow(c, "PROFILE", "SMOOTH DRAG • DEVICE MATCHED", GREEN);
        addDetailRow(c, "GENERAL", String.valueOf(general), GREEN);
        addDetailRow(c, "RED DOT", String.valueOf(red), CYAN);
        addDetailRow(c, "2X SCOPE", String.valueOf(twoX), GREEN2);
        addDetailRow(c, "4X SCOPE", String.valueOf(fourX), PURPLE);
        addDetailRow(c, "SNIPER", String.valueOf(sniper), RED);
        addDetailRow(c, "FREE LOOK", String.valueOf(free), CYAN);
        addDetailRow(c, "DPI / FIRE BUTTON", dpi + " / " + fire + "%", GREEN);
        TextView note = tv("Use these as a starting point. Actual headshot consistency still depends on your drag timing and the game's own settings.", 10, MUTED);
        c.addView(note);
        content.addView(c);
    }

    private void addHeadshotTrainingCard() {
        LinearLayout c = neonCard("🎯 HEADSHOT TRAINING", "Practice drag timing and target tracking inside SADEE X DIMA");
        TextView stats = tv("HITS: 0    HEADSHOTS: 0    ACCURACY: 0%", 12, Color.WHITE);
        stats.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        c.addView(stats);

        Button start = btn("🎯  START 30s HEADSHOT TRAINING", GREEN);
        start.setTextColor(Color.BLACK);
        c.addView(start, new LinearLayout.LayoutParams(-1, 58));

        FrameLayout arena = new FrameLayout(this);
        arena.setBackground(makeBg(Color.rgb(6, 6, 9), 16, GREEN2));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, 300);
        ap.setMargins(0, 8, 0, 8);
        c.addView(arena, ap);

        TextView target = bigText("🎯", 38, Color.WHITE);
        target.setBackground(makeBg(Color.rgb(35, 8, 16), 60, RED));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(78, 78);
        tp.leftMargin = 40; tp.topMargin = 80;
        arena.addView(target, tp);

        TextView timer = tv("READY • 30s", 11, GREEN);
        timer.setGravity(Gravity.CENTER);
        c.addView(timer);

        final int[] hits = {0};
        final int[] headshots = {0};
        final long[] endAt = {0};
        final Random rnd = new Random();
        final boolean[] running = {false};
        final Handler trainingHandler = new Handler(Looper.getMainLooper());

        target.setOnClickListener(v -> {
            if (!running[0]) return;
            hits[0]++;
            headshots[0]++;
            beep(1);
            try { ((android.os.Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(45); } catch (Exception ignored) {}
            int maxX = Math.max(1, arena.getWidth() - 90);
            int maxY = Math.max(1, arena.getHeight() - 90);
            tp.leftMargin = rnd.nextInt(maxX);
            tp.topMargin = rnd.nextInt(maxY);
            target.setLayoutParams(tp);
            int accuracy = hits[0] == 0 ? 0 : Math.round(headshots[0] * 100f / hits[0]);
            stats.setText("HITS: " + hits[0] + "    HEADSHOTS: " + headshots[0] + "    ACCURACY: " + accuracy + "%");
        });

        start.setOnClickListener(v -> {
            if (running[0]) return;
            hits[0] = 0; headshots[0] = 0; running[0] = true;
            endAt[0] = System.currentTimeMillis() + 30000L;
            start.setEnabled(false);
            start.setText("🔥 TRAINING ACTIVE — TAP THE TARGET");
            beep(2);
            Runnable tick = new Runnable() {
                @Override public void run() {
                    if (!running[0]) return;
                    long left = endAt[0] - System.currentTimeMillis();
                    if (left <= 0) {
                        running[0] = false; start.setEnabled(true); start.setText("🎯  START 30s HEADSHOT TRAINING");
                        timer.setText("COMPLETE • HEADSHOTS: " + headshots[0]);
                        beep(3);
                        return;
                    }
                    timer.setText("TRAINING ACTIVE • " + ((left + 999) / 1000) + "s");
                    trainingHandler.postDelayed(this, 250);
                }
            };
            trainingHandler.post(tick);
        });
        content.addView(c);
        content.addView(neonInfo("SAFE MODE", "This training mode does not access, inject into, or modify Free Fire. It only measures your tap/drag practice inside the optimizer."));
    }

    private void addStableGame(String name, String pkg) {
        LinearLayout c = neonCard(name, isInstalled(pkg) ? "🟢 INSTALLED • READY" : "🔴 NOT INSTALLED");
        Button play = btn(isInstalled(pkg) ? "▶  BOOST + LAUNCH" : "NOT INSTALLED", isInstalled(pkg) ? GREEN : Color.rgb(55, 18, 25));
        play.setTextColor(isInstalled(pkg) ? Color.BLACK : Color.LTGRAY);
        c.addView(play, new LinearLayout.LayoutParams(-1, 58));
        play.setOnClickListener(v -> runGameBooster(name, pkg));
        content.addView(c);
    }

    private void stableMorePage() {
        LinearLayout c = neonCard("📱 DEVICE DETAILS", "Live information from Android APIs");
        addDetailRow(c, "DEVICE NAME", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL, GREEN);
        addDetailRow(c, "MANUFACTURER", android.os.Build.MANUFACTURER, RED);
        addDetailRow(c, "MODEL", android.os.Build.MODEL, CYAN);
        addDetailRow(c, "ANDROID", "Android " + android.os.Build.VERSION.RELEASE + " • SDK " + android.os.Build.VERSION.SDK_INT, GREEN2);
        addDetailRow(c, "CPU", Runtime.getRuntime().availableProcessors() + " CORES", PURPLE);
        addDetailRow(c, "BOARD", android.os.Build.BOARD, RED);
        addDetailRow(c, "PRODUCT", android.os.Build.PRODUCT, CYAN);
        addDetailRow(c, "RAM", formatGB(DeviceInfo.ramFreeBytes(this)) + " free / " + formatGB(DeviceInfo.ramTotalBytes(this)) + " total", GREEN);
        addDetailRow(c, "STORAGE", formatGB(DeviceInfo.storageTotalBytes(this) - DeviceInfo.storageFreeBytes(this)) + " used / " + formatGB(DeviceInfo.storageTotalBytes(this)) + " total", CYAN);
        addDetailRow(c, "BATTERY", DeviceInfo.batteryPercent(this) + "%", Color.rgb(255,190,80));
        content.addView(c);

        LinearLayout l = neonCard("🔐 LICENSE SESSION", "Auto-login is enabled for this device");
        addDetailRow(l, "LICENSE", licenseKey, GREEN);
        addDetailRow(l, "PLAN", license == null ? "ACTIVE" : license.optString("plan", "ACTIVE"), CYAN);
        addDetailRow(l, "STATUS", "VERIFIED • DEVICE BOUND", GREEN);
        Button logout = btn("⎋  LOGOUT / CHANGE LICENSE", Color.rgb(55, 18, 25)); logout.setTextColor(Color.WHITE);
        l.addView(logout, new LinearLayout.LayoutParams(-1, 58));
        logout.setOnClickListener(v -> { clearSession(); showLogin(); });
        content.addView(l);
    }

    private TextView deviceMetric(String label, String value, int color) {
        TextView t = tv(label + "\n" + value, 14, Color.WHITE);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setPadding(12, 12, 12, 12);
        t.setBackground(makeBg(Color.rgb(7, 7, 10), 12, color));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 5, 0, 6);
        t.setLayoutParams(lp);
        return t;
    }

    private void addDetailRow(LinearLayout parent, String label, String value, int color) {
        TextView t = tv(label + "\n" + (value == null || value.trim().isEmpty() ? "--" : value), 12, Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(12, 10, 12, 10);
        t.setBackground(makeBg(Color.rgb(8, 7, 10), 11, color));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 3, 0, 5);
        parent.addView(t, lp);
    }

    private LinearLayout neonInfo(String title, String body) {
        LinearLayout c = neonCard(title, body);
        return c;
    }

    private void showSimpleErrorPage(Exception e) {
        content.removeAllViews();
        addHero("SADEE OPTIMIZER", "PAGE READY", "!");
        LinearLayout c = neonCard("PAGE ERROR", "The page could not be loaded.");
        c.addView(tv("Try another tab. If the problem continues, restart the app.", 13, MUTED));
        Button reload = btn("↻  RELOAD", GREEN); reload.setTextColor(Color.BLACK);
        c.addView(reload, new LinearLayout.LayoutParams(-1, 58));
        reload.setOnClickListener(v -> showPage(currentPage));
        content.addView(c);
    }

    private void dashboardPage() {
        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(2,16,2,8);
        TextView h=tv("LIVE DASHBOARD",22,Color.WHITE); h.setTypeface(Typeface.DEFAULT_BOLD); head.addView(h);
        TextView s=tv("REAL DEVICE DATA • NEON CONTROL CENTER",11,MUTED); head.addView(s); content.addView(head);

        LinearLayout health=card(); health.setPadding(18,16,18,16);
        TextView lab=tv("REAL PERFORMANCE HEALTH",11,MUTED); lab.setTypeface(Typeface.DEFAULT_BOLD); health.addView(lab);
        TextView score=tv("--",42,GREEN); score.setTypeface(Typeface.DEFAULT_BOLD); health.addView(score);
        TextView note=tv("Health score from RAM, storage, battery and thermal state.",11,MUTED); health.addView(note);
        Button refresh=btn("⚡  REFRESH / OPTIMIZE SCAN",GREEN); refresh.setTextSize(15); refresh.setTextColor(Color.BLACK); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,64); rp.setMargins(0,12,0,0); health.addView(refresh,rp); content.addView(health);

        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout c1=metricBox("RAM","--",GREEN); LinearLayout c2=metricBox("STORAGE","--",CYAN); LinearLayout c3=metricBox("BATTERY","--",Color.rgb(255,190,80)); LinearLayout c4=metricBox("DEVICE NAME",android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL,Color.WHITE);
        grid.addView(c1,new LinearLayout.LayoutParams(0,108,1)); grid.addView(c2,new LinearLayout.LayoutParams(0,108,1)); content.addView(grid);
        LinearLayout grid2=new LinearLayout(this); grid2.setOrientation(LinearLayout.HORIZONTAL); grid2.addView(c3,new LinearLayout.LayoutParams(0,108,1)); grid2.addView(c4,new LinearLayout.LayoutParams(0,108,1)); content.addView(grid2);

        LinearLayout details=card(); details.setPadding(10,10,10,10);
        TextView dh=tv("📱 LIVE DEVICE DETAILS",14,GREEN); dh.setTypeface(Typeface.DEFAULT_BOLD); details.addView(dh);
        LinearLayout drow1=new LinearLayout(this); drow1.setOrientation(LinearLayout.HORIZONTAL);
        drow1.addView(metricBox("MANUFACTURER",android.os.Build.MANUFACTURER,RED),new LinearLayout.LayoutParams(0,82,1));
        drow1.addView(metricBox("MODEL",android.os.Build.MODEL,Color.rgb(255,120,150)),new LinearLayout.LayoutParams(0,82,1)); details.addView(drow1);
        LinearLayout drow2=new LinearLayout(this); drow2.setOrientation(LinearLayout.HORIZONTAL);
        drow2.addView(metricBox("ANDROID","Android "+android.os.Build.VERSION.RELEASE,RED),new LinearLayout.LayoutParams(0,82,1));
        drow2.addView(metricBox("CPU",Runtime.getRuntime().availableProcessors()+" CORES",CYAN),new LinearLayout.LayoutParams(0,82,1)); details.addView(drow2);
        LinearLayout drow3=new LinearLayout(this); drow3.setOrientation(LinearLayout.HORIZONTAL);
        drow3.addView(metricBox("BOARD",android.os.Build.BOARD,RED),new LinearLayout.LayoutParams(0,82,1));
        drow3.addView(metricBox("PRODUCT",android.os.Build.PRODUCT,CYAN),new LinearLayout.LayoutParams(0,82,1)); details.addView(drow3);
        content.addView(details);

        LinearLayout live=card(); TextView lh=tv("LIVE STATUS",11,MUTED); lh.setTypeface(Typeface.DEFAULT_BOLD); live.addView(lh); TextView ls=tv("Monitoring active",18,GREEN); ls.setTypeface(Typeface.DEFAULT_BOLD); live.addView(ls); TextView lb=tv("RAM, storage, battery, network and Android telemetry are read from system APIs. No root access is required.",11,MUTED); live.addView(lb); content.addView(live);

        Runnable refreshData = () -> {
            try {
                long rf=DeviceInfo.ramFreeBytes(this), rt=DeviceInfo.ramTotalBytes(this);
                long sf=DeviceInfo.storageFreeBytes(this), st=DeviceInfo.storageTotalBytes(this);
                int bat=DeviceInfo.batteryPercent(this);
                c1.getChildAt(1); ((TextView)c1.getChildAt(1)).setText(formatGB(rf)+"\nfree / "+formatGB(rt)+" total");
                ((TextView)c2.getChildAt(1)).setText(formatGB(st-sf)+"\nused / "+formatGB(st)+" total");
                ((TextView)c3.getChildAt(1)).setText(bat+"%");
                int ramScore=rt>0?(int)(rf*100/rt):0; int storageScore=st>0?(int)(sf*100/st):0; int scoreVal=Math.max(1,Math.min(99,(ramScore+storageScore+bat)/3)); score.setText(String.valueOf(scoreVal));
            } catch(Exception ignored){}
        };
        refresh.setOnClickListener(v->{beep(2);refreshData.run();Toast.makeText(this,"LIVE TELEMETRY REFRESHED",Toast.LENGTH_SHORT).show();});
        refreshData.run();
        handler.postDelayed(new Runnable(){public void run(){if(currentPage==0&&!isFinishing()){refreshData.run();handler.postDelayed(this,1500);}}},1500);
    }

    private LinearLayout metricBox(String label,String value,int color){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(10,9,10,8); c.setBackground(makeBg(Color.rgb(10,7,10),14,color)); TextView a=tv(label,9,color); a.setTypeface(Typeface.DEFAULT_BOLD); c.addView(a); TextView b=tv(value,14,Color.WHITE); b.setTypeface(Typeface.DEFAULT_BOLD); b.setMaxLines(2); b.setEllipsize(android.text.TextUtils.TruncateAt.END); c.addView(b); return c; }
    private String formatGB(long bytes){return String.format(Locale.US,"%.2f GB",bytes/1073741824.0);} 

    private void devicePage() {
        LinearLayout card = card();
        TextView info = tv("", 14, Color.WHITE); info.setTypeface(Typeface.MONOSPACE); card.addView(info);
        Runnable refresh = () -> info.setText(DeviceInfo.get(this)); refresh.run();
        handler.postDelayed(new Runnable() { @Override public void run() { if (currentPage == 4 && !isFinishing()) { refresh.run(); handler.postDelayed(this, 1500); } } }, 1500);
        content.addView(card);
        content.addView(section("📊 LIVE MONITOR", CYAN));
        content.addView(tv("RAM • STORAGE • NETWORK • BATTERY values refresh automatically.", 12, MUTED));
    }

    private void ramPage() {
        content.addView(infoCard("🧠 RAM BOOSTER", "Scan memory, release this app's unused memory and clear optimizer cache safely."));
        addAction("🧠 RAM SCAN", () -> runAnim("SCANNING MEMORY", () -> Toast.makeText(this, DeviceInfo.memorySummary(this), Toast.LENGTH_SHORT).show()));
        addAction("🚀 RAM BOOSTER", () -> runAnim("BOOSTING PERFORMANCE", () -> { System.gc(); trimMemory(); }));
        addAction("🧹 RAM CACHE CLEANER", () -> runAnim("CLEARING OPTIMIZER CACHE", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        content.addView(infoCard("ANDROID SAFETY", "Normal Android apps cannot silently kill other apps or force-free system RAM. These actions use permitted app-owned cleanup only."));
    }

    private void trimMemory() { try { android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE); if (am != null) am.getMemoryInfo(new android.app.ActivityManager.MemoryInfo()); } catch (Exception ignored) {} }

    private void storagePage() {
        content.addView(infoCard("🧹 ALL FILE CLEANER", "Cleans files owned by SADEE X DIMA and opens Android's storage controls for protected files."));
        addAction("🔍 SCAN ALL ACCESSIBLE FILES", () -> runAnim("SCANNING ACCESSIBLE FILES", () -> Toast.makeText(this, DeviceInfo.storageSummary(this), Toast.LENGTH_LONG).show()));
        addAction("🧹 CLEAN OPTIMIZER FILES", () -> runAnim("CLEANING OPTIMIZER FILES", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        addAction("📂 MANAGE ALL FILES", this::openStorageAccess);
        addAction("⚙️ ANDROID STORAGE", () -> { try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
    }

    private void openStorageAccess() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            i.setData(Uri.parse("package:" + getPackageName())); startActivity(i);
        } catch (Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
    }

    private void gamePage() {
        content.addView(infoCard("🚀 GAME BOOSTER", "Pre-launch cleanup + memory refresh, then launch the selected game."));
        addGameCard("FREE FIRE", "com.dts.freefireth", "🔥");
        addGameCard("FREE FIRE MAX", "com.dts.freefiremax", "🔥");
        addAction("⚡ GAME BOOSTER → FREE FIRE", () -> runGameBooster("FREE FIRE", "com.dts.freefireth"));
        addAction("⚡ GAME BOOSTER → FREE FIRE MAX", () -> runGameBooster("FREE FIRE MAX", "com.dts.freefiremax"));
        content.addView(infoCard("GAME MODE", "SADEE X DIMA does not inject, modify, or cheat inside game files. It prepares the phone using safe Android operations and then launches the game."));
    }

    private void addGameCard(String name, String pkg, String emoji) {
        LinearLayout c = card();
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = tv(emoji, 35, Color.WHITE); row.addView(icon, new LinearLayout.LayoutParams(60, 60));
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        TextView n = tv(name, 18, Color.WHITE); n.setTypeface(null, Typeface.BOLD); texts.addView(n);
        TextView s = tv(isInstalled(pkg) ? "🟢 INSTALLED • READY" : "🔴 NOT INSTALLED", 11, isInstalled(pkg)?GREEN:RED); texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, 70, 1));
        Button b = btn("PLAY", GREEN); b.setTextSize(11); row.addView(b, new LinearLayout.LayoutParams(90, 52));
        b.setOnClickListener(v -> runGameBooster(name, pkg));
        c.addView(row); content.addView(c);
    }

    private boolean isInstalled(String pkg) { try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; } }

    private void runGameBooster(String name, String pkg) {
        beep(2);
        if (!isInstalled(pkg)) { Toast.makeText(this, name + " not installed", Toast.LENGTH_LONG).show(); return; }
        String[] steps = {"GAME BOOSTER STARTING", "REFRESHING MEMORY", "CLEARING OPTIMIZER CACHE", "PREPARING " + name, "LAUNCHING " + name};
        ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA • GAME BOOSTER"); d.setMessage(steps[0]); d.setIndeterminate(false); d.setMax(steps.length); d.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); d.setCancelable(false); d.show();
        final int[] i = {0};
        Runnable tick = new Runnable() { @Override public void run() {
            if (i[0] < steps.length) { d.setProgress(i[0] + 1); d.setMessage(steps[i[0]]); if(i[0] == 1) trimMemory(); if(i[0] == 2){ clearCache(getCacheDir()); if(getExternalCacheDir()!=null) clearCache(getExternalCacheDir()); } i[0]++; handler.postDelayed(this, 550); }
            else { d.dismiss(); launchGame(pkg); }
        }};
        handler.post(tick);
    }

    private void launchGame(String pkg) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) { Toast.makeText(this, "GAME LAUNCHER NOT FOUND", Toast.LENGTH_LONG).show(); return; }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) { Toast.makeText(this, "GAME LAUNCH FAILED", Toast.LENGTH_LONG).show(); }
    }

    private void addAction(String label, Runnable r) {
        Button b = btn("  ⚡  " + label + "  ➜  ", Color.rgb(5, 28, 20));
        b.setTextColor(GREEN); b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setPadding(18, 4, 18, 4);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 58); lp.setMargins(0, 4, 0, 6);
        content.addView(b, lp); b.setOnClickListener(v -> { beep(1); r.run(); });
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(11, 11, 11, 11); c.setBackground(makeBg(CARD, 16, Color.rgb(105, 24, 40)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 5, 0, 8); c.setLayoutParams(lp); return c;
    }

    private LinearLayout infoCard(String title, String body) {
        LinearLayout c = card();
        TextView h = tv(title, 17, GREEN); h.setTypeface(null, Typeface.BOLD); c.addView(h);
        TextView b = tv(body, 12, MUTED); c.addView(b);
        content.addView(c); return c;
    }

    private void runAnim(String msg, Runnable done) {
        beep(2);
        ProgressDialog d = new ProgressDialog(this);
        d.setTitle("SADEE X DIMA // OPTIMIZER ENGINE");
        d.setMessage(">> " + msg + "...\n[████████░░]  SYSTEM OPERATION\n>> CHECKING PERMITTED ANDROID RESOURCES");
        d.setIndeterminate(true); d.setCancelable(false); d.show();
        handler.postDelayed(() -> {
            d.dismiss(); beep(2);
            Toast.makeText(this, "✓ " + msg + " COMPLETE", Toast.LENGTH_SHORT).show();
            done.run();
            try { ((android.os.Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(100); } catch (Exception ignored) {}
        }, 1400);
    }

    private void optimizePage() {
        content.addView(infoCard("⚡ SADEE X DIMA OPTIMIZED", "ONE TAP GAME MODE • FREE FIRE AUTO LAUNCH"));
        TextView log = tv("SYSTEM LOG\n> License verified\n> Device session online\n> Target game: FREE FIRE\n> READY", 13, Color.LTGRAY); log.setTypeface(Typeface.MONOSPACE); content.addView(log);
        Button b = btn("🔥  SADEE X DIMA OPTIMIZED  →  FREE FIRE", GREEN); content.addView(b, new LinearLayout.LayoutParams(-1, 64));
        b.setOnClickListener(v -> runOptimization(log));
        addAction("🔐 LOGOUT / CHANGE LICENSE", () -> { clearSession(); showLogin(); });
    }

    private void runOptimization(TextView log) {
        beep(2);
        if (!isInstalled("com.dts.freefireth")) {
            Toast.makeText(this, "FREE FIRE IS NOT INSTALLED", Toast.LENGTH_LONG).show();
            return;
        }
        String[] steps = {"Imported profile", "Scanning device", "Clearing optimizer cache", "Refreshing memory metrics", "Preparing FREE FIRE", "Launching FREE FIRE"};
        final int[] i = {0}; ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA // GAME MODE"); d.setMessage("Starting..."); d.setIndeterminate(false); d.setMax(steps.length); d.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); d.setCancelable(false); d.show();
        Runnable tick = new Runnable() { @Override public void run() {
            if (i[0] < steps.length) { d.setProgress(i[0] + 1); log.setText("SYSTEM LOG\n> " + steps[i[0]] + "\n> STATUS: RUNNING"); if(i[0]==2){clearCache(getCacheDir()); if(getExternalCacheDir()!=null)clearCache(getExternalCacheDir());} if(i[0]==3)trimMemory(); i[0]++; handler.postDelayed(this, 600); }
            else { d.dismiss(); beep(4); log.setText("SYSTEM LOG\n> SADEE X DIMA OPTIMIZED\n> STATUS: COMPLETE\n> GAME: FREE FIRE\n> LAUNCHING..."); Toast.makeText(MainActivity.this, "SADEE X DIMA OPTIMIZED • FREE FIRE", Toast.LENGTH_SHORT).show(); handler.postDelayed(() -> launchGame("com.dts.freefireth"), 250); }
        }}; handler.post(tick);
    }

    private void beep(int count) {
        try {
            if (tone == null) { try { tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85); } catch (Exception ignored) { return; } }
            final int[] n = {0};
            Runnable r = new Runnable() { @Override public void run() {
                if (n[0]++ < count) {
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 110);
                    handler.postDelayed(this, 150);
                }
            }};
            handler.post(r);
        } catch (Exception ignored) {}
    }

    private void clearCache(File f) { if (f == null) return; File[] fs = f.listFiles(); if (fs != null) for (File x : fs) { if (x.isDirectory()) clearCache(x); else x.delete(); } }
}
