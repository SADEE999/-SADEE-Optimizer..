# SADEE X DIMA OPTIMIZER • V3 UI

This package contains the Android optimizer UI, Supabase license validation, and an advanced responsive admin dashboard.

## Supabase
1. Open Supabase SQL Editor.
2. Run `supabase.sql`.
3. Create an admin account in Authentication → Users.
4. Run the final `insert into public.admin_users...` line from the SQL file with that account email.
5. Open the admin dashboard and sign in with that account.

The Android app only calls the `validate_license` RPC; it does not need direct table access.

## Admin
The admin dashboard requires Supabase Auth and an entry in `admin_users`. License create/update/delete operations are protected by RLS policies.

## Build
The repository workflow extracts the ZIP, enables AndroidX, uses Java 17 + Gradle 8.0, builds the debug APK, and publishes the admin dashboard to the `gh-pages` branch.
