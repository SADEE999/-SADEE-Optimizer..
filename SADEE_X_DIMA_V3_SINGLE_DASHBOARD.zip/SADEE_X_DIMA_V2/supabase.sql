-- SADEE X DIMA OPTIMIZER • SUPABASE SETUP / MIGRATION
-- Run this whole file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  license_key text unique not null,
  plan text not null default '7 Days',
  price_lkr integer,
  status text not null default 'unused',
  device_id text,
  activated_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

-- Existing projects may already have these columns. ADD IF NOT EXISTS keeps migration safe.
alter table public.licenses add column if not exists license_key text;
alter table public.licenses add column if not exists key text;
alter table public.licenses add column if not exists plan text;
alter table public.licenses add column if not exists price_lkr integer;
alter table public.licenses add column if not exists status text;
alter table public.licenses add column if not exists device_id text;
alter table public.licenses add column if not exists activated_at timestamptz;
alter table public.licenses add column if not exists expires_at timestamptz;
alter table public.licenses add column if not exists created_at timestamptz default now();

update public.licenses set license_key = key where (license_key is null or license_key='') and key is not null;
update public.licenses set key = license_key where (key is null or key='') and license_key is not null;
update public.licenses set plan = '7 Days' where plan is null or plan='';
update public.licenses set status = 'unused' where status is null or status='';

alter table public.licenses alter column status set default 'unused';
alter table public.licenses alter column plan set default '7 Days';
alter table public.licenses alter column created_at set default now();

alter table public.licenses drop constraint if exists licenses_status_check;
alter table public.licenses add constraint licenses_status_check check (lower(status) in ('unused','active','paused','expired'));

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.admin_users where user_id=auth.uid());
$$;

create or replace function public.validate_license(p_key text,p_device_id text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare r public.licenses;
begin
 select * into r from public.licenses where upper(coalesce(license_key,key))=upper(trim(p_key)) limit 1;
 if not found then return jsonb_build_object('valid',false,'message','License key not found.'); end if;
 if lower(r.status)='paused' then return jsonb_build_object('valid',false,'message','License is paused.'); end if;
 if r.expires_at is not null and r.expires_at < now() then update public.licenses set status='expired' where id=r.id; return jsonb_build_object('valid',false,'message','License has expired.'); end if;
 if r.device_id is not null and r.device_id <> p_device_id then return jsonb_build_object('valid',false,'message','License is already bound to another device.'); end if;
 if r.device_id is null then
   update public.licenses set status='active',device_id=p_device_id,activated_at=coalesce(activated_at,now()),expires_at=case when plan='7 Days' then coalesce(expires_at,now()+interval '7 days') when plan='1 Month' then coalesce(expires_at,now()+interval '30 days') else null end where id=r.id returning * into r;
 end if;
 return jsonb_build_object('valid',true,'message','License verified.','plan',r.plan,'expires_at',r.expires_at,'status',r.status);
end; $$;

alter table public.licenses enable row level security;
alter table public.admin_users enable row level security;
revoke all on public.licenses from anon,authenticated;
revoke all on public.admin_users from anon,authenticated;
grant execute on function public.validate_license(text,text) to anon,authenticated;
grant select,insert,update,delete on public.licenses to authenticated;
grant select on public.admin_users to authenticated;

drop policy if exists "admin read licenses" on public.licenses;
drop policy if exists "admin insert licenses" on public.licenses;
drop policy if exists "admin update licenses" on public.licenses;
drop policy if exists "admin delete licenses" on public.licenses;
create policy "admin read licenses" on public.licenses for select to authenticated using (public.is_admin());
create policy "admin insert licenses" on public.licenses for insert to authenticated with check (public.is_admin());
create policy "admin update licenses" on public.licenses for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin delete licenses" on public.licenses for delete to authenticated using (public.is_admin());

-- After creating an admin user in Authentication, link that account:
-- insert into public.admin_users(user_id,email) select id,email from auth.users where email='YOUR_ADMIN_EMAIL';
