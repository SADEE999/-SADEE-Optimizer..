package com.sadee.optimizer;
import android.os.*;import android.view.*;import android.widget.*;import androidx.annotation.*;import androidx.fragment.app.Fragment;
public class HistoryFragment extends Fragment{
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){
  View v=i.inflate(R.layout.fragment_history,c,false); TextView out=v.findViewById(R.id.historyText);
  android.content.SharedPreferences p=requireContext().getSharedPreferences("license",0);
  out.setText("LICENSE SESSION\n\nKey: "+p.getString("key","Not available")+"\nPlan: "+p.getString("plan","Unknown")+"\nExpiry: "+p.getString("expires_at","No expiry")+"\n\nDEVICE BINDING\nThis license is bound by the secure Supabase validation service.\n\nTip\nKeep your activation key private and do not share it with other devices.");
  return v;
 }
}
