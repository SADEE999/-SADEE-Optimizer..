package com.sadee.optimizer;

import android.app.ActivityManager;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.util.Locale;

/**
 * SADEE X DIMA dashboard.
 * The complete main dashboard UI is intentionally kept in this single Java file.
 */
public class MainActivity extends AppCompatActivity {
    private LinearLayout root, content;
    private FrameLayout frame;
    private ScrollView dashboardScroll;
    private TextView ram, cpu, battery, temp, storage, network, cores, refresh, health, licensePlan, licenseExpiry;
    private ProgressBar healthBar;
    private int green, cyan, purple, white, muted, bg, panel, line;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        green = getColorSafe(R.color.green); cyan = getColorSafe(R.color.cyan); purple = getColorSafe(R.color.purple);
        white = getColorSafe(R.color.white); muted = getColorSafe(R.color.muted); bg = getColorSafe(R.color.bg);
        panel = getColorSafe(R.color.panel); line = getColorSafe(R.color.line);
        buildDashboard();
    }

    private int getColorSafe(int id) { return ContextCompat.getColor(this, id); }

    private void buildDashboard() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        root.addView(header(), new LinearLayout.LayoutParams(-1, dp(76)));

        frame = new FrameLayout(this);
        frame.setId(View.generateViewId());
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        dashboardScroll = new ScrollView(this);
        dashboardScroll.setFillViewport(true);
        dashboardScroll.setBackgroundColor(bg);
        dashboardScroll.addView(content);
        frame.addView(dashboardScroll, new FrameLayout.LayoutParams(-1, -1));
        root.addView(frame, new LinearLayout.LayoutParams(-1, 0, 1));

        BottomNavigationView nav = createNav(frame.getId());
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(68)));
        setContentView(root);
        showHome();
    }

    private View header() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(18), dp(10), dp(18), dp(8));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_wordmark);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        h.addView(logo, new LinearLayout.LayoutParams(dp(105), dp(42)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(8), 0, 0, 0);
        TextView title = tv("SADEE X DIMA", 17, white, true);
        TextView sub = tv("PRO CYBER OPTIMIZER  //  ONLINE", 9, cyan, true);
        sub.setLetterSpacing(.10f);
        titleBox.addView(title);
        titleBox.addView(sub);
        h.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView dot = tv("●", 22, green, false);
        h.addView(dot);
        return h;
    }

    private BottomNavigationView createNav(int frameId) {
        BottomNavigationView nav = new BottomNavigationView(this);
        nav.setBackgroundColor(panel);
        nav.setLabelVisibilityMode(BottomNavigationView.LABEL_VISIBILITY_LABELED);
        nav.setItemIconTintList(null);
        nav.getMenu().add(0, 1, 0, "Home").setIcon(R.drawable.ic_home);
        nav.getMenu().add(0, 2, 1, "Performance").setIcon(R.drawable.ic_speed);
        nav.getMenu().add(0, 3, 2, "Cleaner").setIcon(R.drawable.ic_clean);
        nav.getMenu().add(0, 4, 3, "Gaming").setIcon(R.drawable.ic_game);
        nav.getMenu().add(0, 5, 4, "Device").setIcon(R.drawable.ic_device);
        nav.getMenu().add(0, 6, 5, "History").setIcon(R.drawable.ic_history);
        nav.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case 1: showHome(); break;
                case 2: showFragment(new Page1ScannerFragment()); break;
                case 3: showFragment(new Page2CleanerFragment()); break;
                case 4: showFragment(new Page5InjectorFragment()); break;
                case 5: showFragment(new Page4GfxFragment()); break;
                case 6: showFragment(new HistoryFragment()); break;
            }
            return true;
        });
        nav.setSelectedItemId(1);
        return nav;
    }

    private void showHome() {
        Fragment old = getSupportFragmentManager().findFragmentById(frame.getId());
        if (old != null) getSupportFragmentManager().beginTransaction().remove(old).commitAllowingStateLoss();
        dashboardScroll.setVisibility(View.VISIBLE);
        content.removeAllViews();
        content.addView(homeCard(), marginParams(16, 16, 16, 0));
        content.addView(metricsRow(), marginParams(16, 12, 16, 0));
        content.addView(metricsRow2(), marginParams(16, 10, 16, 0));
        content.addView(wideTelemetry(), marginParams(16, 10, 16, 0));
        content.addView(healthCard(), marginParams(16, 10, 16, 0));
        content.addView(licenseCard(), marginParams(16, 10, 16, 24));
        updateTelemetry();
    }

    private View homeCard() {
        LinearLayout c = card();
        TextView a = tv("▣  CYBER SYSTEM  //  REAL MODE", 16, green, true);
        TextView b = tv("Live device telemetry • safe optimization tools", 12, muted, false);
        c.addView(a); c.addView(b, marginParams(0, 5, 0, 0));
        Button refreshBtn = new Button(this);
        refreshBtn.setText("REFRESH SCAN"); refreshBtn.setTextColor(Color.rgb(0,16,21)); refreshBtn.setTextSize(12); refreshBtn.setAllCaps(false);
        refreshBtn.setBackground(round(green, 14));
        refreshBtn.setOnClickListener(v -> { updateTelemetry(); Toast.makeText(this, "System scan refreshed", Toast.LENGTH_SHORT).show(); });
        c.addView(refreshBtn, marginParams(0, 12, 0, 0));
        return c;
    }

    private LinearLayout metricsRow() {
        LinearLayout r = row();
        r.addView(metric("RAM", ram = metricValue()), new LinearLayout.LayoutParams(0, dp(96), 1));
        r.addView(metric("CPU", cpu = metricValue()), gapParams());
        r.addView(metric("CORES", cores = metricValue()), gapParams());
        return r;
    }

    private LinearLayout metricsRow2() {
        LinearLayout r = row();
        r.addView(metric("BATTERY", battery = metricValue()), new LinearLayout.LayoutParams(0, dp(96), 1));
        r.addView(metric("TEMP", temp = metricValue()), gapParams());
        r.addView(metric("STORAGE", storage = metricValue()), gapParams());
        return r;
    }

    private View metric(String label, TextView value) {
        LinearLayout c = card();
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.addView(tv(label, 10, muted, true));
        c.addView(value, marginParams(0, 7, 0, 0));
        return c;
    }

    private TextView metricValue() { return tv("--", 18, white, true); }

    private View wideTelemetry() {
        LinearLayout c = card();
        c.addView(tv("NETWORK MONITOR", 16, cyan, true));
        network = tv("OFFLINE", 18, white, true); c.addView(network, marginParams(0, 8, 0, 0));
        c.addView(tv("Connection status • live device network state", 11, muted, false), marginParams(0, 3, 0, 0));
        refresh = tv("60 Hz", 16, purple, true); c.addView(refresh, marginParams(0, 12, 0, 0));
        c.addView(tv("DISPLAY REFRESH", 10, muted, true));
        return c;
    }

    private View healthCard() {
        LinearLayout c = card();
        LinearLayout top = row();
        top.addView(tv("♥  PERFORMANCE HEALTH SCORE", 16, white, true), new LinearLayout.LayoutParams(0, -2, 1));
        health = tv("0%", 27, green, true); top.addView(health);
        c.addView(top);
        healthBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        healthBar.setMax(100); healthBar.setProgress(0); healthBar.setProgressTintList(android.content.res.ColorStateList.valueOf(green));
        c.addView(healthBar, marginParams(0, 12, 0, 0));
        return c;
    }

    private View licenseCard() {
        LinearLayout c = card();
        c.addView(tv("✓  LICENSE STATUS", 16, cyan, true));
        licensePlan = tv("LICENSED", 21, green, true); c.addView(licensePlan, marginParams(0, 8, 0, 0));
        licenseExpiry = tv("No expiry • Full access", 12, muted, false); c.addView(licenseExpiry, marginParams(0, 3, 0, 0));
        return c;
    }

    private void updateTelemetry() {
        if (ram == null) return;
        ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        long used = 0, total = 0;
        if (am != null) { ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); total = mi.totalMem; used = total - mi.availMem; }
        int ramPct = total > 0 ? (int)(used * 100 / total) : 0;
        ram.setText(ramPct + "%");
        cores.setText(String.valueOf(Runtime.getRuntime().availableProcessors()));
        cpu.setText("ACTIVE");

        Intent bs = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int bp = 0; float tc = 0;
        if (bs != null) { int l = bs.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), s = bs.getIntExtra(BatteryManager.EXTRA_SCALE, 100); bp = s > 0 ? l * 100 / s : 0; tc = bs.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f; }
        battery.setText(bp + "%"); temp.setText(String.format(Locale.US, "%.1f°C", tc));

        StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
        long totalBytes = sf.getBlockCountLong() * sf.getBlockSizeLong(), freeBytes = sf.getAvailableBlocksLong() * sf.getBlockSizeLong();
        int storagePct = totalBytes > 0 ? (int)((totalBytes - freeBytes) * 100 / totalBytes) : 0;
        storage.setText(storagePct + "%");

        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        Network n = Build.VERSION.SDK_INT >= 23 && cm != null ? cm.getActiveNetwork() : null;
        network.setText(n != null ? "ONLINE" : "OFFLINE");
        refresh.setText("60 Hz");

        int score = Math.max(0, Math.min(100, 100 - ramPct / 2));
        health.setText(score + "%"); healthBar.setProgress(score);
        SharedPreferences p = getSharedPreferences("license", MODE_PRIVATE);
        licensePlan.setText(p.getString("plan", "LICENSED"));
        licenseExpiry.setText(p.getString("expires_at", "No expiry • Full access"));
    }

    private void showFragment(Fragment f) {
        dashboardScroll.setVisibility(View.GONE);
        getSupportFragmentManager().beginTransaction().setReorderingAllowed(true)
                .add(frame.getId(), f).commit();
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(18), dp(16), dp(18), dp(16)); c.setBackground(round(panel, 20)); return c;
    }
    private LinearLayout row() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r; }
    private TextView tv(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(null, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL); return t; }
    private GradientDrawable round(int color, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); g.setStroke(dp(1), line); return g; }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private LinearLayout.LayoutParams marginParams(int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(dp(l),dp(t),dp(r),dp(b)); return p; }
    private LinearLayout.LayoutParams gapParams(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(96),1); p.setMargins(dp(5),0,0,0); return p; }

    @Override protected void onResume() {
        super.onResume();
        if (getSharedPreferences("license", MODE_PRIVATE).getString("key", "").isEmpty()) finish();
    }
}
