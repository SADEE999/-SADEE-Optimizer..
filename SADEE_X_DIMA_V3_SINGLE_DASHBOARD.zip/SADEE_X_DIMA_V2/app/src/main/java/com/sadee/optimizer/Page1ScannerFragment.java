package com.sadee.optimizer;
import android.app.ActivityManager;import android.content.*;import android.net.*;import android.os.*;import android.view.*;import android.widget.TextView;import androidx.annotation.*;import androidx.fragment.app.Fragment;
public class Page1ScannerFragment extends Fragment{
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){
  View v=i.inflate(R.layout.fragment_page1,c,false); TextView out=v.findViewById(R.id.txtScanResult); Context x=requireContext(); StringBuilder s=new StringBuilder();
  s.append("DEVICE\n").append(Build.MANUFACTURER.toUpperCase()).append(" ").append(Build.MODEL).append("\nAndroid ").append(Build.VERSION.RELEASE).append(" • API ").append(Build.VERSION.SDK_INT).append("\n\n");
  s.append("CPU\nArchitecture: ").append(System.getProperty("os.arch")).append("\nCores: ").append(Runtime.getRuntime().availableProcessors()).append("\n\n");
  ActivityManager am=(ActivityManager)x.getSystemService(Context.ACTIVITY_SERVICE); ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); if(am!=null){am.getMemoryInfo(mi); long t=mi.totalMem/1048576,f=mi.availMem/1048576;s.append("RAM\nTotal: ").append(t).append(" MB\nFree: ").append(f).append(" MB\nUsed: ").append(t-f).append(" MB\n\n");}
  Intent bs=x.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); if(bs!=null){int l=bs.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),sc=bs.getIntExtra(BatteryManager.EXTRA_SCALE,100);s.append("BATTERY\nLevel: ").append((l*100)/sc).append("%\nTemperature: ").append(bs.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0)/10.0).append(" °C\n\n");}
  ConnectivityManager cm=(ConnectivityManager)x.getSystemService(Context.CONNECTIVITY_SERVICE);Network n=Build.VERSION.SDK_INT>=23&&cm!=null?cm.getActiveNetwork():null;s.append("NETWORK\nStatus: ").append(n!=null?"CONNECTED":"OFFLINE").append("\n");out.setText(s.toString());return v;
 }
}
