package com.sadee.optimizer;
import android.app.ActivityManager;import android.content.*;import android.os.*;import android.view.*;import android.widget.*;import androidx.annotation.*;import androidx.fragment.app.Fragment;
public class Page2CleanerFragment extends Fragment{
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){View v=i.inflate(R.layout.fragment_page2,c,false);TextView st=v.findViewById(R.id.txtCleanStatus);Button go=v.findViewById(R.id.btnCleanRam);go.setOnClickListener(z->{System.gc();ActivityManager am=(ActivityManager)requireContext().getSystemService(Context.ACTIVITY_SERVICE);if(am!=null)am.killBackgroundProcesses(requireContext().getPackageName());st.setText("CLEAN PASS COMPLETE\n\nApp memory cleanup requested.\nAndroid remains in control of system-wide memory.");Toast.makeText(getContext(),"Optimization pass complete",Toast.LENGTH_SHORT).show();});return v;}
}
