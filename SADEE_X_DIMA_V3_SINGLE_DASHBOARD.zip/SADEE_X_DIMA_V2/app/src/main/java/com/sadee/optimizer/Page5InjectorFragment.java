package com.sadee.optimizer;
import android.content.*;import android.view.*;import android.widget.*;import androidx.annotation.*;import androidx.fragment.app.Fragment;
public class Page5InjectorFragment extends Fragment{
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){View v=i.inflate(R.layout.fragment_page5,c,false);Button go=v.findViewById(R.id.btnInjector);TextView st=v.findViewById(R.id.txtGameStatus);go.setOnClickListener(x->{String[] pkgs={"com.dts.freefireth","com.dts.freefiremax"};Intent launch=null;for(String pkg:pkgs){launch=requireContext().getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null)break;}if(launch!=null){st.setText("GAME READY\nLaunching installed game…");startActivity(launch);}else st.setText("No supported Free Fire package was found.\nInstall the game first, then try again.");});return v;}
}
