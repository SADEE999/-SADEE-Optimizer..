package com.sadee.optimizer;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONObject;

import java.io.File;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(0, 255, 128);
    private static final int GREEN2 = Color.rgb(0, 235, 135);
    private static final int CYAN = Color.rgb(30, 220, 255);
    private static final int PURPLE = Color.rgb(178, 105, 255);
    private static final int RED = Color.rgb(255, 85, 105);
    private static final int BG = Color.rgb(1, 5, 6);
    private static final int CARD = Color.rgb(5, 15, 13);
    private static final int CARD2 = Color.rgb(7, 22, 18);
    private static final int MUTED = Color.rgb(135, 153, 151);

    private LinearLayout root, content, nav;
    private TextView licenseTimer, topTitle;
    private JSONObject license;
    private String licenseKey = "";
    private String selectedPlan = "7 DAYS";
    private ToneGenerator tone;
    private int currentPage = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String[] pageNames = {"HOME", "BOOST", "CLEAN", "GAMING", "MORE"};
    private SharedPreferences sessionPrefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        try { tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85); } catch (Exception ignored) { tone = null; }
        sessionPrefs = getSharedPreferences("sadee_secure_session", MODE_PRIVATE);
        tryAutoLogin();
    }

    private TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(12, 8, 12, 8);
        return t;
    }

    private TextView bigText(String s, float size, int color) {
        TextView t = tv(s, size, color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.BLACK); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false);
        b.setBackground(makeBg(color, 16, color)); b.setPadding(12, 4, 12, 4);
        return b;
    }

    private GradientDrawable makeBg(int fill, float radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(radius);
        g.setStroke(1, stroke);
        return g;
    }

    private TextView section(String s, int color) {
        TextView t = tv(s, 19, color);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(4, 18, 4, 10);
        return t;
    }

    private void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16, 12, 16, 28);
        sv.addView(content); root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setPadding(5, 5, 5, 5); nav.setBackgroundColor(Color.rgb(6, 14, 14));
        root.addView(nav, new LinearLayout.LayoutParams(-1, 68));
        setContentView(root);
    }

    private ImageView logo() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.sadee_logo); image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        return image;
    }

    private void addHero(String title, String subtitle, String emoji) {
        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(14,12,14,14);
        hero.setBackground(makeBg(Color.rgb(3,12,10),24,GREEN));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView mini=logo(); mini.setBackground(makeBg(Color.rgb(1,8,7),22,GREEN2)); row.addView(mini,new LinearLayout.LayoutParams(74,74));
        LinearLayout tt=new LinearLayout(this); tt.setOrientation(LinearLayout.VERTICAL); tt.setPadding(12,0,0,0);
        TextView h=tv(title,23,Color.WHITE); h.setTypeface(Typeface.DEFAULT_BOLD); tt.addView(h);
        TextView s=tv(subtitle,11,GREEN); s.setTypeface(Typeface.DEFAULT_BOLD); tt.addView(s);
        row.addView(tt,new LinearLayout.LayoutParams(0,76,1));
        TextView ic=bigText(emoji,32,CYAN); row.addView(ic,new LinearLayout.LayoutParams(58,76));
        hero.addView(row); content.addView(hero,new LinearLayout.LayoutParams(-1,-2));
    }

    private void tryAutoLogin() {
        final String savedKey = sessionPrefs == null ? "" : sessionPrefs.getString("license_key", "");
        final String cached = sessionPrefs == null ? "" : sessionPrefs.getString("license_json", "");
        if (savedKey.trim().isEmpty()) { showLogin(); return; }

        showSessionLoading();
        new Thread(() -> {
            try {
                String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                JSONObject fresh = Supabase.verifyAndBind(savedKey, device, this);
                license = fresh; licenseKey = savedKey;
                saveSession(savedKey, fresh);
                runOnUiThread(() -> showApp());
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "" : e.getMessage();
                boolean hardFail = msg.contains("INVALID LICENSE") || msg.contains("LICENSE EXPIRED") || msg.contains("LICENSE PAUSED") || msg.contains("ANOTHER DEVICE");
                if (!hardFail && !cached.trim().isEmpty()) {
                    try {
                        JSONObject old = new JSONObject(cached);
                        String cachedExp = old.optString("expires_at", "");
                        if (!expiredLocal(cachedExp)) {
                            license = old; licenseKey = savedKey;
                            runOnUiThread(() -> showApp());
                            return;
                        }
                    } catch (Exception ignored) {}
                }
                clearSession();
                runOnUiThread(this::showLogin);
            }
        }).start();
    }

    private void showSessionLoading() {
        base();
        ImageView im = logo(); content.addView(im, new LinearLayout.LayoutParams(-1,220));
        TextView h = bigText("SADEE OPTIMIZER", 30, Color.WHITE); content.addView(h);
        TextView s = bigText("RESTORING SECURE SESSION", 15, GREEN); content.addView(s);
        TextView p = bigText("● LICENSE • DEVICE • CLOUD CHECK", 11, MUTED); content.addView(p);
    }

    private void saveSession(String key, JSONObject obj) {
        if (sessionPrefs == null) return;
        sessionPrefs.edit().putString("license_key", key).putString("license_json", obj == null ? "" : obj.toString()).apply();
    }

    private void clearSession() {
        if (sessionPrefs != null) sessionPrefs.edit().clear().apply();
        license = null; licenseKey = "";
    }

    private void showLogin() {
        base();
        content.addView(logo(), new LinearLayout.LayoutParams(-1, 190));
        TextView h = tv("SADEE X DIMA", 34, Color.WHITE); h.setGravity(Gravity.CENTER); h.setTypeface(null, Typeface.BOLD); content.addView(h);
        TextView sub = tv("O P T I M I Z E R", 24, GREEN); sub.setGravity(Gravity.CENTER); sub.setTypeface(null, Typeface.BOLD); content.addView(sub);
        TextView tag = tv("// SECURE GAMING LICENSE //", 11, MUTED); tag.setGravity(Gravity.CENTER); content.addView(tag);

        LinearLayout card = card();
        card.setPadding(16, 16, 16, 16);
        card.setBackground(makeBg(Color.rgb(7, 16, 15), 22, GREEN2));
        content.addView(card);
        TextView label = tv("● LICENSE ACCESS", 18, GREEN); label.setTypeface(null, Typeface.BOLD); card.addView(label);
        TextView hint = tv("Enter your key and select your plan", 12, MUTED); card.addView(hint);

        EditText key = new EditText(this);
        key.setSingleLine(true); key.setTextColor(Color.WHITE); key.setHintTextColor(MUTED);
        key.setTextSize(17); key.setHint("SXD-XXXX-XXXX-XXXX"); key.setPadding(16, 10, 16, 10);
        key.setBackground(makeBg(Color.rgb(3, 11, 10), 15, GREEN2));
        card.addView(key, new LinearLayout.LayoutParams(-1, 60));

        TextView planTitle = tv("SELECT PLAN", 14, CYAN); planTitle.setTypeface(null, Typeface.BOLD); card.addView(planTitle);
        LinearLayout plans = new LinearLayout(this); plans.setOrientation(LinearLayout.VERTICAL); card.addView(plans);

        TextView status = tv("READY • SELECT A PLAN", 13, MUTED); status.setGravity(Gravity.CENTER); card.addView(status);
        Button verify = btn("✓  VERIFY & UNLOCK", GREEN); verify.setTextColor(Color.BLACK); card.addView(verify, new LinearLayout.LayoutParams(-1, 60));

        final TextView[] selected = new TextView[1];
        String[][] choices = {{"7 DAYS", "LKR 500"}, {"1 MONTH", "LKR 1,000"}, {"LIFETIME", "LKR 2,200"}};
        for (String[] c : choices) {
            TextView p = tv("", 15, Color.WHITE); p.setGravity(Gravity.CENTER_VERTICAL); p.setTypeface(null, Typeface.BOLD);
            p.setPadding(18, 0, 18, 0);
            p.setText(c[0] + "                                      " + c[1]);
            p.setBackground(makeBg(Color.rgb(8, 22, 19), 15, Color.rgb(25, 70, 55)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 58); lp.setMargins(0, 6, 0, 0); plans.addView(p, lp);
            p.setOnClickListener(v -> {
                selectedPlan = c[0];
                if (selected[0] != null) selected[0].setBackground(makeBg(Color.rgb(8, 22, 19), 15, Color.rgb(25, 70, 55)));
                p.setBackground(makeBg(Color.rgb(2, 42, 28), 15, GREEN));
                selected[0] = p;
                status.setText("SELECTED • " + selectedPlan);
                beep(1);
            });
        }
        ((TextView) plans.getChildAt(0)).performClick();

        verify.setOnClickListener(v -> {
            String k = key.getText().toString().trim().toUpperCase(Locale.US);
            if (k.isEmpty()) { status.setText("ENTER A LICENSE KEY"); beep(2); return; }
            verify.setEnabled(false); status.setText("● VERIFYING LICENSE • PLEASE WAIT"); beep(1);
            new Thread(() -> {
                try {
                    String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    license = Supabase.verifyAndBind(k, device, this);
                    licenseKey = k;
                    saveSession(k, license);
                    runOnUiThread(() -> { beep(3); showApp(); });
                } catch (Exception e) {
                    runOnUiThread(() -> { verify.setEnabled(true); status.setText(e.getMessage() == null ? "VERIFY FAILED" : e.getMessage()); beep(2); });
                }
            }).start();
        });

        TextView foot = tv("1 LICENSE = 1 DEVICE • DEVICE BINDING + EXPIRY PROTECTION", 12, MUTED);
        foot.setGravity(Gravity.CENTER);
        content.addView(foot);
    }


    private void showApp() {
        base(); content.setPadding(12,10,12,22);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(2,0,2,4);
        ImageView li=logo(); top.addView(li,new LinearLayout.LayoutParams(68,68));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setPadding(8,0,0,0);
        topTitle=tv("SADEE OPTIMIZER",22,Color.WHITE); topTitle.setTypeface(Typeface.DEFAULT_BOLD); titles.addView(topTitle);
        TextView online=tv("● REAL ANDROID MONITOR",10,GREEN); online.setTypeface(Typeface.DEFAULT_BOLD); titles.addView(online);
        top.addView(titles,new LinearLayout.LayoutParams(0,68,1));
        TextView battery=bigText("●",18,GREEN); top.addView(battery,new LinearLayout.LayoutParams(30,60));
        content.addView(top);

        licenseTimer=bigText("",11,CYAN); licenseTimer.setBackground(makeBg(Color.rgb(3,30,22),18,GREEN2));
        content.addView(licenseTimer,new LinearLayout.LayoutParams(-1,48)); updateLicenseTimer();
        handler.postDelayed(new Runnable(){public void run(){if(!isFinishing()&&license!=null){updateLicenseTimer();handler.postDelayed(this,1000);}}},1000);

        showPage(0);
        String[] icons={"⌂","⚡","🧹","🎮","⋮"};
        for(int i=0;i<pageNames.length;i++){ final int p=i; Button b=btn(icons[i]+"\n"+pageNames[i],Color.rgb(4,13,12)); b.setTextSize(9); b.setTextColor(i==0?GREEN:Color.LTGRAY); b.setTypeface(Typeface.DEFAULT_BOLD); b.setPadding(2,2,2,2); nav.addView(b,new LinearLayout.LayoutParams(0,-1,1)); b.setOnClickListener(v->{showPage(p);for(int j=0;j<nav.getChildCount();j++)((Button)nav.getChildAt(j)).setTextColor(j==p?GREEN:Color.LTGRAY);}); }
    }

    private void updateLicenseTimer() {
        if (license == null || licenseTimer == null) return;
        String exp = license.optString("expires_at", "");
        String plan = license.optString("plan", "ACTIVE");
        licenseTimer.setText("🔑 " + licenseKey + "   •   " + plan.toUpperCase(Locale.US) + "   •   " + remaining(exp));
    }

    private String remaining(String exp) {
        if (exp == null || exp.trim().isEmpty() || "null".equalsIgnoreCase(exp)) return "LIFETIME • NO EXPIRY";
        Date d = parseDate(exp); if (d == null) return "TIME UNKNOWN";
        long ms = d.getTime() - System.currentTimeMillis(); if (ms <= 0) return "0h 0m REMAINING";
        long h = ms / 3600000L; long m = (ms % 3600000L) / 60000L;
        return h + "h " + m + "m REMAINING";
    }

    private boolean expiredLocal(String exp) {
        if (exp == null || exp.trim().isEmpty() || "null".equalsIgnoreCase(exp.trim())) return false;
        Date d = parseDate(exp); return d != null && d.getTime() <= System.currentTimeMillis();
    }

    private Date parseDate(String s) {
        String[] formats = {"yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String f : formats) { try { SimpleDateFormat df = new SimpleDateFormat(f, Locale.US); df.setTimeZone(TimeZone.getTimeZone("UTC")); Date d = df.parse(s, new ParsePosition(0)); if (d != null) return d; } catch (Exception ignored) {} }
        return null;
    }

    private void showPage(int p) {
        currentPage = p; content.removeAllViews();
        if (p == 0) { addHero("SADEE OPTIMIZER", "GAMING CORE • ONLINE", "⚡"); dashboardPage(); }
        else if (p == 1) { addHero("RAM BOOSTER", "MEMORY • PERFORMANCE • CLEANUP", "🧠"); ramPage(); }
        else if (p == 2) { addHero("ADVANCED CLEANER", "STORAGE • JUNK • SAFE CLEANUP", "🧹"); storagePage(); }
        else if (p == 3) { addHero("GAME CENTER", "GAME BOOSTER • FREE FIRE", "🎮"); gamePage(); }
        else { addHero("SADEE X DIMA", "OPTIMIZER CONTROL CENTER", "⚙"); optimizePage(); }
    }

    private void dashboardPage() {
        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(2,16,2,8);
        TextView h=tv("LIVE DASHBOARD",26,Color.WHITE); h.setTypeface(Typeface.DEFAULT_BOLD); head.addView(h);
        TextView s=tv("Monitor your phone before you launch a game",12,MUTED); head.addView(s); content.addView(head);

        LinearLayout health=card(); health.setPadding(18,16,18,16);
        TextView lab=tv("REAL PERFORMANCE HEALTH",11,MUTED); lab.setTypeface(Typeface.DEFAULT_BOLD); health.addView(lab);
        TextView score=tv("--",52,GREEN); score.setTypeface(Typeface.DEFAULT_BOLD); health.addView(score);
        TextView note=tv("Health score from RAM, storage, battery and thermal state.",11,MUTED); health.addView(note);
        Button refresh=btn("⚡  REFRESH / OPTIMIZE SCAN",GREEN); refresh.setTextSize(15); refresh.setTextColor(Color.BLACK); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,64); rp.setMargins(0,12,0,0); health.addView(refresh,rp); content.addView(health);

        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout c1=metricBox("RAM","--",GREEN); LinearLayout c2=metricBox("STORAGE","--",CYAN); LinearLayout c3=metricBox("BATTERY","--",Color.rgb(255,190,80)); LinearLayout c4=metricBox("DEVICE",DeviceInfo.model(this),Color.WHITE);
        grid.addView(c1,new LinearLayout.LayoutParams(0,130,1)); grid.addView(c2,new LinearLayout.LayoutParams(0,130,1)); content.addView(grid);
        LinearLayout grid2=new LinearLayout(this); grid2.setOrientation(LinearLayout.HORIZONTAL); grid2.addView(c3,new LinearLayout.LayoutParams(0,130,1)); grid2.addView(c4,new LinearLayout.LayoutParams(0,130,1)); content.addView(grid2);

        LinearLayout live=card(); TextView lh=tv("LIVE STATUS",11,MUTED); lh.setTypeface(Typeface.DEFAULT_BOLD); live.addView(lh); TextView ls=tv("Monitoring active",18,GREEN); ls.setTypeface(Typeface.DEFAULT_BOLD); live.addView(ls); TextView lb=tv("RAM, storage, battery, network and Android telemetry are read from system APIs. No root access is required.",11,MUTED); live.addView(lb); content.addView(live);

        Runnable refreshData = () -> {
            try {
                long rf=DeviceInfo.ramFreeBytes(this), rt=DeviceInfo.ramTotalBytes(this);
                long sf=DeviceInfo.storageFreeBytes(this), st=DeviceInfo.storageTotalBytes(this);
                int bat=DeviceInfo.batteryPercent(this);
                c1.getChildAt(1); ((TextView)c1.getChildAt(1)).setText(formatGB(rf)+"\nfree / "+formatGB(rt)+" total");
                ((TextView)c2.getChildAt(1)).setText(formatGB(st-sf)+"\nused / "+formatGB(st)+" total");
                ((TextView)c3.getChildAt(1)).setText(bat+"%");
                int ramScore=rt>0?(int)(rf*100/rt):0; int storageScore=st>0?(int)(sf*100/st):0; int scoreVal=Math.max(1,Math.min(99,(ramScore+storageScore+bat)/3)); score.setText(String.valueOf(scoreVal));
            } catch(Exception ignored){}
        };
        refresh.setOnClickListener(v->{beep(2);refreshData.run();Toast.makeText(this,"LIVE TELEMETRY REFRESHED",Toast.LENGTH_SHORT).show();});
        refreshData.run();
        handler.postDelayed(new Runnable(){public void run(){if(currentPage==0&&!isFinishing()){refreshData.run();handler.postDelayed(this,1500);}}},1500);
    }

    private LinearLayout metricBox(String label,String value,int color){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(12,12,12,10); c.setBackground(makeBg(Color.rgb(10,17,24),0,Color.rgb(17,35,45))); TextView a=tv(label,10,MUTED); a.setTypeface(Typeface.DEFAULT_BOLD); c.addView(a); TextView b=tv(value,16,color); b.setTypeface(Typeface.DEFAULT_BOLD); c.addView(b); return c; }
    private String formatGB(long bytes){return String.format(Locale.US,"%.2f GB",bytes/1073741824.0);} 

    private void devicePage() {
        LinearLayout card = card();
        TextView info = tv("", 14, Color.WHITE); info.setTypeface(Typeface.MONOSPACE); card.addView(info);
        Runnable refresh = () -> info.setText(DeviceInfo.get(this)); refresh.run();
        handler.postDelayed(new Runnable() { @Override public void run() { if (currentPage == 0 && !isFinishing()) { refresh.run(); handler.postDelayed(this, 1500); } } }, 1500);
        content.addView(card);
        content.addView(section("📊 LIVE MONITOR", CYAN));
        content.addView(tv("RAM • STORAGE • NETWORK • BATTERY values refresh automatically.", 12, MUTED));
    }

    private void ramPage() {
        content.addView(infoCard("🧠 RAM BOOSTER", "Scan memory, release this app's unused memory and clear optimizer cache safely."));
        addAction("🧠 RAM SCAN", () -> runAnim("SCANNING MEMORY", () -> Toast.makeText(this, DeviceInfo.memorySummary(this), Toast.LENGTH_SHORT).show()));
        addAction("🚀 RAM BOOSTER", () -> runAnim("BOOSTING PERFORMANCE", () -> { System.gc(); trimMemory(); }));
        addAction("🧹 RAM CACHE CLEANER", () -> runAnim("CLEARING OPTIMIZER CACHE", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        content.addView(infoCard("ANDROID SAFETY", "Normal Android apps cannot silently kill other apps or force-free system RAM. These actions use permitted app-owned cleanup only."));
    }

    private void trimMemory() { try { android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE); if (am != null) am.getMemoryInfo(new android.app.ActivityManager.MemoryInfo()); } catch (Exception ignored) {} }

    private void storagePage() {
        content.addView(infoCard("🧹 ALL FILE CLEANER", "Cleans files owned by SADEE X DIMA and opens Android's storage controls for protected files."));
        addAction("🔍 SCAN ALL ACCESSIBLE FILES", () -> runAnim("SCANNING ACCESSIBLE FILES", () -> Toast.makeText(this, DeviceInfo.storageSummary(this), Toast.LENGTH_LONG).show()));
        addAction("🧹 CLEAN OPTIMIZER FILES", () -> runAnim("CLEANING OPTIMIZER FILES", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        addAction("📂 MANAGE ALL FILES", this::openStorageAccess);
        addAction("⚙️ ANDROID STORAGE", () -> { try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
    }

    private void openStorageAccess() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            i.setData(Uri.parse("package:" + getPackageName())); startActivity(i);
        } catch (Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
    }

    private void gamePage() {
        content.addView(infoCard("🚀 GAME BOOSTER", "Pre-launch cleanup + memory refresh, then launch the selected game."));
        addGameCard("FREE FIRE", "com.dts.freefireth", "🔥");
        addGameCard("FREE FIRE MAX", "com.dts.freefiremax", "🔥");
        addAction("⚡ GAME BOOSTER → FREE FIRE", () -> runGameBooster("FREE FIRE", "com.dts.freefireth"));
        addAction("⚡ GAME BOOSTER → FREE FIRE MAX", () -> runGameBooster("FREE FIRE MAX", "com.dts.freefiremax"));
        content.addView(infoCard("GAME MODE", "SADEE X DIMA does not inject, modify, or cheat inside game files. It prepares the phone using safe Android operations and then launches the game."));
    }

    private void addGameCard(String name, String pkg, String emoji) {
        LinearLayout c = card();
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = tv(emoji, 35, Color.WHITE); row.addView(icon, new LinearLayout.LayoutParams(60, 60));
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        TextView n = tv(name, 18, Color.WHITE); n.setTypeface(null, Typeface.BOLD); texts.addView(n);
        TextView s = tv(isInstalled(pkg) ? "🟢 INSTALLED • READY" : "🔴 NOT INSTALLED", 11, isInstalled(pkg)?GREEN:RED); texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, 70, 1));
        Button b = btn("PLAY", GREEN); b.setTextSize(11); row.addView(b, new LinearLayout.LayoutParams(90, 52));
        b.setOnClickListener(v -> runGameBooster(name, pkg));
        c.addView(row); content.addView(c);
    }

    private boolean isInstalled(String pkg) { try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; } }

    private void runGameBooster(String name, String pkg) {
        beep(2);
        if (!isInstalled(pkg)) { Toast.makeText(this, name + " not installed", Toast.LENGTH_LONG).show(); return; }
        String[] steps = {"GAME BOOSTER STARTING", "REFRESHING MEMORY", "CLEARING OPTIMIZER CACHE", "PREPARING " + name, "LAUNCHING " + name};
        ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA • GAME BOOSTER"); d.setMessage(steps[0]); d.setIndeterminate(false); d.setMax(steps.length); d.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); d.setCancelable(false); d.show();
        final int[] i = {0};
        Runnable tick = new Runnable() { @Override public void run() {
            if (i[0] < steps.length) { d.setProgress(i[0] + 1); d.setMessage(steps[i[0]]); if(i[0] == 1) trimMemory(); if(i[0] == 2){ clearCache(getCacheDir()); if(getExternalCacheDir()!=null) clearCache(getExternalCacheDir()); } i[0]++; handler.postDelayed(this, 550); }
            else { d.dismiss(); launchGame(pkg); }
        }};
        handler.post(tick);
    }

    private void launchGame(String pkg) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) { Toast.makeText(this, "GAME LAUNCHER NOT FOUND", Toast.LENGTH_LONG).show(); return; }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) { Toast.makeText(this, "GAME LAUNCH FAILED", Toast.LENGTH_LONG).show(); }
    }

    private void addAction(String label, Runnable r) {
        Button b = btn("  ⚡  " + label + "  ➜  ", Color.rgb(5, 28, 20));
        b.setTextColor(GREEN); b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setPadding(18, 4, 18, 4);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 70); lp.setMargins(0, 4, 0, 6);
        content.addView(b, lp); b.setOnClickListener(v -> { beep(1); r.run(); });
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(14, 14, 14, 14); c.setBackground(makeBg(CARD, 18, Color.rgb(22, 65, 53)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 5, 0, 8); c.setLayoutParams(lp); return c;
    }

    private LinearLayout infoCard(String title, String body) {
        LinearLayout c = card();
        TextView h = tv(title, 20, GREEN); h.setTypeface(null, Typeface.BOLD); c.addView(h);
        TextView b = tv(body, 14, MUTED); c.addView(b);
        content.addView(c); return c;
    }

    private void runAnim(String msg, Runnable done) {
        beep(2);
        ProgressDialog d = new ProgressDialog(this);
        d.setTitle("SADEE X DIMA // OPTIMIZER ENGINE");
        d.setMessage(">> " + msg + "...\n[████████░░]  SYSTEM OPERATION\n>> CHECKING PERMITTED ANDROID RESOURCES");
        d.setIndeterminate(true); d.setCancelable(false); d.show();
        handler.postDelayed(() -> {
            d.dismiss(); beep(2);
            Toast.makeText(this, "✓ " + msg + " COMPLETE", Toast.LENGTH_SHORT).show();
            done.run();
            try { ((android.os.Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(100); } catch (Exception ignored) {}
        }, 1400);
    }

    private void optimizePage() {
        content.addView(infoCard("⚡ SADEE X DIMA OPTIMIZED", "ONE TAP GAME MODE • FREE FIRE AUTO LAUNCH"));
        TextView log = tv("SYSTEM LOG\n> License verified\n> Device session online\n> Target game: FREE FIRE\n> READY", 13, Color.LTGRAY); log.setTypeface(Typeface.MONOSPACE); content.addView(log);
        Button b = btn("🔥  SADEE X DIMA OPTIMIZED  →  FREE FIRE", GREEN); content.addView(b, new LinearLayout.LayoutParams(-1, 64));
        b.setOnClickListener(v -> runOptimization(log));
        addAction("🔐 LOGOUT / CHANGE LICENSE", () -> { clearSession(); showLogin(); });
    }

    private void runOptimization(TextView log) {
        beep(2);
        if (!isInstalled("com.dts.freefireth")) {
            Toast.makeText(this, "FREE FIRE IS NOT INSTALLED", Toast.LENGTH_LONG).show();
            return;
        }
        String[] steps = {"Imported profile", "Scanning device", "Clearing optimizer cache", "Refreshing memory metrics", "Preparing FREE FIRE", "Launching FREE FIRE"};
        final int[] i = {0}; ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA // GAME MODE"); d.setMessage("Starting..."); d.setIndeterminate(false); d.setMax(steps.length); d.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); d.setCancelable(false); d.show();
        Runnable tick = new Runnable() { @Override public void run() {
            if (i[0] < steps.length) { d.setProgress(i[0] + 1); log.setText("SYSTEM LOG\n> " + steps[i[0]] + "\n> STATUS: RUNNING"); if(i[0]==2){clearCache(getCacheDir()); if(getExternalCacheDir()!=null)clearCache(getExternalCacheDir());} if(i[0]==3)trimMemory(); i[0]++; handler.postDelayed(this, 600); }
            else { d.dismiss(); beep(4); log.setText("SYSTEM LOG\n> SADEE X DIMA OPTIMIZED\n> STATUS: COMPLETE\n> GAME: FREE FIRE\n> LAUNCHING..."); Toast.makeText(MainActivity.this, "SADEE X DIMA OPTIMIZED • FREE FIRE", Toast.LENGTH_SHORT).show(); handler.postDelayed(() -> launchGame("com.dts.freefireth"), 250); }
        }}; handler.post(tick);
    }

    private void beep(int count) {
        try {
            if (tone == null) { try { tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85); } catch (Exception ignored) { return; } }
            final int[] n = {0};
            Runnable r = new Runnable() { @Override public void run() {
                if (n[0]++ < count) {
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 110);
                    handler.postDelayed(this, 150);
                }
            }};
            handler.post(r);
        } catch (Exception ignored) {}
    }

    private void clearCache(File f) { if (f == null) return; File[] fs = f.listFiles(); if (fs != null) for (File x : fs) { if (x.isDirectory()) clearCache(x); else x.delete(); } }
}
