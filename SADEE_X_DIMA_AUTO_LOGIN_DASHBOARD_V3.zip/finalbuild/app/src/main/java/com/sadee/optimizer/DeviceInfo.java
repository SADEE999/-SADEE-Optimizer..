package com.sadee.optimizer;

import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import java.util.Locale;

public final class DeviceInfo {
    private DeviceInfo() {}
    public static String get(Context c) {
        ActivityManager am=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); if(am!=null) am.getMemoryInfo(mi);
        StatFs sf=new StatFs(Environment.getDataDirectory().getPath());
        long totalS=sf.getTotalBytes(), freeS=sf.getAvailableBytes();
        String net=network(c);
        return "DEVICE   : "+Build.MANUFACTURER+"\nMODEL    : "+Build.MODEL+"\nANDROID  : "+Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")\nCPU      : "+Runtime.getRuntime().availableProcessors()+" cores\nRAM      : "+gb(mi.availMem)+" free / "+gb(mi.totalMem)+" total\nSTORAGE  : "+gb(freeS)+" free / "+gb(totalS)+" total\nNETWORK  : "+net+"\nBOARD    : "+Build.BOARD+"\nPRODUCT  : "+Build.PRODUCT;
    }
    public static String model(Context c){ return Build.MODEL; }
    public static String memorySummary(Context c){ ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo(); ActivityManager a=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE); if(a!=null)a.getMemoryInfo(m); return "RAM: "+gb(m.availMem)+" free / "+gb(m.totalMem)+" total"; }
    public static String storageSummary(Context c){ StatFs s=new StatFs(Environment.getDataDirectory().getPath()); return "STORAGE: "+gb(s.getAvailableBytes())+" free / "+gb(s.getTotalBytes())+" total"; }
    private static String network(Context c){ try{ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);NetworkCapabilities n=cm==null?null:cm.getNetworkCapabilities(cm.getActiveNetwork());if(n!=null){if(n.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))return "WIFI";if(n.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))return "MOBILE DATA";return "ONLINE";}}catch(Exception ignored){}return "OFFLINE"; }
    private static String gb(long b){return String.format(Locale.US,"%.2f GB",b/1073741824.0);}
    public static long ramFreeBytes(Context c){ ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo(); ActivityManager a=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE); if(a!=null)a.getMemoryInfo(m); return m.availMem; }
    public static long ramTotalBytes(Context c){ ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo(); ActivityManager a=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE); if(a!=null)a.getMemoryInfo(m); return m.totalMem; }
    public static long storageFreeBytes(Context c){ return new StatFs(Environment.getDataDirectory().getPath()).getAvailableBytes(); }
    public static long storageTotalBytes(Context c){ return new StatFs(Environment.getDataDirectory().getPath()).getTotalBytes(); }
    public static int batteryPercent(Context c){ try{ android.content.Intent i=c.registerReceiver(null,new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)); if(i!=null){int level=i.getIntExtra("level",-1), scale=i.getIntExtra("scale",100); if(level>=0&&scale>0)return Math.round(level*100f/scale);} }catch(Exception ignored){} return 0; }

}
