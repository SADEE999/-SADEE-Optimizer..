SADEE X DIMA OPTIMIZER - APP + ADMIN

APP:
The Android app source is kept as supplied. The app itself is not changed by this admin update.

ADMIN:
admin-dashboard/index.html is the updated 4-page Supabase admin:
1. Dashboard - live license counts, generator, plan overview and recent keys.
2. Licenses - search/filter, activate, pause, resume, expire, unbind and delete.
3. Devices - bound Android device details stored by the app.
4. Settings - connection/control information.

GITHUB BUILD:
1. Put this ZIP in the repository root.
2. Put SADEE_X_DIMA_WORKFLOW.yml in .github/workflows/main.yml.
3. Commit both files to the main branch.
4. GitHub Actions extracts the ZIP automatically.
5. The APK is uploaded as an Actions artifact.
6. The admin dashboard is published to the gh-pages branch.

SUPABASE:
The admin uses the existing publishable key. Do not put a service-role/secret key into HTML or the Android app.
