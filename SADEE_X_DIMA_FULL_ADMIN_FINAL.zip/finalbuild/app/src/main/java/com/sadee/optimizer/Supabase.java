package com.sadee.optimizer;

import android.content.Context;
import android.os.Build;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

public final class Supabase {
    private Supabase() {}
    private static HttpsURLConnection conn(String path,String method)throws Exception{URL u=new URL(Config.SUPABASE_URL+"/rest/v1/"+path);HttpsURLConnection c=(HttpsURLConnection)u.openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("apikey",Config.SUPABASE_KEY);c.setRequestProperty("Authorization","Bearer "+Config.SUPABASE_KEY);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");c.setRequestProperty("Prefer","return=representation");return c;}
    private static String body(HttpsURLConnection c,String json)throws Exception{if(json!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(json.getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();InputStream is=code>=200&&code<400?c.getInputStream():c.getErrorStream();String s=read(is);if(code<200||code>=300)throw new IOException("HTTP "+code+": "+s);return s;}
    private static String read(InputStream in)throws Exception{if(in==null)return "";StringBuilder s=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String x;while((x=r.readLine())!=null)s.append(x);}return s.toString();}
    public static JSONObject verifyAndBind(String key,String device,Context ctx)throws Exception{
        String path="licenses?select=*&license_key=eq."+URLEncoder.encode(key,"UTF-8")+"&limit=1";String s=body(conn(path,"GET"),null);JSONArray a=new JSONArray(s);if(a.length()==0)throw new Exception("INVALID LICENSE");
        JSONObject o=a.getJSONObject(0);String status=o.optString("status","unused").toLowerCase(Locale.US);if("expired".equals(status))throw new Exception("LICENSE EXPIRED");if("paused".equals(status))throw new Exception("LICENSE PAUSED");
        String exp=o.optString("expires_at","");if(expired(exp)){try{JSONObject p=new JSONObject();p.put("status","expired");body(conn("licenses?license_key=eq."+URLEncoder.encode(key,"UTF-8"),"PATCH"),p.toString());}catch(Exception ignored){}throw new Exception("LICENSE EXPIRED");}
        String bound=o.optString("device_id","");if(bound!=null&&!bound.isEmpty()&&!bound.equals(device))throw new Exception("LICENSE ALREADY BOUND TO ANOTHER DEVICE");
        if(bound==null||bound.isEmpty()){
            JSONObject p=new JSONObject();p.put("status","active");p.put("device_id",device);p.put("device_model",Build.MANUFACTURER+" "+Build.MODEL);p.put("device_ram",DeviceInfo.memorySummary(ctx));p.put("device_storage",DeviceInfo.storageSummary(ctx));p.put("device_cpu",Runtime.getRuntime().availableProcessors()+" cores");p.put("android_version",Build.VERSION.RELEASE+" / API "+Build.VERSION.SDK_INT);p.put("network_type",DeviceInfo.get(ctx).split("NETWORK  : ")[1].split("\\n")[0]);p.put("bound_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US).format(new Date()));
            String pth="licenses?license_key=eq."+URLEncoder.encode(key,"UTF-8");String updated=body(conn(pth,"PATCH"),p.toString());if(updated!=null&&!updated.isEmpty())try{o= new JSONArray(updated).getJSONObject(0);}catch(Exception ignored){}
        }
        return o;
    }
    private static boolean expired(String s){if(s==null||s.trim().isEmpty()||"null".equalsIgnoreCase(s))return false;String[] fs={"yyyy-MM-dd'T'HH:mm:ss.SSSXXX","yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String f:fs){try{SimpleDateFormat d=new SimpleDateFormat(f,Locale.US);d.setTimeZone(TimeZone.getTimeZone("UTC"));Date x=d.parse(s);if(x!=null)return x.getTime()<=System.currentTimeMillis();}catch(Exception ignored){}}return false;}
}
