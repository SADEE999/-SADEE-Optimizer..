-- SADEE X DIMA schema repair / setup
-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

alter table public.licenses add column if not exists license_key text;
alter table public.licenses add column if not exists key text;
alter table public.licenses add column if not exists plan text;
alter table public.licenses add column if not exists status text default 'unused';
alter table public.licenses add column if not exists device_id text;
alter table public.licenses add column if not exists activated_at timestamptz;
alter table public.licenses add column if not exists expires_at timestamptz;
alter table public.licenses add column if not exists created_at timestamptz default now();

update public.licenses set license_key=coalesce(license_key,key) where license_key is null;
update public.licenses set key=coalesce(key,license_key) where key is null;
update public.licenses set status='unused' where status is null or lower(status) not in ('unused','active','paused','expired');

create unique index if not exists licenses_license_key_uidx on public.licenses(license_key) where license_key is not null;

drop policy if exists "public_read_licenses" on public.licenses;
drop policy if exists "public_insert_licenses" on public.licenses;
drop policy if exists "public_update_licenses" on public.licenses;
drop policy if exists "public_delete_licenses" on public.licenses;

grant usage on schema public to anon;
grant select,insert,update,delete on public.licenses to anon;
alter table public.licenses enable row level security;
create policy "public_read_licenses" on public.licenses for select to anon using (true);
create policy "public_insert_licenses" on public.licenses for insert to anon with check (true);
create policy "public_update_licenses" on public.licenses for update to anon using (true) with check (true);
create policy "public_delete_licenses" on public.licenses for delete to anon using (true);
notify pgrst,'reload schema';
