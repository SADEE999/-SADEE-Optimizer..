# SADEE X DIMA OPTIMIZER

Android optimizer-style app + Supabase admin dashboard.

## Important
The app uses safe Android APIs. RAM actions clean this app's own cache and show a terminal/beep animation; Android does not allow an ordinary app to force-clear arbitrary apps' RAM/data without privileged access. Game launch opens the installed game package; it does not inject or modify game files.

## Supabase
1. Open Supabase SQL Editor.
2. Run `supabase_schema.sql`.
3. The publishable key is used by the app/admin. Never put a Supabase service-role key in client code.

## Build
The GitHub Actions workflow extracts the first ZIP in the repository, finds the Android project, repairs common build issues, builds the debug APK, uploads it, and publishes `admin-dashboard` to `gh-pages`.
