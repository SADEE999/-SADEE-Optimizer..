package com.sadee.optimizer;

import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.time.*;import java.util.*;

public final class Supabase {
    public static final String URL="https://cpmzjplfqggmgeotmtcd.supabase.co";
    public static final String KEY="sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW";
    private Supabase(){}
    static HttpURLConnection conn(String path,String method)throws Exception{
      HttpURLConnection c=(HttpURLConnection)new URL(URL+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(9000); c.setReadTimeout(12000);
      c.setRequestProperty("apikey",KEY); c.setRequestProperty("Authorization","Bearer "+KEY); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Prefer","return=representation");
      if(!method.equals("GET"))c.setDoOutput(true); return c;
    }
    static String body(HttpURLConnection c)throws Exception{InputStream in=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream(); if(in==null)return ""; BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); StringBuilder s=new StringBuilder();String x;while((x=r.readLine())!=null)s.append(x);return s.toString();}
    public static JSONObject verify(String key,String device)throws Exception{
      HttpURLConnection c=conn("/rest/v1/licenses?select=*&or=(license_key.eq."+URLEncoder.encode(key,"UTF-8")+",key.eq."+URLEncoder.encode(key,"UTF-8")+")&limit=1","GET");
      String b=body(c); if(c.getResponseCode()>=300)throw new IOException(b); JSONArray a=new JSONArray(b); if(a.length()==0)return null; JSONObject o=a.getJSONObject(0);
      String status=o.optString("status","unused"); String bound=o.optString("device_id",""); if("expired".equalsIgnoreCase(status)||"paused".equalsIgnoreCase(status))return o;
      if(bound.length()>0&&!bound.equals(device)) {o.put("_error","BOUND");return o;}
      if("unused".equalsIgnoreCase(status)){JSONObject u=new JSONObject();u.put("status","active");u.put("device_id",device);u.put("activated_at",Instant.now().toString());String plan=o.optString("plan","7 days").toLowerCase(Locale.US);if(!plan.contains("life")){long days=plan.contains("month")?30:7;u.put("expires_at",Instant.now().plusSeconds(days*86400L).toString());} else u.put("expires_at",JSONObject.NULL); update(o.getString("id"),u); o.put("status","active");o.put("device_id",device);o.put("activated_at",u.getString("activated_at"));if(u.has("expires_at"))o.put("expires_at",u.get("expires_at"));}
      return o;
    }
    public static JSONObject update(String id,JSONObject data)throws Exception{HttpURLConnection c=conn("/rest/v1/licenses?id=eq."+URLEncoder.encode(id,"UTF-8"),"PATCH");try(OutputStream out=c.getOutputStream()){out.write(data.toString().getBytes(StandardCharsets.UTF_8));}String b=body(c);if(c.getResponseCode()>=300)throw new IOException(b);JSONArray a=b.isEmpty()?new JSONArray():new JSONArray(b);return a.length()>0?a.getJSONObject(0):data;}
    public static JSONArray list()throws Exception{HttpURLConnection c=conn("/rest/v1/licenses?select=*&order=created_at.desc","GET");String b=body(c);if(c.getResponseCode()>=300)throw new IOException(b);return new JSONArray(b);}
    public static JSONObject create(String plan)throws Exception{String key="SXD-"+token(4)+"-"+token(4)+"-"+token(4);JSONObject o=new JSONObject();o.put("license_key",key);o.put("key",key);o.put("plan",plan);o.put("status","unused");o.put("created_at",Instant.now().toString());HttpURLConnection c=conn("/rest/v1/licenses","POST");try(OutputStream out=c.getOutputStream()){out.write(o.toString().getBytes(StandardCharsets.UTF_8));}String b=body(c);if(c.getResponseCode()>=300)throw new IOException(b);JSONArray a=new JSONArray(b);return a.getJSONObject(0);}
    static String token(int n){String chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";Random r=new Random();StringBuilder s=new StringBuilder();for(int i=0;i<n;i++)s.append(chars.charAt(r.nextInt(chars.length())));return s.toString();}
}
