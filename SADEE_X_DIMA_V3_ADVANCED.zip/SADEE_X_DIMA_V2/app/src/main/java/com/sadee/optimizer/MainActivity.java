package com.sadee.optimizer;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private Fragment page(int p){
        switch(p){case 0:return new HomeFragment();case 1:return new Page2CleanerFragment();case 2:return new Page3SaverFragment();case 3:return new Page5InjectorFragment();case 4:return new Page4GfxFragment();default:return new HistoryFragment();}
    }
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView nav = findViewById(R.id.bottomNav);
        if (savedInstanceState == null) getSupportFragmentManager().beginTransaction().replace(R.id.contentFrame, page(0)).commit();
        nav.setOnItemSelectedListener(item -> {
            int p;
            int id = item.getItemId();
            if (id == R.id.nav_home) p=0;
            else if (id == R.id.nav_performance) p=1;
            else if (id == R.id.nav_cleaner) p=2;
            else if (id == R.id.nav_gaming) p=3;
            else if (id == R.id.nav_device) p=4;
            else p=5;
            getSupportFragmentManager().beginTransaction().setReorderingAllowed(true).replace(R.id.contentFrame, page(p)).commit();
            return true;
        });
    }
    @Override protected void onResume(){
        super.onResume();
        if(getSharedPreferences("license",MODE_PRIVATE).getString("key","").isEmpty()) finish();
    }
}
