package com.sadee.optimizer;

import android.app.ActivityManager;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private TextView ram,cpu,battery,temp,storage,network,cores,refresh,health,licensePlan,licenseExpiry;
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){
        View v=i.inflate(R.layout.fragment_home,c,false);
        ram=v.findViewById(R.id.metricRam); cpu=v.findViewById(R.id.metricCpu); battery=v.findViewById(R.id.metricBattery);
        temp=v.findViewById(R.id.metricTemp); storage=v.findViewById(R.id.metricStorage); network=v.findViewById(R.id.metricNetwork);
        cores=v.findViewById(R.id.metricCores); refresh=v.findViewById(R.id.metricRefresh); health=v.findViewById(R.id.healthScore);
        licensePlan=v.findViewById(R.id.licensePlan); licenseExpiry=v.findViewById(R.id.licenseExpiry);
        Button scan=v.findViewById(R.id.btnQuickScan); scan.setOnClickListener(x->{ update(); Toast.makeText(getContext(),"System scan refreshed",Toast.LENGTH_SHORT).show(); });
        update(); return v;
    }
    private void update(){
        if(!isAdded()) return; Context x=requireContext();
        ActivityManager am=(ActivityManager)x.getSystemService(Context.ACTIVITY_SERVICE); long used=0,total=0;
        if(am!=null){ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);total=mi.totalMem;used=total-mi.availMem;}
        int ramPct=total>0?(int)(used*100/total):0; ram.setText(ramPct+"%"); cores.setText(""+Runtime.getRuntime().availableProcessors());
        cpu.setText("ACTIVE");
        Intent bs=x.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); int bp=0; float tc=0;
        if(bs!=null){int l=bs.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),s=bs.getIntExtra(BatteryManager.EXTRA_SCALE,100);bp=s>0?(l*100/s):0;tc=bs.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0)/10f;}
        battery.setText(bp+"%"); temp.setText(String.format(Locale.US,"%.1f°C",tc));
        android.os.StatFs sf=new android.os.StatFs(Environment.getDataDirectory().getPath()); long b=sf.getBlockCountLong()*sf.getBlockSizeLong(), a=sf.getAvailableBlocksLong()*sf.getBlockSizeLong(); int sp=b>0?(int)((b-a)*100/b):0; storage.setText(sp+"%");
        ConnectivityManager cm=(ConnectivityManager)x.getSystemService(Context.CONNECTIVITY_SERVICE); Network n=Build.VERSION.SDK_INT>=23&&cm!=null?cm.getActiveNetwork():null; network.setText(n!=null?"ONLINE":"OFFLINE");
        if(Build.VERSION.SDK_INT>=30){WindowManager wm=x.getSystemService(WindowManager.class); if(wm!=null) refresh.setText(String.format(Locale.US,"%.0f Hz",wm.getCurrentWindowMetrics().getDensity()*60));} else refresh.setText("60 Hz");
        int score=Math.max(0,Math.min(100,100-ramPct/2)); health.setText(score+"%");
        SharedPreferences p=x.getSharedPreferences("license",Context.MODE_PRIVATE); licensePlan.setText(p.getString("plan","LICENSED")); licenseExpiry.setText(p.getString("expires_at","No expiry • Full access"));
    }
}
