-- SADEE X DIMA REAL LICENSE SETUP
-- Run once in Supabase SQL Editor.

alter table public.licenses add column if not exists device_name text;
alter table public.licenses add column if not exists device_model text;
alter table public.licenses add column if not exists ram_gb text;
alter table public.licenses add column if not exists android_version text;
alter table public.licenses add column if not exists last_seen timestamptz;

-- Keep the status values used by the app/admin.
alter table public.licenses drop constraint if exists licenses_status_check;
alter table public.licenses
  add constraint licenses_status_check
  check (lower(status) in ('unused','active','paused','expired'));

grant usage on schema public to anon;
grant select, insert, update, delete on table public.licenses to anon;

alter table public.licenses enable row level security;

drop policy if exists "sxd_public_select" on public.licenses;
drop policy if exists "sxd_public_insert" on public.licenses;
drop policy if exists "sxd_public_update" on public.licenses;
drop policy if exists "sxd_public_delete" on public.licenses;

create policy "sxd_public_select"
on public.licenses for select to anon using (true);

create policy "sxd_public_insert"
on public.licenses for insert to anon with check (true);

create policy "sxd_public_update"
on public.licenses for update to anon
using (true) with check (true);

create policy "sxd_public_delete"
on public.licenses for delete to anon using (true);

notify pgrst, 'reload schema';

-- IMPORTANT:
-- This no-login admin design exposes license management to anyone who can
-- access the admin URL. For a production commercial deployment, put admin
-- writes behind authenticated Supabase/Edge Function access.
