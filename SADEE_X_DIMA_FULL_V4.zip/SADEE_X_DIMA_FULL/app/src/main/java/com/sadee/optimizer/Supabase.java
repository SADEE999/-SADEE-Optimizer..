package com.sadee.optimizer;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Supabase {
    public static final String URL = "https://cpmzjplfqggmgeotmtcd.supabase.co";
    public static final String KEY = "sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW";

    private static HttpURLConnection open(String method, String path) throws Exception {
        URL u = new URL(URL + path);
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("apikey", KEY);
        c.setRequestProperty("Authorization", "Bearer " + KEY);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Accept", "application/json");
        if (method.equals("POST") || method.equals("PATCH")) {
            c.setDoOutput(true);
            c.setRequestProperty("Prefer", "return=representation");
        }
        return c;
    }

    private static String body(HttpURLConnection c) throws Exception {
        InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder s = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) s.append(line);
            return s.toString();
        }
    }

    public static JSONObject verify(String license, String deviceId, String deviceName,
                                     String ram, String androidVersion) throws Exception {
        String q = "/rest/v1/licenses?select=*&license_key=eq." +
                URLEncoder.encode(license, "UTF-8") + "&limit=1";
        HttpURLConnection c = open("GET", q);
        int code = c.getResponseCode();
        String raw = body(c);
        if (code >= 400) throw new Exception(raw);
        JSONArray a = new JSONArray(raw);
        if (a.length() == 0) throw new Exception("LICENSE KEY NOT FOUND");
        JSONObject row = a.getJSONObject(0);

        String status = row.optString("status", "unused").toLowerCase(Locale.US);
        String oldDevice = row.optString("device_id", "");
        String expires = row.optString("expires_at", "");
        if ("expired".equals(status)) throw new Exception("LICENSE EXPIRED");
        if ("paused".equals(status)) throw new Exception("LICENSE PAUSED");
        if (!oldDevice.isEmpty() && !oldDevice.equals(deviceId))
            throw new Exception("LICENSE ALREADY BOUND TO ANOTHER DEVICE");

        long now = System.currentTimeMillis();
        long expiry = parseIso(expires);
        String plan = row.optString("plan", row.optString("plan_id", "7 DAYS"));
        String p = plan.toLowerCase(Locale.US);
        if (expiry <= now && !p.contains("life")) {
            if (status.equals("unused") || expires.isEmpty()) {
                long days = p.contains("month") ? 30 : 7;
                expiry = now + days * 86400000L;
                expires = iso(expiry);
            } else {
                throw new Exception("LICENSE EXPIRED");
            }
        }

        if (status.equals("unused")) {
            JSONObject patch = new JSONObject();
            patch.put("status", "active");
            patch.put("device_id", deviceId);
            patch.put("activated_at", iso(now));
            if (!p.contains("life")) patch.put("expires_at", expires);
            patchRow(license, patch);
            try {
                JSONObject telemetry = new JSONObject();
                telemetry.put("device_model", deviceName);
                telemetry.put("device_name", deviceName);
                telemetry.put("ram_gb", ram);
                telemetry.put("android_version", androidVersion);
                telemetry.put("last_seen", iso(now));
                patchRow(license, telemetry);
            } catch (Exception ignored) {}
            row.put("status", "active");
            row.put("device_id", deviceId);
            row.put("expires_at", expires);
        } else {
            JSONObject patch = new JSONObject();
            patch.put("last_seen", iso(now));
            patch.put("device_model", deviceName);
            patch.put("device_name", deviceName);
            patch.put("ram_gb", ram);
            patch.put("android_version", androidVersion);
            try { patchRow(license, patch); } catch (Exception ignored) {}
        }
        return row;
    }

    public static void heartbeat(String license, String deviceId, String deviceName,
                                 String ram, String androidVersion) throws Exception {
        JSONObject p = new JSONObject();
        p.put("last_seen", iso(System.currentTimeMillis()));
        p.put("device_model", deviceName);
        p.put("device_name", deviceName);
        p.put("ram_gb", ram);
        p.put("android_version", androidVersion);
        String path = "/rest/v1/licenses?license_key=eq." + URLEncoder.encode(license, "UTF-8")
                + "&device_id=eq." + URLEncoder.encode(deviceId, "UTF-8");
        HttpURLConnection c = open("PATCH", path);
        try (OutputStream o = c.getOutputStream()) { o.write(p.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode(); body(c);
        if (code >= 400) throw new Exception("Heartbeat failed");
    }

    private static void patchRow(String license, JSONObject patch) throws Exception {
        String path = "/rest/v1/licenses?license_key=eq." + URLEncoder.encode(license, "UTF-8");
        HttpURLConnection c = open("PATCH", path);
        try (OutputStream o = c.getOutputStream()) { o.write(patch.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        String raw = body(c);
        if (code >= 400) throw new Exception(raw);
    }

    public static String iso(long ms) {
        return new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
                .format(new Date(ms));
    }

    private static long parseIso(String s) {
        if (s == null || s.isEmpty()) return 0;
        try { return java.time.Instant.parse(s).toEpochMilli(); } catch (Exception e) {}
        try { return javax.xml.bind.DatatypeConverter.parseDateTime(s).getTimeInMillis(); } catch (Exception e) {}
        return 0;
    }
}
