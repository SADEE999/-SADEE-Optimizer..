package com.sadee.optimizer;

import android.app.*;
import android.content.*;
import android.os.*;
import android.net.*;
import android.telephony.*;
import android.view.*;
import java.util.*;

public class Device {
    static String id(Context c){
        String s=android.provider.Settings.Secure.getString(c.getContentResolver(),android.provider.Settings.Secure.ANDROID_ID);
        return s==null?"unknown":s;
    }
    static String name(){ return Build.MANUFACTURER+" "+Build.MODEL; }
    static String ram(Context c){
        ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();
        ((ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(m);
        return String.format(Locale.US,"%.1f GB",(m.totalMem/1073741824.0));
    }
    static long totalRam(Context c){ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();((ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(m);return m.totalMem;}
    static long availRam(Context c){ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();((ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(m);return m.availMem;}
    static long totalStorage(){android.os.StatFs s=new android.os.StatFs(Environment.getDataDirectory().getPath());return s.getTotalBytes();}
    static long freeStorage(){android.os.StatFs s=new android.os.StatFs(Environment.getDataDirectory().getPath());return s.getAvailableBytes();}
    static String storage(long bytes){return String.format(Locale.US,"%.1f GB",bytes/1073741824.0);}
    static int usedPercent(){long t=totalStorage(),f=freeStorage();return t==0?0:(int)Math.round((t-f)*100.0/t);}
    static String network(Context c){
        try{ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);Network n=cm.getActiveNetwork();if(n==null)return "Offline";NetworkCapabilities x=cm.getNetworkCapabilities(n);if(x==null)return "Unknown";if(x.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))return "Wi‑Fi";if(x.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))return "Mobile";return "Online";}catch(Exception e){return "Unknown";}
    }
    static String refresh(Context c){try{float hz=((WindowManager)c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRefreshRate();return String.format(Locale.US,"%.0f Hz",hz);}catch(Exception e){return "Unknown";}}
    static String uptime(){long s=SystemClock.elapsedRealtime()/1000;long h=s/3600;long m=(s%3600)/60;return String.format(Locale.US,"%02dh %02dm",h,m);}
}
