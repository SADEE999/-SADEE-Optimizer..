package com.sadee.optimizer;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONObject;
import java.util.*;

public class LoginActivity extends Activity {
    EditText keyBox; TextView status; Button verify;
    int green=Color.rgb(53,255,138), cyan=Color.rgb(22,217,255), bg=Color.rgb(5,8,11), panel=Color.rgb(16,21,26);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        String saved=getSharedPreferences("license",0).getString("key","");
        if(!saved.isEmpty()) {
            new Thread(() -> {
                try {
                    JSONObject row=Supabase.verify(saved, Device.id(this), Device.name(), Device.ram(this), Build.VERSION.RELEASE);
                    save(row,saved);
                    runOnUiThread(() -> openMain());
                } catch(Exception ignored) {}
            }).start();
        }
        build(saved);
    }

    void build(String saved) {
        LinearLayout root=base();
        ImageView logo=new ImageView(this);
        logo.setImageResource(com.sadee.optimizer.R.drawable.sadee_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        root.addView(logo,new LinearLayout.LayoutParams(-1,110));
        TextView title=t("SADEE X DIMA",28,Color.WHITE); title.setGravity(17);
        root.addView(title,new LinearLayout.LayoutParams(-1,55));
        TextView sub=t("OPTIMIZER",18,green); sub.setGravity(17); sub.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        root.addView(sub,new LinearLayout.LayoutParams(-1,40));

        LinearLayout card=card();
        TextView head=t("VERIFYING LICENSE ACCESS",18,green); head.setTypeface(null,Typeface.BOLD);
        card.addView(head,lp(1,52,16));
        keyBox=new EditText(this); keyBox.setSingleLine(true); keyBox.setHint("SXD-XXXX-XXXX-XXXX-XXXX");
        keyBox.setText(saved); keyBox.setTextColor(Color.WHITE); keyBox.setHintTextColor(Color.rgb(100,110,120));
        keyBox.setTextSize(18); keyBox.setPadding(22,0,22,0);
        keyBox.setBackground(round(Color.rgb(11,15,19),Color.rgb(35,55,64),2,24));
        card.addView(keyBox,lp(1,70,16));
        verify=new Button(this); verify.setText("VERIFY & UNLOCK"); verify.setTextSize(16); verify.setTypeface(null,Typeface.BOLD);
        verify.setTextColor(Color.rgb(15,10,20)); verify.setBackground(round(Color.rgb(180,124,255),Color.rgb(180,124,255),0,24));
        card.addView(verify,lp(1,64,16));
        status=t("",14,Color.GRAY); status.setGravity(17);
        card.addView(status,lp(1,55,16));
        root.addView(card,new LinearLayout.LayoutParams(-1,-2));
        TextView choose=t("CHOOSE YOUR PLAN",19,cyan); choose.setTypeface(null,Typeface.BOLD); root.addView(choose,lp(1,45,20));
        LinearLayout plans=card();
        plan(plans,"7 DAYS","LKR 500"); plan(plans,"1 MONTH","LKR 1,000"); plan(plans,"LIFETIME","LKR 2,200");
        root.addView(plans,new LinearLayout.LayoutParams(-1,-2));
        Button wa=new Button(this); wa.setText("BUY LICENSE • WHATSAPP"); wa.setTextSize(15); wa.setTextColor(Color.BLACK);
        wa.setBackground(round(Color.rgb(180,124,255),Color.TRANSPARENT,0,24));
        wa.setOnClickListener(v->{ Intent i=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://wa.me/94768472404?text=I%20need%20a%20SADEE%20X%20DIMA%20license")); startActivity(i);});
        root.addView(wa,lp(1,65,20));
        TextView foot=t("1 LICENSE = 1 DEVICE • DEVICE BINDING + EXPIRY PROTECTION",11,Color.GRAY); foot.setGravity(17);
        root.addView(foot,lp(1,50,12));
        verify.setOnClickListener(v->verifyKey());
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
    }

    void verifyKey(){
        String k=keyBox.getText().toString().trim().toUpperCase(Locale.US);
        if(k.isEmpty()){status.setText("ENTER LICENSE KEY");return;}
        verify.setEnabled(false); status.setText("CONNECTING TO SECURE LICENSE SERVER...");
        new Thread(()->{
            try{
                JSONObject row=Supabase.verify(k,Device.id(this),Device.name(),Device.ram(this),Build.VERSION.RELEASE);
                save(row,k);
                runOnUiThread(()->{status.setText("LICENSE VERIFIED SUCCESSFULLY • OPENING DASHBOARD..."); new Handler().postDelayed(this::openMain,500);});
            }catch(Exception e){runOnUiThread(()->{status.setText(e.getMessage()==null?"VERIFICATION FAILED":e.getMessage());verify.setEnabled(true);});}
        }).start();
    }

    void save(JSONObject row,String k){
        getSharedPreferences("license",0).edit()
                .putString("key",k)
                .putString("plan",row.optString("plan","LIFETIME"))
                .putString("expires_at",row.optString("expires_at",""))
                .apply();
    }
    void openMain(){startActivity(new Intent(this,MainActivity.class)); finish();}
    void plan(LinearLayout p,String a,String b){ TextView x=t(a+"                                      "+b,16,Color.WHITE); x.setGravity(17); x.setBackground(round(Color.rgb(180,124,255),Color.TRANSPARENT,0,22)); p.addView(x,lp(1,65,6));}
    LinearLayout base(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(28,18,28,18);l.setBackgroundColor(bg);return l;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(16,16,16,16);l.setBackground(round(panel,Color.rgb(35,55,64),2,24));return l;}
    TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
    LinearLayout.LayoutParams lp(float w,int h,int m){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,h);p.setMargins(0,m,0,m);return p;}
    android.graphics.drawable.GradientDrawable round(int c,int stroke,int sw,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(c);g.setCornerRadius(r);if(sw>0)g.setStroke(sw,stroke);return g;}
}
