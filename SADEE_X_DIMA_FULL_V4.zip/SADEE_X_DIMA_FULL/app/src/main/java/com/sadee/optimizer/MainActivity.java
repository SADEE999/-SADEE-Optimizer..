package com.sadee.optimizer;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout content, nav; TextView keyTimer, title, live;
    Handler h=new Handler(Looper.getMainLooper());
    int green=Color.rgb(53,255,138), cyan=Color.rgb(22,217,255), purple=Color.rgb(180,124,255), bg=Color.rgb(5,8,11), panel=Color.rgb(16,21,26);
    String key, plan, expires;
    int page=0;
    Runnable ticker;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        key=getSharedPreferences("license",0).getString("key","");
        plan=getSharedPreferences("license",0).getString("plan","LIFETIME");
        expires=getSharedPreferences("license",0).getString("expires_at","");
        buildShell(); showPage(0);
        ticker=()->{updateTop(); liveStats(); h.postDelayed(ticker,1000);};
        h.post(ticker);
        new Thread(()->{try{Supabase.heartbeat(key,Device.id(this),Device.name(),Device.ram(this),Build.VERSION.RELEASE);}catch(Exception ignored){}}).start();
    }
    void buildShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(18,12,14,4);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.sadee_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        head.addView(logo,new LinearLayout.LayoutParams(0,74,1));
        TextView refresh=t("↻",34,cyan);refresh.setGravity(17);refresh.setOnClickListener(v->{showPage(page);});
        head.addView(refresh,new LinearLayout.LayoutParams(54,70));
        root.addView(head);
        LinearLayout keybar=new LinearLayout(this);keybar.setPadding(20,0,20,4);keybar.setGravity(Gravity.CENTER_VERTICAL);
        keyTimer=t("LICENSE • "+plan,12,Color.WHITE); keybar.addView(keyTimer,new LinearLayout.LayoutParams(0,42,1));
        TextView ver=t("v4.0",11,Color.GRAY);keybar.addView(ver,new LinearLayout.LayoutParams(55,42));
        root.addView(keybar);
        ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(22,4,22,100);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setPadding(4,5,4,5);nav.setBackgroundColor(Color.rgb(14,18,22));
        String[] ns={"⌂\nHOME","♨\nRAM","▦\nSTORAGE","🎮\nGAMING","▣\nDEVICE"};
        for(int i=0;i<5;i++){final int j=i;Button b=button(ns[i],12,Color.LTGRAY);b.setBackgroundColor(Color.TRANSPARENT);b.setOnClickListener(v->{page=j;showPage(j);});nav.addView(b,new LinearLayout.LayoutParams(0,64,1));}
        root.addView(nav);setContentView(root);
    }
    void showPage(int p){
        content.removeAllViews();
        if(p==0)home(); else if(p==1)ramPage(); else if(p==2)storagePage(); else if(p==3)gamingPage(); else devicePage();
    }
    void home(){
        content.addView(section("CYBER SYSTEM // REAL MODE",green));
        LinearLayout card=card();
        TextView a=t("LIVE DEVICE TELEMETRY",15,green);card.addView(a,lp(1,40,4));
        live=t("",14,Color.WHITE);live.setLineSpacing(8,1);card.addView(live,lp(1,125,2));content.addView(card);
        content.addView(section("PERFORMANCE HEALTH SCORE",green));
        ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress(72);content.addView(pb,lp(1,25,10));
        TextView score=t("REAL-TIME HEALTH • "+Device.network(this)+" • "+Device.refresh(this),13,Color.GRAY);content.addView(score,lp(1,35,2));
        content.addView(metricGrid());
        content.addView(section("QUICK ACTIONS",cyan));
        Button r=button("⚡ RAM BOOST / CLEAN",15,Color.BLACK);r.setBackground(round(green,green,0,24));r.setOnClickListener(v->{page=1;showPage(1);});content.addView(r,lp(1,62,5));
        Button s=button("▦ STORAGE SCAN",15,Color.BLACK);s.setBackground(round(cyan,cyan,0,24));s.setOnClickListener(v->{page=2;showPage(2);});content.addView(s,lp(1,62,5));
    }
    void ramPage(){
        content.addView(section("RAM BOOSTER // LIVE MEMORY ENGINE",green));
        TextView stat=t("",15,Color.WHITE);stat.setLineSpacing(8,1);content.addView(stat,lp(1,100,6));
        TextView console=t("READY > MEMORY ENGINE ONLINE\nREADY > SAFE PROCESS TRIM ENABLED",13,green);console.setTypeface(Typeface.MONOSPACE);console.setPadding(14,14,14,14);console.setBackground(round(Color.BLACK,Color.rgb(25,65,40),1,16));content.addView(console,lp(1,180,8));
        Button scan=button("⌁ RAM SCAN",15,Color.WHITE);scan.setBackground(round(panel,green,2,20));content.addView(scan,lp(1,60,5));
        Button clean=button("⚡ RAM CLEANER",15,Color.BLACK);clean.setBackground(round(green,green,0,20));content.addView(clean,lp(1,60,5));
        TextView note=t("OPTIMIZER INJECTOR // SAFE MODE\nThis performs app-owned memory trim/GC only. It does not inject code into other apps.",12,Color.GRAY);content.addView(note,lp(1,70,10));
        scan.setOnClickListener(v->animateEngine(console,"SCANNING MEMORY MAP"));
        clean.setOnClickListener(v->cleanRam(console,stat));
    }
    void cleanRam(TextView console,TextView stat){
        beep(); console.setText("INITIALIZING OPTIMIZER INJECTOR...\n");
        new Thread(()->{
            long before=Device.availRam(this);
            for(int i=0;i<7;i++){final int n=i;runOnUiThread(()->console.append("0"+n+" > "+new String[]{"MEMORY SCAN","CACHE HINT","TRIM PROCESS","GC PASS","RAM RECHECK","ENGINE SYNC","COMPLETE"}[n]+"\n"));System.gc();SystemClock.sleep(180);}
            System.gc();
            long after=Device.availRam(this);
            runOnUiThread(()->{stat.setText("AVAILABLE RAM BEFORE  "+Device.storage(before)+"\nAVAILABLE RAM AFTER   "+Device.storage(after)+"\nDELTA                 "+Device.storage(Math.max(0,after-before)));console.setText(console.getText()+"\n✓ SAFE MEMORY CLEAN COMPLETE\n✓ REAL TELEMETRY UPDATED");});
        }).start();
    }
    void storagePage(){
        content.addView(section("STORAGE CLEANER // REAL SCAN",cyan));
        TextView stats=t("",16,Color.WHITE);stats.setLineSpacing(8,1);content.addView(stats,lp(1,130,6));
        TextView console=t("READY > STORAGE ENGINE ONLINE",13,cyan);console.setTypeface(Typeface.MONOSPACE);console.setPadding(14,14,14,14);console.setBackground(round(Color.BLACK,Color.rgb(25,55,65),1,16));content.addView(console,lp(1,180,8));
        Button scan=button("⌕ SCAN STORAGE",15,Color.WHITE);scan.setBackground(round(panel,cyan,2,20));content.addView(scan,lp(1,60,5));
        Button clear=button("⚡ CLEAR APP CACHE",15,Color.BLACK);clear.setBackground(round(cyan,cyan,0,20));content.addView(clear,lp(1,60,5));
        scan.setOnClickListener(v->{
            new Thread(()->{
                int[] files={0}; long[] bytes={0}; scanDir(getCacheDir(),files,bytes);
                runOnUiThread(()->{stats.setText("TOTAL STORAGE     "+Device.storage(Device.totalStorage())+"\nFREE STORAGE      "+Device.storage(Device.freeStorage())+"\nUSED              "+Device.usedPercent()+"%\nAPP CACHE FOUND   "+Device.storage(bytes[0])+"\nFILES SCANNED     "+files[0]);console.setText("✓ REAL STORAGE SCAN COMPLETE\n> "+files[0]+" FILES INDEXED");});
            }).start();
        });
        clear.setOnClickListener(v->{
            beep(); clearCache(getCacheDir()); clearCache(getCodeCache());
            console.setText("STORAGE CLEANER\n> APP CACHE PURGED\n> TEMP DATA REMOVED\n> STORAGE TELEMETRY REFRESHED");
            stats.setText("FREE STORAGE NOW   "+Device.storage(Device.freeStorage())+"\nUSED               "+Device.usedPercent()+"%");
        });
    }
    void gamingPage(){
        content.addView(section("GAME LAUNCH CENTER",cyan));
        TextView intro=t("CYBER TURBO • PRE-CLEAN • LIVE SESSION TELEMETRY",12,Color.GRAY);content.addView(intro,lp(1,30,2));
        gameCard("FREE FIRE","com.dts.freefireth","NORMAL");
        gameCard("FREE FIRE MAX","com.dts.freefiremax","MAX");
        content.addView(section("SADEE X DIMA OPTIMIZED",green));
        TextView msg=t("PRE-LAUNCH ENGINE\n• memory trim\n• app cache cleanup\n• device telemetry refresh\n• direct game launch\n\nNo game files are modified.",13,Color.GRAY);content.addView(msg,lp(1,150,5));
    }
    void gameCard(String name,String pkg,String mode){
        LinearLayout c=card();TextView n=t("🎮  "+name+"                         "+mode,17,Color.WHITE);n.setTypeface(null,Typeface.BOLD);c.addView(n,lp(1,48,2));
        TextView p=t(pkg,11,Color.GRAY);p.setGravity(17);c.addView(p,lp(1,28,0));
        Button b=button("🚀  SADEE X DIMA OPTIMIZED",14,Color.BLACK);b.setBackground(round(purple,purple,0,30));c.addView(b,lp(1,60,4));
        b.setOnClickListener(v->launchGame(name,pkg));content.addView(c);
    }
    void launchGame(String name,String pkg){
        beep(); final Dialog d=new Dialog(this);LinearLayout box=card();box.setPadding(20,20,20,20);TextView log=t("SADEE X DIMA OPTIMIZED\n\n",15,green);log.setTypeface(Typeface.MONOSPACE);box.addView(log,lp(1,240,0));d.setContentView(box);Window w=d.getWindow();if(w!=null)w.setBackgroundDrawable(round(bg,green,1,18));d.show();
        new Thread(()->{
            String[] lines={"[01] IMPORTED PROFILE CHECK","[02] CLEAR APP TEMP CACHE","[03] MEMORY TRIM","[04] DEVICE TELEMETRY SYNC","[05] TURBO PRE-LAUNCH","[06] GAME SESSION READY"};
            for(String x:lines){runOnUiThread(()->log.append(x+"\n"));SystemClock.sleep(300);}
            runOnUiThread(()->{d.dismiss();try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null){Toast.makeText(this,name+" is not installed",Toast.LENGTH_LONG).show();return;}startActivity(i);}catch(Exception e){Toast.makeText(this,"Could not launch "+name,Toast.LENGTH_LONG).show();}});
        }).start();
    }
    void devicePage(){
        content.addView(section("DEVICE INFORMATION // LIVE",cyan));
        TextView d=t("",15,Color.WHITE);d.setLineSpacing(8,1);content.addView(d,lp(1,520,8));
        Button refresh=button("↻ REFRESH LIVE DATA",14,Color.BLACK);refresh.setBackground(round(cyan,cyan,0,22));content.addView(refresh,lp(1,60,5));
        Runnable up=()->d.setText("DEVICE          "+Device.name()+"\nMANUFACTURER    "+Build.MANUFACTURER+"\nMODEL           "+Build.MODEL+"\nANDROID         "+Build.VERSION.RELEASE+"\nSDK             "+Build.VERSION.SDK_INT+"\nCPU CORES       "+Runtime.getRuntime().availableProcessors()+"\nTOTAL RAM       "+Device.ram(this)+"\nAVAILABLE RAM   "+Device.storage(Device.availRam(this))+"\nTOTAL STORAGE   "+Device.storage(Device.totalStorage())+"\nFREE STORAGE    "+Device.storage(Device.freeStorage())+"\nSTORAGE USED    "+Device.usedPercent()+"%\nNETWORK         "+Device.network(this)+"\nDISPLAY         "+Device.refresh(this)+"\nUPTIME          "+Device.uptime()+"\nDEVICE ID       "+Device.id(this));
        up.run();refresh.setOnClickListener(v->up.run());
    }
    LinearLayout metricGrid(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        String[][] m={{"RAM","CPU","CORES"},{"BATTERY","TEMP","THERMAL"},{"STORAGE","NETWORK","UPTIME"}};
        for(String[] row:m){LinearLayout r=new LinearLayout(this);for(String x:row){TextView q=t(x+"\n\nLIVE",13,Color.LTGRAY);q.setPadding(14,12,8,12);q.setBackground(round(Color.rgb(10,14,18),Color.TRANSPARENT,0,16));r.addView(q,new LinearLayout.LayoutParams(0,92,1));}box.addView(r,lp(1,98,4));}return box;
    }
    void liveStats(){if(live!=null&&page==0)live.setText("CPU CORES        "+Runtime.getRuntime().availableProcessors()+"\nRAM              "+Device.ram(this)+" • FREE "+Device.storage(Device.availRam(this))+"\nSTORAGE          "+Device.usedPercent()+"% USED\nNETWORK          "+Device.network(this)+"\nDISPLAY          "+Device.refresh(this)+"\nUPTIME           "+Device.uptime());}
    void updateTop(){
        if(keyTimer==null)return;
        if(expires==null||expires.isEmpty()||plan.toLowerCase(Locale.US).contains("life")){keyTimer.setText("LICENSE • "+plan.toUpperCase(Locale.US)+" • NO EXPIRY");return;}
        try{long end=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US).parse(expires).getTime(), left=Math.max(0,end-System.currentTimeMillis());long h=left/3600000,m=(left%3600000)/60000,s=(left%60000)/1000;keyTimer.setText(String.format(Locale.US,"LICENSE • %s • %02dh %02dm %02ds REMAINING",plan.toUpperCase(Locale.US),h,m,s));}catch(Exception e){keyTimer.setText("LICENSE • "+plan.toUpperCase(Locale.US));}
    }
    void animateEngine(TextView v,String start){beep();v.setText(start+"...\n");new Thread(()->{String[] x={"MAPPING MEMORY","CHECKING TEMP CACHE","TRIM HINTS","SCANNING ACTIVE PROCESS","SYNCING TELEMETRY","SCAN COMPLETE"};for(String s:x){runOnUiThread(()->v.append("> "+s+"\n"));SystemClock.sleep(220);}}).start();}
    void scanDir(File f,int[] count,long[] bytes){if(f==null||!f.exists())return;File[] a=f.listFiles();if(a==null)return;for(File x:a){if(x.isDirectory())scanDir(x,count,bytes);else{count[0]++;bytes[0]+=x.length();}}}
    void clearCache(File f){try{File[] a=f.listFiles();if(a!=null)for(File x:a){if(x.isDirectory())clearCache(x);if(x.isFile())x.delete();}}catch(Exception ignored){}}
    void beep(){try{new ToneGenerator(AudioManager.STREAM_NOTIFICATION,80).startTone(ToneGenerator.TONE_PROP_BEEP,120);}catch(Exception ignored){}}
    TextView section(String s,int c){TextView x=t(s,19,c);x.setTypeface(null,Typeface.BOLD);return x;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(16,16,16,16);l.setBackground(round(panel,Color.rgb(35,55,64),2,24));return l;}
    Button button(String s,float z,int c){Button b=new Button(this);b.setText(s);b.setTextSize(z);b.setTextColor(c);return b;}
    TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
    LinearLayout.LayoutParams lp(float w,int h,int m){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h);p.setMargins(0,m,0,m);return p;}
    GradientDrawable round(int c,int stroke,int sw,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);if(sw>0)g.setStroke(sw,stroke);return g;}
}
