SADEE X DIMA OPTIMIZER v4.0
==============================

Contents
- Android app: 5 pages
  1. Home / live device telemetry
  2. RAM Booster / Cleaner
  3. Storage Scanner / Cleaner
  4. Gaming / pre-launch optimizer
  5. Device details
- Supabase-backed license activation
- Dynamic remaining-time banner (hours/minutes/seconds)
- Device binding and last-seen telemetry
- Admin dashboard with 4 pages
  1. Key Generator
  2. License Database
  3. Bound Devices
  4. License Control

SETUP
1. Run SUPABASE_SETUP.sql in Supabase SQL Editor.
2. Keep the publishable Supabase key in the app/admin. Never put a service-role key in the frontend.
3. Put this ZIP in the GitHub repository root.
4. Add the workflow file supplied with this project as:
   .github/workflows/main.yml
5. Push to main.
6. Download the APK artifact:
   SADEE-X-DIMA-REAL-RELEASE
7. GitHub Pages deploys the admin-dashboard to the gh-pages branch.

REAL DEVICE FEATURES
- CPU core count, RAM, storage, Android version, model, network, display refresh and uptime are read from Android APIs.
- RAM cleaner only performs safe app-owned memory trim/GC. Android does not allow an ordinary app to forcibly free arbitrary RAM belonging to other apps.
- Storage cleaner clears this optimizer's own cache/temp files. It does not silently delete user files.
- Gaming page launches installed Free Fire / Free Fire MAX packages after a safe pre-launch routine. It does not inject code or modify game files.

ADMIN SECURITY
This requested no-login admin is intentionally simple, but it is NOT a secure commercial admin. Anyone who can reach the public admin page can attempt license writes when anon INSERT/UPDATE is allowed. For production, move admin mutations behind Supabase Auth or a protected Edge Function.
