SADEE X DIMA GREEN GAMING FINAL

This package preserves the original Android Java app, Supabase license binding,
the existing 5 user pages, and the existing 4-page admin dashboard.

UI update only:
- darker cyber black/green visual style
- logo retained
- license countdown remains visible
- RAM/storage/game operations keep their existing safe Android behavior
- beep/progress animations retained
- final optimizer still launches Free Fire when installed

Admin dashboard:
- Dashboard
- Licenses
- Devices
- Settings
- license generation auto-copies the generated key
