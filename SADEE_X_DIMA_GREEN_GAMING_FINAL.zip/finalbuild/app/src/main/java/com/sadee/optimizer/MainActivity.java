package com.sadee.optimizer;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONObject;

import java.io.File;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(0, 255, 128);
    private static final int GREEN2 = Color.rgb(0, 235, 135);
    private static final int CYAN = Color.rgb(30, 220, 255);
    private static final int PURPLE = Color.rgb(178, 105, 255);
    private static final int RED = Color.rgb(255, 85, 105);
    private static final int BG = Color.rgb(1, 5, 6);
    private static final int CARD = Color.rgb(5, 15, 13);
    private static final int CARD2 = Color.rgb(7, 22, 18);
    private static final int MUTED = Color.rgb(135, 153, 151);

    private LinearLayout root, content, nav;
    private TextView licenseTimer, topTitle;
    private JSONObject license;
    private String licenseKey = "";
    private String selectedPlan = "7 DAYS";
    private ToneGenerator tone;
    private int currentPage = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String[] pageNames = {"DEVICE", "RAM", "STORAGE", "GAMES", "OPTIMIZER"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85);
        showLogin();
    }

    private TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(12, 8, 12, 8);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.BLACK); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false);
        b.setBackground(makeBg(color, 16, color)); b.setPadding(12, 4, 12, 4);
        return b;
    }

    private GradientDrawable makeBg(int fill, float radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(radius);
        g.setStroke(1, stroke);
        return g;
    }

    private TextView section(String s, int color) {
        TextView t = tv(s, 19, color);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(4, 18, 4, 10);
        return t;
    }

    private void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16, 12, 16, 28);
        sv.addView(content); root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setPadding(5, 5, 5, 5); nav.setBackgroundColor(Color.rgb(6, 14, 14));
        root.addView(nav, new LinearLayout.LayoutParams(-1, 68));
        setContentView(root);
    }

    private ImageView logo() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.sadee_logo); image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        return image;
    }

    private void addHero(String title, String subtitle, String emoji) {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL); hero.setGravity(Gravity.CENTER);
        hero.setPadding(10, 8, 10, 14);
        hero.setBackground(makeBg(CARD, 22, Color.rgb(0, 90, 65)));
        ImageView mini = new ImageView(this);
        mini.setImageResource(R.drawable.sadee_logo);
        mini.setScaleType(ImageView.ScaleType.CENTER_CROP);
        mini.setBackground(makeBg(Color.rgb(4, 20, 16), 18, GREEN2));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(72, 72);
        mlp.gravity = Gravity.CENTER;
        mlp.setMargins(0, 2, 0, 5);
        hero.addView(mini, mlp);
        TextView e = tv(emoji, 30, Color.WHITE); e.setGravity(Gravity.CENTER); hero.addView(e);
        TextView h = tv(title, 23, Color.WHITE); h.setGravity(Gravity.CENTER); h.setTypeface(null, Typeface.BOLD); hero.addView(h);
        TextView s = tv(subtitle, 11, GREEN); s.setGravity(Gravity.CENTER); hero.addView(s);
        content.addView(hero, new LinearLayout.LayoutParams(-1, -2));
    }

    private void showLogin() {
        base();
        content.addView(logo(), new LinearLayout.LayoutParams(-1, 150));
        TextView h = tv("SADEE X DIMA", 30, Color.WHITE); h.setGravity(Gravity.CENTER); h.setTypeface(null, Typeface.BOLD); content.addView(h);
        TextView sub = tv("O P T I M I Z E R", 21, GREEN); sub.setGravity(Gravity.CENTER); sub.setTypeface(null, Typeface.BOLD); content.addView(sub);
        TextView tag = tv("// SECURE GAMING LICENSE //", 11, MUTED); tag.setGravity(Gravity.CENTER); content.addView(tag);

        LinearLayout card = card();
        card.setPadding(16, 16, 16, 16);
        card.setBackground(makeBg(Color.rgb(7, 16, 15), 22, GREEN2));
        content.addView(card);
        TextView label = tv("● LICENSE ACCESS", 18, GREEN); label.setTypeface(null, Typeface.BOLD); card.addView(label);
        TextView hint = tv("Enter your key and select your plan", 12, MUTED); card.addView(hint);

        EditText key = new EditText(this);
        key.setSingleLine(true); key.setTextColor(Color.WHITE); key.setHintTextColor(MUTED);
        key.setTextSize(17); key.setHint("SXD-XXXX-XXXX-XXXX"); key.setPadding(16, 10, 16, 10);
        key.setBackground(makeBg(Color.rgb(3, 11, 10), 15, GREEN2));
        card.addView(key, new LinearLayout.LayoutParams(-1, 60));

        TextView planTitle = tv("SELECT PLAN", 14, CYAN); planTitle.setTypeface(null, Typeface.BOLD); card.addView(planTitle);
        LinearLayout plans = new LinearLayout(this); plans.setOrientation(LinearLayout.VERTICAL); card.addView(plans);

        TextView status = tv("READY • SELECT A PLAN", 13, MUTED); status.setGravity(Gravity.CENTER); card.addView(status);
        Button verify = btn("✓  VERIFY & UNLOCK", GREEN); verify.setTextColor(Color.BLACK); card.addView(verify, new LinearLayout.LayoutParams(-1, 60));

        final TextView[] selected = new TextView[1];
        String[][] choices = {{"7 DAYS", "LKR 500"}, {"1 MONTH", "LKR 1,000"}, {"LIFETIME", "LKR 2,200"}};
        for (String[] c : choices) {
            TextView p = tv("", 15, Color.WHITE); p.setGravity(Gravity.CENTER_VERTICAL); p.setTypeface(null, Typeface.BOLD);
            p.setPadding(18, 0, 18, 0);
            p.setText(c[0] + "                                      " + c[1]);
            p.setBackground(makeBg(Color.rgb(8, 22, 19), 15, Color.rgb(25, 70, 55)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 58); lp.setMargins(0, 6, 0, 0); plans.addView(p, lp);
            p.setOnClickListener(v -> {
                selectedPlan = c[0];
                if (selected[0] != null) selected[0].setBackground(makeBg(Color.rgb(8, 22, 19), 15, Color.rgb(25, 70, 55)));
                p.setBackground(makeBg(Color.rgb(2, 42, 28), 15, GREEN));
                selected[0] = p;
                status.setText("SELECTED • " + selectedPlan);
                beep(1);
            });
        }
        ((TextView) plans.getChildAt(0)).performClick();

        verify.setOnClickListener(v -> {
            String k = key.getText().toString().trim().toUpperCase(Locale.US);
            if (k.isEmpty()) { status.setText("ENTER A LICENSE KEY"); beep(2); return; }
            verify.setEnabled(false); status.setText("● VERIFYING LICENSE • PLEASE WAIT"); beep(1);
            new Thread(() -> {
                try {
                    String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    license = Supabase.verifyAndBind(k, device, this);
                    licenseKey = k;
                    runOnUiThread(() -> { beep(3); showApp(); });
                } catch (Exception e) {
                    runOnUiThread(() -> { verify.setEnabled(true); status.setText(e.getMessage() == null ? "VERIFY FAILED" : e.getMessage()); beep(2); });
                }
            }).start();
        });

        content.addView(section("💚 CHOOSE YOUR PLAN", CYAN));
        addPlan("7 DAYS", "LKR 500");
        addPlan("1 MONTH", "LKR 1,000");
        addPlan("LIFETIME", "LKR 2,200");
        TextView foot = tv("1 LICENSE = 1 DEVICE • DEVICE BINDING + EXPIRY PROTECTION", 12, MUTED); foot.setGravity(Gravity.CENTER); content.addView(foot);
    }

    private void addPlan(String plan, String price) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(12, 5, 12, 5); row.setBackground(makeBg(Color.rgb(7, 18, 16), 15, Color.rgb(22, 60, 48)));
        TextView left = tv("◆  " + plan, 16, Color.WHITE); left.setTypeface(null, Typeface.BOLD); row.addView(left, new LinearLayout.LayoutParams(0, 56, 1));
        TextView right = tv(price + "\nBUY • WHATSAPP", 13, GREEN); right.setGravity(Gravity.RIGHT); row.addView(right, new LinearLayout.LayoutParams(150, 56));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 68); lp.setMargins(0, 5, 0, 5); content.addView(row, lp);
        row.setOnClickListener(v -> { beep(1); Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + Config.WHATSAPP + "?text=" + Uri.encode("SADEE X DIMA OPTIMIZER - " + plan + " - " + price))); startActivity(i); });
    }

    private void showApp() {
        base();
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(4, 0, 4, 4);
        top.addView(logo(), new LinearLayout.LayoutParams(66, 66));
        topTitle = tv("SADEE X DIMA\nOPTIMIZER", 20, GREEN); topTitle.setTypeface(null, Typeface.BOLD); top.addView(topTitle, new LinearLayout.LayoutParams(0, 66, 1));
        content.addView(top);
        licenseTimer = tv("", 12, CYAN); licenseTimer.setTypeface(null, Typeface.BOLD); licenseTimer.setGravity(Gravity.CENTER); licenseTimer.setPadding(12, 13, 12, 13);
        licenseTimer.setBackground(makeBg(Color.rgb(3, 30, 22), 16, GREEN2)); content.addView(licenseTimer);
        TextView line = tv("● ONLINE   //   LICENSE VERIFIED   //   SECURE SESSION", 10, GREEN); line.setGravity(Gravity.CENTER); line.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        content.addView(line);
        TextView engine = tv("╔══ SADEE X DIMA OPTIMIZER ENGINE ══╗\n║  RAM  •  STORAGE  •  GAME MODE  •  LIVE DEVICE  ║\n╚════════════════════════════════════╝", 9, Color.rgb(90, 255, 190));
        engine.setGravity(Gravity.CENTER); engine.setTypeface(Typeface.MONOSPACE); engine.setPadding(4, 8, 4, 12); content.addView(engine);
        updateLicenseTimer();
        handler.postDelayed(new Runnable() { @Override public void run() { if (!isFinishing() && license != null) { updateLicenseTimer(); handler.postDelayed(this, 1000); } } }, 1000);
        showPage(0);
        for (int i = 0; i < pageNames.length; i++) {
            final int p = i; Button b = btn(pageNames[i], Color.rgb(10, 25, 22)); b.setTextSize(10); b.setTextColor(i == 0 ? GREEN : Color.LTGRAY);
            nav.addView(b, new LinearLayout.LayoutParams(0, -1, 1)); b.setOnClickListener(v -> { showPage(p); for (int j=0;j<nav.getChildCount();j++) ((Button)nav.getChildAt(j)).setTextColor(j==p?GREEN:Color.LTGRAY); });
        }
    }

    private void updateLicenseTimer() {
        if (license == null || licenseTimer == null) return;
        String exp = license.optString("expires_at", "");
        String plan = license.optString("plan", "ACTIVE");
        licenseTimer.setText("🔑 " + licenseKey + "   •   " + plan.toUpperCase(Locale.US) + "   •   " + remaining(exp));
    }

    private String remaining(String exp) {
        if (exp == null || exp.trim().isEmpty() || "null".equalsIgnoreCase(exp)) return "LIFETIME • NO EXPIRY";
        Date d = parseDate(exp); if (d == null) return "TIME UNKNOWN";
        long ms = d.getTime() - System.currentTimeMillis(); if (ms <= 0) return "0h 0m REMAINING";
        long h = ms / 3600000L; long m = (ms % 3600000L) / 60000L;
        return h + "h " + m + "m REMAINING";
    }

    private Date parseDate(String s) {
        String[] formats = {"yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String f : formats) { try { SimpleDateFormat df = new SimpleDateFormat(f, Locale.US); df.setTimeZone(TimeZone.getTimeZone("UTC")); Date d = df.parse(s, new ParsePosition(0)); if (d != null) return d; } catch (Exception ignored) {} }
        return null;
    }

    private void showPage(int p) {
        currentPage = p; content.removeAllViews();
        if (p == 0) { addHero("DEVICE CENTER", "LIVE PHONE INFORMATION", "📱"); devicePage(); }
        else if (p == 1) { addHero("RAM BOOSTER", "MEMORY • PERFORMANCE • CLEANUP", "🧠"); ramPage(); }
        else if (p == 2) { addHero("ALL FILE CLEANER", "SAFE ACCESSIBLE FILE CLEANUP", "🧹"); storagePage(); }
        else if (p == 3) { addHero("GAMES", "GAME BOOSTER • FREE FIRE", "🎮"); gamePage(); }
        else { addHero("SADEE X DIMA OPTIMIZED", "ONE TAP → FREE FIRE", "⚡"); optimizePage(); }
    }

    private void devicePage() {
        LinearLayout card = card();
        TextView info = tv("", 14, Color.WHITE); info.setTypeface(Typeface.MONOSPACE); card.addView(info);
        Runnable refresh = () -> info.setText(DeviceInfo.get(this)); refresh.run();
        handler.postDelayed(new Runnable() { @Override public void run() { if (currentPage == 0 && !isFinishing()) { refresh.run(); handler.postDelayed(this, 1500); } } }, 1500);
        content.addView(card);
        content.addView(section("📊 LIVE MONITOR", CYAN));
        content.addView(tv("RAM • STORAGE • NETWORK • BATTERY values refresh automatically.", 12, MUTED));
    }

    private void ramPage() {
        content.addView(infoCard("🧠 RAM BOOSTER", "Scan memory, release this app's unused memory and clear optimizer cache safely."));
        addAction("🧠 RAM SCAN", () -> runAnim("SCANNING MEMORY", () -> Toast.makeText(this, DeviceInfo.memorySummary(this), Toast.LENGTH_SHORT).show()));
        addAction("🚀 RAM BOOSTER", () -> runAnim("BOOSTING PERFORMANCE", () -> { System.gc(); trimMemory(); }));
        addAction("🧹 RAM CACHE CLEANER", () -> runAnim("CLEARING OPTIMIZER CACHE", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        content.addView(infoCard("ANDROID SAFETY", "Normal Android apps cannot silently kill other apps or force-free system RAM. These actions use permitted app-owned cleanup only."));
    }

    private void trimMemory() { try { android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE); if (am != null) am.getMemoryInfo(new android.app.ActivityManager.MemoryInfo()); } catch (Exception ignored) {} }

    private void storagePage() {
        content.addView(infoCard("🧹 ALL FILE CLEANER", "Cleans files owned by SADEE X DIMA and opens Android's storage controls for protected files."));
        addAction("🔍 SCAN ALL ACCESSIBLE FILES", () -> runAnim("SCANNING ACCESSIBLE FILES", () -> Toast.makeText(this, DeviceInfo.storageSummary(this), Toast.LENGTH_LONG).show()));
        addAction("🧹 CLEAN OPTIMIZER FILES", () -> runAnim("CLEANING OPTIMIZER FILES", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        addAction("📂 MANAGE ALL FILES", this::openStorageAccess);
        addAction("⚙️ ANDROID STORAGE", () -> { try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
    }

    private void openStorageAccess() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            i.setData(Uri.parse("package:" + getPackageName())); startActivity(i);
        } catch (Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
    }

    private void gamePage() {
        content.addView(infoCard("🚀 GAME BOOSTER", "Pre-launch cleanup + memory refresh, then launch the selected game."));
        addGameCard("FREE FIRE", "com.dts.freefireth", "🔥");
        addGameCard("FREE FIRE MAX", "com.dts.freefiremax", "🔥");
        addAction("⚡ GAME BOOSTER → FREE FIRE", () -> runGameBooster("FREE FIRE", "com.dts.freefireth"));
        addAction("⚡ GAME BOOSTER → FREE FIRE MAX", () -> runGameBooster("FREE FIRE MAX", "com.dts.freefiremax"));
        content.addView(infoCard("GAME MODE", "SADEE X DIMA does not inject, modify, or cheat inside game files. It prepares the phone using safe Android operations and then launches the game."));
    }

    private void addGameCard(String name, String pkg, String emoji) {
        LinearLayout c = card();
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = tv(emoji, 35, Color.WHITE); row.addView(icon, new LinearLayout.LayoutParams(60, 60));
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        TextView n = tv(name, 18, Color.WHITE); n.setTypeface(null, Typeface.BOLD); texts.addView(n);
        TextView s = tv(isInstalled(pkg) ? "🟢 INSTALLED • READY" : "🔴 NOT INSTALLED", 11, isInstalled(pkg)?GREEN:RED); texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, 70, 1));
        Button b = btn("PLAY", GREEN); b.setTextSize(11); row.addView(b, new LinearLayout.LayoutParams(90, 52));
        b.setOnClickListener(v -> runGameBooster(name, pkg));
        c.addView(row); content.addView(c);
    }

    private boolean isInstalled(String pkg) { try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; } }

    private void runGameBooster(String name, String pkg) {
        beep(2);
        if (!isInstalled(pkg)) { Toast.makeText(this, name + " not installed", Toast.LENGTH_LONG).show(); return; }
        String[] steps = {"GAME BOOSTER STARTING", "REFRESHING MEMORY", "CLEARING OPTIMIZER CACHE", "PREPARING " + name, "LAUNCHING " + name};
        ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA • GAME BOOSTER"); d.setMessage(steps[0]); d.setIndeterminate(false); d.setMax(steps.length); d.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); d.setCancelable(false); d.show();
        final int[] i = {0};
        Runnable tick = new Runnable() { @Override public void run() {
            if (i[0] < steps.length) { d.setProgress(i[0] + 1); d.setMessage(steps[i[0]]); if(i[0] == 1) trimMemory(); if(i[0] == 2){ clearCache(getCacheDir()); if(getExternalCacheDir()!=null) clearCache(getExternalCacheDir()); } i[0]++; handler.postDelayed(this, 550); }
            else { d.dismiss(); launchGame(pkg); }
        }};
        handler.post(tick);
    }

    private void launchGame(String pkg) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) { Toast.makeText(this, "GAME LAUNCHER NOT FOUND", Toast.LENGTH_LONG).show(); return; }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) { Toast.makeText(this, "GAME LAUNCH FAILED", Toast.LENGTH_LONG).show(); }
    }

    private void addAction(String label, Runnable r) {
        Button b = btn("  ▸  " + label + "  ◂  ", Color.rgb(5, 28, 20));
        b.setTextColor(GREEN); b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setPadding(18, 4, 18, 4);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 60); lp.setMargins(0, 4, 0, 6);
        content.addView(b, lp); b.setOnClickListener(v -> { beep(1); r.run(); });
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(14, 14, 14, 14); c.setBackground(makeBg(CARD, 18, Color.rgb(22, 65, 53)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 5, 0, 8); c.setLayoutParams(lp); return c;
    }

    private LinearLayout infoCard(String title, String body) {
        LinearLayout c = card();
        TextView h = tv(title, 17, GREEN); h.setTypeface(null, Typeface.BOLD); c.addView(h);
        TextView b = tv(body, 12, MUTED); c.addView(b);
        content.addView(c); return c;
    }

    private void runAnim(String msg, Runnable done) {
        beep(2);
        ProgressDialog d = new ProgressDialog(this);
        d.setTitle("SADEE X DIMA // OPTIMIZER ENGINE");
        d.setMessage(">> " + msg + "...\n[████████░░]  SYSTEM OPERATION\n>> CHECKING PERMITTED ANDROID RESOURCES");
        d.setIndeterminate(true); d.setCancelable(false); d.show();
        handler.postDelayed(() -> {
            d.dismiss(); beep(2);
            Toast.makeText(this, "✓ " + msg + " COMPLETE", Toast.LENGTH_SHORT).show();
            done.run();
            try { ((android.os.Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(100); } catch (Exception ignored) {}
        }, 1400);
    }

    private void optimizePage() {
        content.addView(infoCard("⚡ SADEE X DIMA OPTIMIZED", "ONE TAP GAME MODE • FREE FIRE AUTO LAUNCH"));
        TextView log = tv("SYSTEM LOG\n> License verified\n> Device session online\n> Target game: FREE FIRE\n> READY", 13, Color.LTGRAY); log.setTypeface(Typeface.MONOSPACE); content.addView(log);
        Button b = btn("🔥  SADEE X DIMA OPTIMIZED  →  FREE FIRE", GREEN); content.addView(b, new LinearLayout.LayoutParams(-1, 64));
        b.setOnClickListener(v -> runOptimization(log));
    }

    private void runOptimization(TextView log) {
        beep(2);
        if (!isInstalled("com.dts.freefireth")) {
            Toast.makeText(this, "FREE FIRE IS NOT INSTALLED", Toast.LENGTH_LONG).show();
            return;
        }
        String[] steps = {"Imported profile", "Scanning device", "Clearing optimizer cache", "Refreshing memory metrics", "Preparing FREE FIRE", "Launching FREE FIRE"};
        final int[] i = {0}; ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA // GAME MODE"); d.setMessage("Starting..."); d.setIndeterminate(false); d.setMax(steps.length); d.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); d.setCancelable(false); d.show();
        Runnable tick = new Runnable() { @Override public void run() {
            if (i[0] < steps.length) { d.setProgress(i[0] + 1); log.setText("SYSTEM LOG\n> " + steps[i[0]] + "\n> STATUS: RUNNING"); if(i[0]==2){clearCache(getCacheDir()); if(getExternalCacheDir()!=null)clearCache(getExternalCacheDir());} if(i[0]==3)trimMemory(); i[0]++; handler.postDelayed(this, 600); }
            else { d.dismiss(); beep(4); log.setText("SYSTEM LOG\n> SADEE X DIMA OPTIMIZED\n> STATUS: COMPLETE\n> GAME: FREE FIRE\n> LAUNCHING..."); Toast.makeText(MainActivity.this, "SADEE X DIMA OPTIMIZED • FREE FIRE", Toast.LENGTH_SHORT).show(); handler.postDelayed(() -> launchGame("com.dts.freefireth"), 250); }
        }}; handler.post(tick);
    }

    private void beep(int count) {
        try {
            if (tone == null) tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85);
            final int[] n = {0};
            Runnable r = new Runnable() { @Override public void run() {
                if (n[0]++ < count) {
                    tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 110);
                    handler.postDelayed(this, 150);
                }
            }};
            handler.post(r);
        } catch (Exception ignored) {}
    }

    private void clearCache(File f) { if (f == null) return; File[] fs = f.listFiles(); if (fs != null) for (File x : fs) { if (x.isDirectory()) clearCache(x); else x.delete(); } }
}
