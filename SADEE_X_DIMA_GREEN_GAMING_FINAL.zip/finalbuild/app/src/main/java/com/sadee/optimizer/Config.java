package com.sadee.optimizer;

public final class Config {
    public static final String SUPABASE_URL = "https://cpmzjplfqggmgeotmtcd.supabase.co";
    public static final String SUPABASE_KEY = "sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW";
    public static final String WHATSAPP = "94768472404";
    private Config() {}
}
