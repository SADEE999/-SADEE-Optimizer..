package com.sadee.optimizer;

import android.content.Context;
import android.os.Build;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

public final class Supabase {
    private Supabase() {}
    private static HttpsURLConnection conn(String path,String method)throws Exception{URL u=new URL(Config.SUPABASE_URL+"/rest/v1/"+path);HttpsURLConnection c=(HttpsURLConnection)u.openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("apikey",Config.SUPABASE_KEY);c.setRequestProperty("Authorization","Bearer "+Config.SUPABASE_KEY);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");c.setRequestProperty("Prefer","return=representation");return c;}
    private static String body(HttpsURLConnection c,String json)throws Exception{if(json!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(json.getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();InputStream is=code>=200&&code<400?c.getInputStream():c.getErrorStream();String s=read(is);if(code<200||code>=300)throw new IOException("HTTP "+code+": "+s);return s;}
    private static String read(InputStream in)throws Exception{if(in==null)return "";StringBuilder s=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String x;while((x=r.readLine())!=null)s.append(x);}return s.toString();}
    public static JSONObject verifyAndBind(String key,String device,Context ctx)throws Exception{
        String cleanKey = key == null ? "" : key.trim().toUpperCase(Locale.US);
        String cleanDevice = device == null ? "" : device.trim();
        if(cleanKey.isEmpty()) throw new Exception("ENTER A LICENSE KEY");
        if(cleanDevice.isEmpty()) throw new Exception("DEVICE ID UNAVAILABLE");

        String enc=URLEncoder.encode(cleanKey,"UTF-8");
        String select="license_key,status,device_id,activated_at,expires_at,plan,price,device_model,device_ram,device_storage,device_cpu,android_version,network_type,bound_at";
        String path="licenses?select="+URLEncoder.encode(select,"UTF-8")+"&license_key=eq."+enc+"&limit=1";

        String s=body(conn(path,"GET"),null);
        JSONArray a=new JSONArray(s);
        if(a.length()==0)throw new Exception("INVALID LICENSE");

        JSONObject o=a.getJSONObject(0);
        String status=readNullable(o,"status","unused").toLowerCase(Locale.US);

        if("expired".equals(status))throw new Exception("LICENSE EXPIRED");
        if("paused".equals(status))throw new Exception("LICENSE PAUSED");

        String exp=readNullable(o,"expires_at","");
        if(expired(exp)){
            try{
                JSONObject p=new JSONObject();
                p.put("status","expired");
                body(conn("licenses?license_key=eq."+enc,"PATCH"),p.toString());
            }catch(Exception ignored){}
            throw new Exception("LICENSE EXPIRED");
        }

        String bound=readNullable(o,"device_id","");

        // NULL/empty device_id means the license has never been bound.
        // Only a non-empty DIFFERENT device id is considered already bound.
        if(!bound.isEmpty() && !bound.equals(cleanDevice)){
            throw new Exception("LICENSE ALREADY BOUND TO ANOTHER DEVICE");
        }

        // First activation: claim only an unused, unbound row.
        if(bound.isEmpty()){
            JSONObject p=new JSONObject();
            p.put("status","active");
            p.put("device_id",cleanDevice);
            p.put("activated_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US).format(new Date()));

            String claimPath="licenses?license_key=eq."+enc+"&device_id=is.null&status=eq.unused";
            String updated=body(conn(claimPath,"PATCH"),p.toString());

            if(updated==null || updated.trim().isEmpty() || "[]".equals(updated.trim())){
                // The claim may have raced with another device. Re-read the server row.
                String check=body(conn(path,"GET"),null);
                JSONArray ca=new JSONArray(check);
                if(ca.length()==0)throw new Exception("INVALID LICENSE");
                o=ca.getJSONObject(0);
                bound=readNullable(o,"device_id","");
                if(!bound.isEmpty() && !bound.equals(cleanDevice)){
                    throw new Exception("LICENSE ALREADY BOUND TO ANOTHER DEVICE");
                }
                if(bound.isEmpty()){
                    throw new Exception("LICENSE COULD NOT BE ACTIVATED");
                }
            }else{
                try{o=new JSONArray(updated).getJSONObject(0);}catch(Exception ignored){}
            }

            // Metadata is optional. A metadata-column/API failure must never undo login.
            try{
                JSONObject meta=new JSONObject();
                meta.put("device_model",Build.MANUFACTURER+" "+Build.MODEL);
                meta.put("device_ram",DeviceInfo.memorySummary(ctx));
                meta.put("device_storage",DeviceInfo.storageSummary(ctx));
                meta.put("device_cpu",Runtime.getRuntime().availableProcessors()+" cores");
                meta.put("android_version",Build.VERSION.RELEASE+" / API "+Build.VERSION.SDK_INT);
                String info=DeviceInfo.get(ctx);
                String marker="NETWORK  : ";
                int ni=info.indexOf(marker);
                if(ni>=0){
                    String nv=info.substring(ni+marker.length()).split("\\n")[0].trim();
                    meta.put("network_type",nv);
                }
                meta.put("bound_at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US).format(new Date()));
                body(conn("licenses?license_key=eq."+enc,"PATCH"),meta.toString());
            }catch(Exception ignored){}

            try{
                String finalRow=body(conn(path,"GET"),null);
                JSONArray fa=new JSONArray(finalRow);
                if(fa.length()>0)o=fa.getJSONObject(0);
            }catch(Exception ignored){}
        }

        return o;
    }

    private static String readNullable(JSONObject o,String key,String fallback){
        if(o==null || !o.has(key) || o.isNull(key)) return fallback;
        String v=o.optString(key,fallback);
        return v==null || "null".equalsIgnoreCase(v.trim()) ? fallback : v.trim();
    }

    private static boolean expired(String s){if(s==null||s.trim().isEmpty()||"null".equalsIgnoreCase(s))return false;String[] fs={"yyyy-MM-dd'T'HH:mm:ss.SSSXXX","yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String f:fs){try{SimpleDateFormat d=new SimpleDateFormat(f,Locale.US);d.setTimeZone(TimeZone.getTimeZone("UTC"));Date x=d.parse(s);if(x!=null)return x.getTime()<=System.currentTimeMillis();}catch(Exception ignored){}}return false;}
}
