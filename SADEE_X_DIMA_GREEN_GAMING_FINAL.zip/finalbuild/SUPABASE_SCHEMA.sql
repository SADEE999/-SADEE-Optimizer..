-- SADEE X DIMA - REAL SUPABASE MIGRATION
-- Safe for the existing public.licenses table.
-- Existing license rows are preserved.

-- Missing columns used by the Android app + admin dashboard.
alter table public.licenses add column if not exists license_key text;
alter table public.licenses add column if not exists plan text;
alter table public.licenses add column if not exists price integer not null default 0;
alter table public.licenses add column if not exists status text not null default 'unused';
alter table public.licenses add column if not exists device_id text;
alter table public.licenses add column if not exists device_model text;
alter table public.licenses add column if not exists device_ram text;
alter table public.licenses add column if not exists device_storage text;
alter table public.licenses add column if not exists device_cpu text;
alter table public.licenses add column if not exists android_version text;
alter table public.licenses add column if not exists network_type text;
alter table public.licenses add column if not exists activated_at timestamptz;
alter table public.licenses add column if not exists bound_at timestamptz;
alter table public.licenses add column if not exists expires_at timestamptz;
alter table public.licenses add column if not exists created_at timestamptz not null default now();

-- Keep the legacy "key" column if it exists, but use license_key everywhere.
update public.licenses
set license_key = coalesce(nullif(license_key,''), nullif("key",''))
where license_key is null or license_key = '';

-- Normalize status values before recreating the check constraint.
update public.licenses
set status = lower(trim(status))
where status is not null;

update public.licenses
set status = 'unused'
where status is null or status not in ('unused','active','paused','expired');

do $$
begin
  if exists (
    select 1 from pg_constraint
    where conname = 'licenses_status_check'
      and conrelid = 'public.licenses'::regclass
  ) then
    alter table public.licenses drop constraint licenses_status_check;
  end if;
exception when undefined_table then
  null;
end $$;

alter table public.licenses
  add constraint licenses_status_check
  check (lower(status) in ('unused','active','paused','expired'));

-- Useful indexes. Duplicate-safe.
create index if not exists licenses_license_key_idx on public.licenses(license_key);
create index if not exists licenses_status_idx on public.licenses(status);
create index if not exists licenses_device_id_idx on public.licenses(device_id);

-- RLS / REST permissions used by the current no-login dashboard and app.
alter table public.licenses enable row level security;
grant usage on schema public to anon;
grant select, insert, update, delete on public.licenses to anon;

drop policy if exists licenses_select on public.licenses;
drop policy if exists licenses_insert on public.licenses;
drop policy if exists licenses_update on public.licenses;
drop policy if exists licenses_delete on public.licenses;
drop policy if exists public_read_licenses on public.licenses;
drop policy if exists public_insert_licenses on public.licenses;
drop policy if exists public_update_licenses on public.licenses;
drop policy if exists public_delete_licenses on public.licenses;

create policy licenses_select
on public.licenses for select to anon using (true);

create policy licenses_insert
on public.licenses for insert to anon with check (true);

create policy licenses_update
on public.licenses for update to anon using (true) with check (true);

create policy licenses_delete
on public.licenses for delete to anon using (true);

notify pgrst, 'reload schema';
