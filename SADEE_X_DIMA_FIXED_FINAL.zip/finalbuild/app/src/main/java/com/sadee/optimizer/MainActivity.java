package com.sadee.optimizer;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONObject;

import java.io.File;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(0, 245, 154);
    private static final int CYAN = Color.rgb(20, 220, 255);
    private static final int PURPLE = Color.rgb(177, 111, 255);
    private static final int BG = Color.rgb(2, 6, 8);
    private static final int CARD = Color.rgb(13, 19, 22);
    private static final int INPUT = Color.rgb(8, 13, 16);
    private static final int MUTED = Color.rgb(130, 143, 148);

    private LinearLayout root, content, nav;
    private TextView licenseTimer, topTitle;
    private JSONObject license;
    private String licenseKey = "";
    private int currentPage = 0;
    private String selectedPackage = null;
    private String selectedGameName = null;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String[] pageNames = {"DEVICE", "RAM", "STORAGE", "GAMES", "OPTIMIZER"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showLogin();
    }

    private TextView tv(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(16, 10, 16, 10);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.BLACK); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false);
        b.setBackgroundColor(color); b.setPadding(12, 4, 12, 4);
        return b;
    }

    private TextView section(String s, int color) {
        TextView t = tv(s, 19, color);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(4, 18, 4, 10);
        return t;
    }

    private void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(20, 14, 20, 24);
        sv.addView(content); root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setPadding(4, 4, 4, 4); nav.setBackgroundColor(Color.rgb(8, 13, 15));
        root.addView(nav, new LinearLayout.LayoutParams(-1, 66));
        setContentView(root);
    }

    private ImageView logo() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.sadee_logo); image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        return image;
    }

    private void showLogin() {
        base();
        content.addView(logo(), new LinearLayout.LayoutParams(-1, 205));
        TextView h = tv("SADEE X DIMA", 29, Color.WHITE); h.setGravity(Gravity.CENTER); h.setTypeface(null, Typeface.BOLD); content.addView(h);
        TextView sub = tv("O P T I M I Z E R", 21, GREEN); sub.setGravity(Gravity.CENTER); sub.setTypeface(null, Typeface.BOLD); content.addView(sub);

        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(14, 16, 14, 16); card.setBackgroundColor(CARD);
        content.addView(card, new LinearLayout.LayoutParams(-1, -2));
        TextView label = tv("VERIFYING LICENSE ACCESS", 19, GREEN); label.setTypeface(null, Typeface.BOLD); card.addView(label);

        EditText key = new EditText(this); key.setSingleLine(true); key.setTextColor(Color.WHITE); key.setHintTextColor(MUTED);
        key.setTextSize(17); key.setHint("SXD-XXXX-XXXX-XXXX"); key.setPadding(16, 10, 16, 10); card.addView(key, new LinearLayout.LayoutParams(-1, 58));
        Button verify = btn("VERIFY & UNLOCK", PURPLE); card.addView(verify, new LinearLayout.LayoutParams(-1, 58));
        TextView status = tv("Paste a valid key to unlock the optimizer.", 14, MUTED); status.setGravity(Gravity.CENTER); card.addView(status);

        verify.setOnClickListener(v -> {
            String k = key.getText().toString().trim().toUpperCase(Locale.US);
            if (k.isEmpty()) { status.setText("ENTER A LICENSE KEY"); return; }
            verify.setEnabled(false); status.setText("VERIFYING LICENSE...");
            new Thread(() -> {
                try {
                    String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                    license = Supabase.verifyAndBind(k, device, this);
                    licenseKey = k;
                    runOnUiThread(this::showApp);
                } catch (Exception e) {
                    runOnUiThread(() -> { verify.setEnabled(true); status.setText(e.getMessage() == null ? "VERIFY FAILED" : e.getMessage()); });
                }
            }).start();
        });

        content.addView(section("CHOOSE YOUR PLAN", CYAN));
        addPlan("7 DAYS", "LKR 500", "7 days");
        addPlan("1 MONTH", "LKR 1,000", "30 days");
        addPlan("LIFETIME", "LKR 2,200", "Lifetime");
        TextView foot = tv("1 LICENSE = 1 DEVICE • DEVICE BINDING + EXPIRY PROTECTION", 12, MUTED); foot.setGravity(Gravity.CENTER); content.addView(foot);
    }

    private void addPlan(String plan, String price, String value) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(12, 6, 12, 6); row.setBackgroundColor(Color.rgb(16, 22, 25));
        TextView left = tv(plan, 16, Color.WHITE); left.setTypeface(null, Typeface.BOLD); row.addView(left, new LinearLayout.LayoutParams(0, 56, 1));
        TextView right = tv(price + "\nBUY • WHATSAPP", 14, GREEN); right.setGravity(Gravity.RIGHT); row.addView(right, new LinearLayout.LayoutParams(145, 56));
        content.addView(row, new LinearLayout.LayoutParams(-1, 68));
        row.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + Config.WHATSAPP + "?text=" + Uri.encode("SADEE X DIMA OPTIMIZER - " + plan + " - " + price))); startActivity(i); });
    }

    private void showApp() {
        base();
        topTitle = tv("● SADEE X DIMA", 22, GREEN); topTitle.setTypeface(null, Typeface.BOLD); content.addView(topTitle);
        licenseTimer = tv("", 13, CYAN); licenseTimer.setTypeface(null, Typeface.BOLD); content.addView(licenseTimer);
        TextView line = tv("ONLINE • LICENSE VERIFIED • SECURE DEVICE SESSION", 11, MUTED); content.addView(line);
        updateLicenseTimer();
        handler.postDelayed(new Runnable() { @Override public void run() { if (!isFinishing() && license != null) { updateLicenseTimer(); handler.postDelayed(this, 1000); } } }, 1000);
        showPage(0);
        for (int i = 0; i < pageNames.length; i++) {
            final int p = i; Button b = btn(pageNames[i], Color.rgb(15, 25, 28)); b.setTextColor(i == 0 ? GREEN : Color.LTGRAY);
            nav.addView(b, new LinearLayout.LayoutParams(0, -1, 1)); b.setOnClickListener(v -> showPage(p));
        }
    }

    private void updateLicenseTimer() {
        if (license == null || licenseTimer == null) return;
        String exp = license.optString("expires_at", "");
        String plan = license.optString("plan", "ACTIVE");
        licenseTimer.setText("🔑 " + licenseKey + "    •    " + plan.toUpperCase(Locale.US) + "    •    " + remaining(exp));
    }

    private String remaining(String exp) {
        if (exp == null || exp.trim().isEmpty() || "null".equalsIgnoreCase(exp)) return "LIFETIME • NO EXPIRY";
        Date d = parseDate(exp); if (d == null) return "TIME UNKNOWN";
        long ms = d.getTime() - System.currentTimeMillis(); if (ms <= 0) return "0h 0m REMAINING";
        long h = ms / 3600000L; long m = (ms % 3600000L) / 60000L;
        return h + "h " + m + "m REMAINING";
    }

    private Date parseDate(String s) {
        String[] formats = {"yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String f : formats) { try { SimpleDateFormat df = new SimpleDateFormat(f, Locale.US); df.setTimeZone(TimeZone.getTimeZone("UTC")); Date d = df.parse(s, new ParsePosition(0)); if (d != null) return d; } catch (Exception ignored) {} }
        return null;
    }

    private void showPage(int p) {
        currentPage = p; content.removeAllViews();
        TextView h = section(pageNames[p] + " // ONLINE", GREEN); content.addView(h);
        if (p == 0) devicePage(); else if (p == 1) ramPage(); else if (p == 2) storagePage(); else if (p == 3) gamePage(); else optimizePage();
    }

    private void devicePage() {
        TextView info = tv("", 14, Color.WHITE); info.setTypeface(Typeface.MONOSPACE); content.addView(info);
        Runnable refresh = () -> info.setText(DeviceInfo.get(this)); refresh.run();
        handler.postDelayed(new Runnable() { @Override public void run() { if (currentPage == 0 && !isFinishing()) { refresh.run(); handler.postDelayed(this, 1500); } } }, 1500);
        content.addView(section("LIVE MONITOR", CYAN));
        content.addView(tv("RAM / storage / network values refresh automatically. Device data is read from Android APIs.", 13, MUTED));
    }

    private void ramPage() {
        content.addView(tv("MEMORY TOOLS // SAFE ANDROID OPERATIONS", 13, CYAN));
        addAction("RAM SCAN", () -> runAnim("SCANNING MEMORY", () -> Toast.makeText(this, DeviceInfo.memorySummary(this), Toast.LENGTH_SHORT).show()));
        addAction("RAM CLEANER", () -> runAnim("RELEASING THIS APP'S MEMORY", () -> { System.gc(); trimMemory(); }));
        addAction("RAM CLEAR", () -> runAnim("CLEARING OPTIMIZER CACHE", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        content.addView(tv("Note: Android does not allow a normal app to silently kill other apps or clear their RAM. These controls perform safe operations available to this app.", 12, MUTED));
    }

    private void trimMemory() { try { android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE); if (am != null) am.getMemoryInfo(new android.app.ActivityManager.MemoryInfo()); } catch (Exception ignored) {} }

    private void storagePage() {
        content.addView(tv(DeviceInfo.storageSummary(this), 14, Color.WHITE));
        addAction("STORAGE SCAN", () -> runAnim("SCANNING STORAGE", () -> Toast.makeText(this, DeviceInfo.storageSummary(this), Toast.LENGTH_SHORT).show()));
        addAction("CLEAR OPTIMIZER CACHE", () -> runAnim("CLEARING CACHE", () -> { clearCache(getCacheDir()); if (getExternalCacheDir() != null) clearCache(getExternalCacheDir()); }));
        addAction("OPEN ANDROID STORAGE", () -> { try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
    }

    private void addAction(String label, Runnable r) {
        Button b = btn("⚡  " + label, Color.rgb(12, 23, 24)); b.setTextColor(GREEN); b.setGravity(Gravity.CENTER_VERTICAL); content.addView(b, new LinearLayout.LayoutParams(-1, 58)); b.setOnClickListener(v -> r.run());
    }

    private void runAnim(String msg, Runnable done) {
        ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA // OPTIMIZER"); d.setMessage(msg + "...\n[████████░░] SYSTEM OPERATION"); d.setIndeterminate(true); d.setCancelable(false); d.show();
        handler.postDelayed(() -> { d.dismiss(); Toast.makeText(this, msg + " COMPLETE", Toast.LENGTH_SHORT).show(); done.run(); try { ((android.os.Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(100); } catch (Exception ignored) {} }, 1200);
    }

    private void gamePage() {
        content.addView(tv("GAME / APP LAUNCHER", 13, CYAN));
        content.addView(tv("Choose an installed app. SADEE X DIMA will run the selected app after the optimizer animation.", 12, MUTED));
        PackageManager pm = getPackageManager(); Intent q = new Intent(Intent.ACTION_MAIN, null); q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(q, PackageManager.MATCH_ALL);
        for (ResolveInfo ri : list) {
            String n = ri.loadLabel(pm).toString(); String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            Button b = btn("▶  " + n, Color.rgb(13, 23, 25)); b.setTextColor(Color.WHITE); content.addView(b, new LinearLayout.LayoutParams(-1, 56));
            b.setOnClickListener(v -> { selectedPackage = pkg; selectedGameName = n; Toast.makeText(this, n + " selected", Toast.LENGTH_SHORT).show(); });
        }
    }

    private void optimizePage() {
        content.addView(tv("SADEE X DIMA OPTIMIZED", 25, GREEN));
        content.addView(tv("GAME MODE // READY", 15, CYAN));
        TextView log = tv("SYSTEM LOG\n> License verified\n> Device session online\n> Waiting for optimization...", 13, Color.LTGRAY); log.setTypeface(Typeface.MONOSPACE); content.addView(log);
        Button b = btn("⚡ SADEE X DIMA OPTIMIZED", GREEN); content.addView(b, new LinearLayout.LayoutParams(-1, 62));
        b.setOnClickListener(v -> runOptimization(log));
    }

    private void runOptimization(TextView log) {
        String[] steps = {"Imported profile", "Scanning device", "Clearing optimizer cache", "Refreshing memory metrics", "Preparing game mode"};
        final int[] i = {0}; ProgressDialog d = new ProgressDialog(this); d.setTitle("SADEE X DIMA // GAME MODE"); d.setMessage("Starting..."); d.setIndeterminate(false); d.setMax(steps.length); d.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); d.setCancelable(false); d.show();
        Runnable tick = new Runnable() { @Override public void run() { if (i[0] < steps.length) { d.setProgress(i[0] + 1); log.setText("SYSTEM LOG\n> " + steps[i[0]] + "\n> STATUS: RUNNING"); i[0]++; handler.postDelayed(this, 650); } else { d.dismiss(); log.setText("SYSTEM LOG\n> SADEE X DIMA OPTIMIZED\n> STATUS: COMPLETE\n> GAME: " + (selectedGameName == null ? "NOT SELECTED" : selectedGameName) + "\n> GAME LAUNCH READY"); Toast.makeText(MainActivity.this, "OPTIMIZATION COMPLETE", Toast.LENGTH_SHORT).show(); if (selectedPackage != null) { Intent launch = getPackageManager().getLaunchIntentForPackage(selectedPackage); if (launch != null) startActivity(launch); } } } }; handler.post(tick);
    }

    private void clearCache(File f) { if (f == null) return; File[] fs = f.listFiles(); if (fs != null) for (File x : fs) { if (x.isDirectory()) clearCache(x); else x.delete(); } }
}
