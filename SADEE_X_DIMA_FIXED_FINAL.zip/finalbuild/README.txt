SADEE X DIMA OPTIMIZER - FIXED FINAL

WHAT WAS FIXED
1. Android license verification no longer fails just because optional device metadata columns are missing.
2. First activation uses an atomic unbound + unused claim.
3. Same device can reopen an already-active license.
4. Another device is rejected only when device_id is actually different.
5. Admin generator / unbind / device pages use the same metadata fields.
6. SUPABASE_SCHEMA.sql adds all required columns to the existing licenses table without deleting existing licenses.
7. GitHub Actions builds the APK and deploys admin-dashboard to the gh-pages branch in one job.

SUPABASE SETUP
Run the complete SUPABASE_SCHEMA.sql once in Supabase SQL Editor.
Then wait a few seconds for PostgREST schema cache reload.

GITHUB
Upload this ZIP to the repository root and push to main.
The workflow extracts the ZIP, builds the APK, uploads the APK artifact, and deploys admin-dashboard.

IMPORTANT
The dashboard is intentionally no-login because that was requested. The publishable Supabase key is safe to expose to clients, but public write access is not a secure production authorization model. For a production paid-license system, move privileged writes to an authenticated backend/Edge Function.
