package com.sadee.dima;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.ArrayList;
import java.util.zip.*;

public class MainActivity extends Activity {
    private static final int PICK_ZIP = 10, PICK_DIR = 11;
    private TextView status, percent;
    private ProgressBar bar;
    private Uri zipUri;
    private long totalEntries=0, doneEntries=0;

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); }

    private TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(18,14,18,14); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false); return b; }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,30,22,22); root.setBackgroundColor(Color.rgb(3,3,5));
        TextView title=tv("SADEE X DIMA\nOPTIMIZER",25); title.setTextColor(Color.rgb(255,23,68)); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView note=tv("VIP PACK\nDEVICE STORAGE / Android_DETA\nAndroid 15: choose the destination folder once.",16); note.setGravity(Gravity.CENTER); root.addView(note);
        Button vip=btn("🔥  VIP SADEE X DIMA OPTIMIZER"); root.addView(vip,new LinearLayout.LayoutParams(-1,64));
        Button pick=btn("📦  SELECT ZIP PACK"); root.addView(pick,new LinearLayout.LayoutParams(-1,60));
        Button dest=btn("📁  SELECT Android_DETA FOLDER"); root.addView(dest,new LinearLayout.LayoutParams(-1,60));
        status=tv("READY — no files copied",15); status.setGravity(Gravity.CENTER); root.addView(status);
        bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(100); bar.setProgress(0); root.addView(bar,new LinearLayout.LayoutParams(-1,18));
        percent=tv("0%",22); percent.setTextColor(Color.rgb(255,23,68)); percent.setGravity(Gravity.CENTER); root.addView(percent);
        TextView safety=tv("Safety: executable/modification files (.so, .dex, .apk, .iso, scripts/configs intended to alter games) are not deployed. The app does not inject or modify Free Fire.",12); safety.setTextColor(Color.LTGRAY); root.addView(safety);
        setContentView(root);
        vip.setOnClickListener(v -> { if (zipUri == null) { pick.performClick(); } else { dest.performClick(); } });
        pick.setOnClickListener(v->{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/zip"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_ZIP); });
        dest.setOnClickListener(v->{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.putExtra("android.content.extra.SHOW_ADVANCED",true); startActivityForResult(i,PICK_DIR); });
    }

    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(c!=RESULT_OK||d==null)return; if(r==PICK_ZIP){ zipUri=d.getData(); status.setText("ZIP SELECTED ✓ — now select Android_DETA"); } else if(r==PICK_DIR && zipUri!=null){ Uri tree=d.getData(); getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION); startExtract(tree); } }

    private boolean blocked(String n){ String x=n.toLowerCase(); return x.endsWith(".so")||x.endsWith(".dex")||x.endsWith(".apk")||x.endsWith(".iso")||x.endsWith(".jar")||x.endsWith(".exe")||x.endsWith(".bat")||x.endsWith(".sh")||x.endsWith(".js")||x.endsWith(".dat")||x.contains("inject")||x.contains("bypass")||x.contains("aim")||x.contains("headshot"); }

    private void startExtract(Uri tree){ new Thread(()->{
        try{
            status.post(()->status.setText("SCANNING PACK…"));
            ArrayList<String> names=new ArrayList<>();
            try(InputStream in=getContentResolver().openInputStream(zipUri); ZipInputStream z=new ZipInputStream(new BufferedInputStream(in))){ ZipEntry e; while((e=z.getNextEntry())!=null){ if(!e.isDirectory()&&!blocked(e.getName())) names.add(e.getName()); }}
            totalEntries=names.size(); doneEntries=0;
            status.post(()->status.setText("EXTRACTING → Android_DETA"));
            try(InputStream in=getContentResolver().openInputStream(zipUri); ZipInputStream z=new ZipInputStream(new BufferedInputStream(in))){ ZipEntry e; byte[] buf=new byte[8192]; while((e=z.getNextEntry())!=null){ if(e.isDirectory()||blocked(e.getName())) continue; String clean=e.getName().replace('\\','/'); while(clean.startsWith("/"))clean=clean.substring(1); if(clean.contains("../")||clean.equals(".."))continue;
                    DocumentFileHelper.Target target=DocumentFileHelper.createFile(this,tree,clean); if(target==null)continue;
                    try(OutputStream out=getContentResolver().openOutputStream(target.uri)){ int n; while((n=z.read(buf))>0)out.write(buf,0,n); }
                    doneEntries++; int p=totalEntries==0?100:(int)(doneEntries*100L/totalEntries); bar.post(()->bar.setProgress(p)); percent.post(()->percent.setText(p+"%")); }
            }
            status.post(()->status.setText("✓ PACK COMPLETE — files copied to selected Android_DETA folder"));
            ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(android.os.VibrationEffect.createOneShot(180,android.os.VibrationEffect.DEFAULT_AMPLITUDE));
            new Handler(Looper.getMainLooper()).post(()->Toast.makeText(this,"PACK COMPLETE ✓",Toast.LENGTH_LONG).show());
        }catch(Exception ex){ status.post(()->status.setText("ERROR: "+ex.getMessage())); }
    }).start(); }

    static class DocumentFileHelper {
        static class Target { Uri uri; Target(Uri u){uri=u;} }
        static Target createFile(Activity a,Uri tree,String path){
            String[] parts=path.split("/"); Uri cur=tree;
            try{
                for(int i=0;i<parts.length-1;i++){ if(parts[i].isEmpty())continue; Uri next=findChild(a,cur,parts[i],true); if(next==null)return null; cur=next; }
                String name=parts[parts.length-1]; if(name.isEmpty())return null; Uri f=findChild(a,cur,name,false); if(f==null) f=android.provider.DocumentsContract.createDocument(a.getContentResolver(),cur,"application/octet-stream",name); return f==null?null:new Target(f);
            }catch(Exception e){return null;}
        }
        static Uri findChild(Activity a,Uri parent,String name,boolean dir)throws Exception{
            Uri children=android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(parent,android.provider.DocumentsContract.getTreeDocumentId(parent)); android.database.Cursor c=a.getContentResolver().query(children,new String[]{android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null); if(c!=null)try{while(c.moveToNext()){if(name.equals(c.getString(1))){String id=c.getString(0);return android.provider.DocumentsContract.buildDocumentUriUsingTree(parent,id);}}}finally{c.close();} return android.provider.DocumentsContract.createDocument(a.getContentResolver(),parent,android.provider.DocumentsContract.Document.MIME_TYPE_DIR,name);
        }
    }
}
