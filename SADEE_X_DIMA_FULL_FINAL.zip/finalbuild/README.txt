SADEE X DIMA OPTIMIZER - FINAL BUILD

1. Run SUPABASE_SCHEMA.sql in Supabase SQL Editor.
2. Keep the publishable key in Config.java/admin HTML only. Never use a service-role key in the app or dashboard.
3. Upload this project ZIP to your GitHub repository root (or any folder).
4. Put the supplied SADEE_X_DIMA_WORKFLOW.yml in .github/workflows/main.yml.
5. Push to main. The workflow searches the repository recursively for the ZIP, extracts it, builds the APK, uploads the APK artifact and deploys admin-dashboard to gh-pages.

The optimizer uses safe Android APIs: live device information, this-app cache cleaning, memory refresh/GC, Android storage settings and installed-app/game launching. It does not claim to silently clean or modify other apps, which Android normally prevents without privileged/root access.
