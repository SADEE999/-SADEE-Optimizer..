SADEE X DIMA FULL V5
====================

Included:
- 5-page Android optimizer UI
- License key login + 1-device binding
- Live device telemetry
- RAM scan/clean animation + beep
- Storage scan/cache clean animation + beep
- Gaming page with Free Fire / Free Fire MAX launch
- Remaining license time at the top
- SADEE X DIMA OPTIMIZED pre-launch sequence
- 4-page no-login admin dashboard
- Key generator: 7 DAYS / 1 MONTH / LIFETIME
- License controls: RESUME, PAUSE, EXPIRE, UNBIND DEVICE, DELETE
- Device telemetry: model, RAM, Android, device ID, last seen
- Supabase setup SQL
- One-job GitHub Actions workflow: Build APK and Admin

SUPABASE SETUP
--------------
1. Open Supabase SQL Editor.
2. Run SUPABASE_SETUP.sql once.
3. Wait for the query to finish successfully.
4. Commit/upload this ZIP to the GitHub repository root.
5. Run Actions -> SADEE X DIMA REAL BUILD.
6. Download artifact: SADEE-X-DIMA-REAL-RELEASE.
7. Admin is deployed to the gh-pages branch by the workflow.

IMPORTANT
---------
The dashboard uses the Supabase publishable/anon key in browser and app code.
Never put a Supabase service-role/secret key in the Android APK or admin HTML.
This no-login admin is intentionally simple; for a commercial production system,
admin writes should be protected with authentication or an Edge Function.
