SADEE X DIMA GREEN GAMING BUILD

UI updates:
- Green gaming theme with emoji/icons and logo hero cards.
- RAM page: RAM Scan, RAM Booster, RAM Cache Cleaner.
- Storage page: All File Cleaner, accessible-file scan, optimizer cleanup, Android storage controls.
- Games page: Game Booster cards for Free Fire and Free Fire MAX.
- Optimizer page: SADEE X DIMA OPTIMIZED automatically launches Free Fire after the optimization animation.

Safety:
Normal Android apps cannot silently kill other apps, clear other apps' private data, or modify/inject game files. Cleanup is limited to app-owned cache/files and Android settings where required.

Build:
GitHub Actions extracts the uploaded ZIP, builds the APK with Java 17 + Gradle 8.7, uploads the APK artifact, and deploys admin-dashboard to gh-pages.
