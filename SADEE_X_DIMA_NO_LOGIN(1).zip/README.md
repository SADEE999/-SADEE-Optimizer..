# SADEE X DIMA — REAL SUPABASE NO-LOGIN ADMIN

The admin dashboard has NO email/password screen. It opens directly and talks to Supabase using the publishable key.

Run `SUPABASE_NO_LOGIN.sql` in Supabase SQL Editor before using Generate/Pause/Delete.

Security note: no-login + public CRUD means the license table can be changed by anyone who can access the dashboard. For a private production admin, use an Edge Function/protected backend later.
