package com.sadee.xdima;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Build;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, content;
    private TextView title, status;
    private SharedPreferences prefs;
    private final Handler handler = new Handler();
    private int cyan = Color.rgb(0,229,255);
    private int purple = Color.rgb(124,77,255);
    private int bg = Color.rgb(5,8,13);
    private int panel = Color.rgb(11,17,26);
    private int text = Color.rgb(244,247,250);
    private int muted = Color.rgb(141,154,170);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("sadee", MODE_PRIVATE);
        showLoginIfNeeded();
    }

    private TextView tv(String s, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        v.setPadding(0, 6, 0, 6);
        return v;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(16,25,37));
        b.setPadding(18, 12, 18, 12);
        return b;
    }

    private LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(18,16,18,16);
        l.setBackgroundColor(panel);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,8,0,8);
        l.setLayoutParams(p);
        return l;
    }

    private void base(String page) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(18,18,18,18);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setPadding(8,6,8,6);
        nav.setBackgroundColor(Color.rgb(8,12,18));
        String[] ns={"HOME","BOOST","DEVICE","SETTINGS"};
        for(String n:ns){
            Button b=btn(n); b.setTextSize(11);
            nav.addView(b,new LinearLayout.LayoutParams(0,58,1));
            if(n.equals("HOME")) b.setOnClickListener(v->home());
            if(n.equals("BOOST")) b.setOnClickListener(v->boost());
            if(n.equals("DEVICE")) b.setOnClickListener(v->device());
            if(n.equals("SETTINGS")) b.setOnClickListener(v->settings());
        }
        root.addView(nav);
        setContentView(root);
    }

    private void header(String sub) {
        title = tv("SADEE X DIMA",26,cyan); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        content.addView(title);
        TextView x=tv("ADVANCED OPTIMIZER  •  "+sub,11,muted);
        content.addView(x);
        View line=new View(this); line.setBackgroundColor(Color.rgb(30,45,62));
        content.addView(line,new LinearLayout.LayoutParams(-1,1));
    }

    private void showLoginIfNeeded() {
        if (prefs.getBoolean("logged", false)) { home(); return; }
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER); root.setPadding(28,28,28,28); root.setBackgroundColor(bg);
        TextView logo=tv("SADEE X DIMA",30,cyan); logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD); logo.setGravity(17);
        root.addView(logo);
        TextView sub=tv("ADVANCED GAMING OPTIMIZER",12,muted); sub.setGravity(17); root.addView(sub);
        EditText key=new EditText(this); key.setHint("Enter license key"); key.setHintTextColor(muted);
        key.setTextColor(text); key.setSingleLine(true); key.setPadding(18,8,18,8);
        root.addView(key,new LinearLayout.LayoutParams(-1,60));
        Button login=btn("ACTIVATE LICENSE");
        root.addView(login,new LinearLayout.LayoutParams(-1,58));
        TextView demo=tv("Demo key: DIMA-2026-ADVANCED",11,muted); demo.setGravity(17); root.addView(demo);
        TextView msg=tv("",12,Color.RED); msg.setGravity(17); root.addView(msg);
        login.setOnClickListener(v->{
            String k=key.getText().toString().trim();
            if(k.equalsIgnoreCase("DIMA-2026-ADVANCED") || k.length()>=10){
                prefs.edit().putBoolean("logged",true).putString("key",k).apply();
                home();
            } else msg.setText("Invalid license key");
        });
        setContentView(root);
    }

    private void home() {
        base("CONTROL CENTER"); header("CONTROL CENTER");
        LinearLayout hero=box();
        hero.addView(tv("SYSTEM READY",14,Color.rgb(57,255,136)));
        hero.addView(tv("Smart profile • Balanced performance",18,text));
        hero.addView(tv("Gaming profile is prepared without root access.",11,muted));
        content.addView(hero);

        LinearLayout stats=box();
        stats.addView(tv("LIVE STATUS",13,cyan));
        stats.addView(tv("RAM      "+ram()+" MB free",14,text));
        stats.addView(tv("ANDROID  "+Build.VERSION.RELEASE,14,text));
        stats.addView(tv("MODEL    "+Build.MANUFACTURER+" "+Build.MODEL,14,text));
        stats.addView(tv("LICENSE  ACTIVE",14,Color.rgb(57,255,136)));
        content.addView(stats);

        Button b=btn("OPEN BOOST CENTER");
        content.addView(b); b.setOnClickListener(v->boost());
    }

    private String ram(){
        android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
        android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi); return String.valueOf(mi.availMem/1024/1024);
    }

    private void boost() {
        base("BOOST CENTER"); header("BOOST CENTER");
        LinearLayout card=box();
        card.addView(tv("PERFORMANCE ENGINE",14,cyan));
        card.addView(tv("Ready to run a safe optimization simulation.",12,muted));
        content.addView(card);
        String[] opts={"Reduce background load","Refresh app process state","Prepare gaming profile","Network latency monitor"};
        for(String o:opts){
            LinearLayout r=box();
            CheckBox c=new CheckBox(this); c.setText(o); c.setTextColor(text); c.setChecked(true);
            r.addView(c); content.addView(r);
        }
        Button go=btn("⚡  START 10s BOOST");
        content.addView(go);
        status=tv("",13,cyan); status.setGravity(17); content.addView(status);
        go.setOnClickListener(v->{
            go.setEnabled(false); final long start=System.currentTimeMillis();
            handler.post(new Runnable(){ public void run(){
                long elapsed=System.currentTimeMillis()-start; int sec=(int)(elapsed/1000);
                if(sec<10){ status.setText("BOOST ENGINE  "+(10-sec)+"s"); handler.postDelayed(this,250); }
                else { status.setText("✓ BOOST COMPLETE  •  PROFILE READY"); go.setEnabled(true); }
            }});
        });
    }

    private void device() {
        base("DEVICE"); header("DEVICE INTELLIGENCE");
        LinearLayout d=box();
        d.addView(tv("DEVICE",13,cyan));
        d.addView(tv(Build.MANUFACTURER+" "+Build.MODEL,18,text));
        d.addView(tv("Android "+Build.VERSION.RELEASE+"  •  SDK "+Build.VERSION.SDK_INT,12,muted));
        d.addView(tv("CPU ABI  "+Build.SUPPORTED_ABIS[0],12,muted));
        d.addView(tv("RAM FREE  "+ram()+" MB",12,muted));
        content.addView(d);
        LinearLayout note=box();
        note.addView(tv("ENGINE NOTE",13,purple));
        note.addView(tv("This build uses Android-safe UI controls and does not claim to modify protected system settings.",12,muted));
        content.addView(note);
    }

    private void settings() {
        base("SETTINGS"); header("SETTINGS");
        LinearLayout s=box();
        s.addView(tv("LICENSE",13,cyan));
        s.addView(tv("Key: "+prefs.getString("key","ACTIVE"),12,text));
        Button logout=btn("LOG OUT");
        s.addView(logout); content.addView(s);
        logout.setOnClickListener(v->{prefs.edit().clear().apply(); showLoginIfNeeded();});
    }
}
