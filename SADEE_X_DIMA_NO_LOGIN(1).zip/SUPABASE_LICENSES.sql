-- SADEE X DIMA REAL LICENSE SYSTEM
-- Run this whole file in Supabase SQL Editor.
-- IMPORTANT: Never put a service_role/secret key in the app or browser.

create extension if not exists pgcrypto;

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  license_key text unique not null,
  plan text not null check (plan in ('7D','30D','LIFETIME')),
  status text not null default 'ACTIVE' check (status in ('ACTIVE','PAUSED','EXPIRED')),
  device_id text,
  device_name text,
  bound_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists licenses_key_idx on public.licenses(license_key);
create index if not exists licenses_status_idx on public.licenses(status);
create index if not exists licenses_created_idx on public.licenses(created_at desc);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.licenses enable row level security;
alter table public.admin_users enable row level security;

-- Helper: only users listed in admin_users are admins.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admin_users
    where user_id = auth.uid()
  );
$$;

-- Mobile app: anonymous/public clients can only SELECT ACTIVE licenses.
-- The query still filters by the exact license_key supplied by the app.
drop policy if exists "mobile can verify active licenses" on public.licenses;
create policy "mobile can verify active licenses"
on public.licenses
for select
to anon, authenticated
using (status = 'ACTIVE');

-- Admin dashboard: full CRUD only for authenticated admin users.
drop policy if exists "admins read licenses" on public.licenses;
create policy "admins read licenses"
on public.licenses for select
to authenticated
using (public.is_admin());

drop policy if exists "admins insert licenses" on public.licenses;
create policy "admins insert licenses"
on public.licenses for insert
to authenticated
with check (public.is_admin());

drop policy if exists "admins update licenses" on public.licenses;
create policy "admins update licenses"
on public.licenses for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "admins delete licenses" on public.licenses;
create policy "admins delete licenses"
on public.licenses for delete
to authenticated
using (public.is_admin());

-- admin_users should only be readable by its own security-definer function.
-- No public insert/update/delete policy is created intentionally.
revoke all on public.admin_users from anon, authenticated;

-- AFTER creating an admin account in Supabase Authentication,
-- replace YOUR_AUTH_USER_UUID below with that account's UUID and run:
--
-- insert into public.admin_users(user_id)
-- values ('YOUR_AUTH_USER_UUID')
-- on conflict do nothing;

-- Example real license:
-- insert into public.licenses (license_key, plan, status, expires_at)
-- values ('SXD-ABCD-1234-EFGH', '7D', 'ACTIVE', now() + interval '7 days');
