import 'package:flutter/material.dart';
import 'screens/user_home_v6.dart';

void main() {
  runApp(const SadeeDimaApp());
}

class SadeeDimaApp extends StatelessWidget {
  const SadeeDimaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SADEE X DIMA OPTIMIZER',
      theme: ThemeData.dark(useMaterial3: true),
      home: const UserHomeScreen(),
    );
  }
}
