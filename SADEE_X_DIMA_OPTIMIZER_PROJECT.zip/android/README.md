Android project scaffold. Run flutter create . in the project before building if needed.
