package com.sadee.optimizer;
import android.content.*;import android.net.Uri;import android.os.Bundle;import android.provider.Settings;import android.view.View;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import org.json.JSONObject;
public class LoginActivity extends AppCompatActivity{
 private EditText keyInput; private TextView status; private Button login; private String selectedPlan="7 Days",selectedPrice="LKR 500"; private static final String WHATSAPP="94768472404";
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_login);keyInput=findViewById(R.id.keyInput);status=findViewById(R.id.txtStatus);login=findViewById(R.id.btnLogin);Button order=findViewById(R.id.btnOrder);Button p7=findViewById(R.id.plan7),p30=findViewById(R.id.plan30),pl=findViewById(R.id.planLife);
  View.OnClickListener pick=v->{if(v==p7){selectedPlan="7 Days";selectedPrice="LKR 500";}else if(v==p30){selectedPlan="1 Month";selectedPrice="LKR 1,000";}else{selectedPlan="Lifetime";selectedPrice="LKR 2,200";}status.setText("SELECTED • "+selectedPlan+" • "+selectedPrice);};p7.setOnClickListener(pick);p30.setOnClickListener(pick);pl.setOnClickListener(pick);order.setOnClickListener(v->openWhatsApp());login.setOnClickListener(v->verify());
  String saved=getSharedPreferences("license",MODE_PRIVATE).getString("key","");if(!saved.isEmpty()){keyInput.setText(saved);verify();}
 }
 private void verify(){String key=keyInput.getText().toString().trim().toUpperCase();if(key.isEmpty()){status.setText("ENTER A LICENSE KEY");return;}login.setEnabled(false);login.setText("VERIFYING…");status.setText("SECURE LICENSE CHECK • SUPABASE");String deviceId=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);LicenseService.validate(key,deviceId,(ok,message,data)->runOnUiThread(()->{login.setEnabled(true);login.setText("VERIFY & UNLOCK");if(ok){
 getSharedPreferences("license",MODE_PRIVATE).edit().putString("key",key).putString("plan",data.optString("plan","Licensed")).putString("expires_at",data.optString("expires_at","No expiry • Full access")).apply();
 status.setText("LICENSE VERIFIED SUCCESSFULLY");
 login.setText("OPENING DASHBOARD…");
 new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{
   Intent i=new Intent(LoginActivity.this,MainActivity.class);
   i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
   try { startActivity(i); } catch(Exception e) { status.setText(("DASHBOARD ERROR: "+e.getClass().getSimpleName()).toUpperCase()); login.setText("VERIFY & UNLOCK"); }
 },350);
}else status.setText(message.toUpperCase());}));}
 private void openWhatsApp(){String msg="SADEE X DIMA OPTIMIZER\n\nI want to order:\nPlan: "+selectedPlan+"\nPrice: "+selectedPrice+"\n\nPlease send payment/order details.";try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+WHATSAPP+"?text="+Uri.encode(msg))));}catch(Exception e){status.setText("WHATSAPP COULD NOT BE OPENED");}}
}
